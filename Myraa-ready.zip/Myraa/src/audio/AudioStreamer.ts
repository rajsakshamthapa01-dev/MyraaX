/**
 * AudioStreamer - Microphone Capture & Voice Activity Detection Engine for Gemini Live
 *
 * Implements:
 * 1. 16kHz PCM16 Little-Endian streaming for Gemini Live API.
 * 2. High-grade noise suppression, echo cancellation, and automatic gain control.
 * 3. Silent Web Audio routing (prevents acoustic feedback loop from processor to speaker).
 * 4. Anti-Noise Interruption Shield:
 *    - Suppresses ambient noise, room reverb, fan/AC hum, and speaker bleed.
 *    - Distinguishes between ambient noise and genuine intentional user speech.
 *    - Prevents background sounds from triggering unwanted Gemini Live barge-in interruptions.
 *    - Preserves deliberate user voice interruption when user speaks with sustained intent.
 */

export type InterruptionShieldMode = 'balanced' | 'high_protection' | 'voice_only';

export class AudioStreamer {
  private audioCtx: AudioContext | null = null;
  private mediaStream: MediaStream | null = null;
  private sourceNode: MediaStreamAudioSourceNode | null = null;
  private processorNode: ScriptProcessorNode | null = null;
  private zeroGainNode: GainNode | null = null;
  private analyserNode: AnalyserNode | null = null;

  private onAudioChunk: (base64Audio: string, isIntentionalSpeech: boolean) => void;
  private onVolumeChange?: (volume: number) => void;
  private onIntentionalBargeIn?: () => void;

  private isMuted: boolean = false;
  private isRunning: boolean = false;
  private isAssistantSpeaking: boolean = false;
  private shieldMode: InterruptionShieldMode = 'high_protection';

  // Adaptive noise floor tracking
  private ambientNoiseFloor: number = 0.015;
  private sustainedBargeInFrames: number = 0;
  private speechHangoverFrames: number = 0;
  private preRollBuffer: string[] = [];

  constructor(
    onAudioChunk: (base64Audio: string, isIntentionalSpeech: boolean) => void,
    onVolumeChange?: (volume: number) => void,
    onIntentionalBargeIn?: () => void
  ) {
    this.onAudioChunk = onAudioChunk;
    this.onVolumeChange = onVolumeChange;
    this.onIntentionalBargeIn = onIntentionalBargeIn;
  }

  public setAssistantSpeaking(speaking: boolean): void {
    this.isAssistantSpeaking = speaking;
    if (!speaking) {
      this.sustainedBargeInFrames = 0;
    }
  }

  public setShieldMode(mode: InterruptionShieldMode): void {
    this.shieldMode = mode;
  }

  public async start(): Promise<void> {
    if (this.isRunning) return;

    // 1. Request microphone with browser-native hardware DSP echo cancellation and noise suppression
    this.mediaStream = await navigator.mediaDevices.getUserMedia({
      audio: {
        channelCount: 1,
        echoCancellation: true,
        noiseSuppression: true,
        autoGainControl: true,
      },
    });

    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    this.audioCtx = new AudioContextClass();
    if (this.audioCtx.state === 'suspended') {
      await this.audioCtx.resume();
    }

    this.sourceNode = this.audioCtx.createMediaStreamSource(this.mediaStream);

    // Create analyser for visualizer volume meter
    this.analyserNode = this.audioCtx.createAnalyser();
    this.analyserNode.fftSize = 256;
    this.analyserNode.smoothingTimeConstant = 0.4;
    this.sourceNode.connect(this.analyserNode);

    // Buffer size 2048 gives ~43ms latency per chunk at 48kHz
    const bufferSize = 2048;
    this.processorNode = this.audioCtx.createScriptProcessor(bufferSize, 1, 1);

    // Zero-gain node ensures the processor runs in the Web Audio graph WITHOUT sending
    // microphone audio back into the device speakers (preventing speaker-to-mic acoustic feedback)
    this.zeroGainNode = this.audioCtx.createGain();
    this.zeroGainNode.gain.value = 0;

    this.processorNode.onaudioprocess = (e: AudioProcessingEvent) => {
      // Always zero out output buffer to guarantee no audible mic loopback
      const outputBuffer = e.outputBuffer.getChannelData(0);
      outputBuffer.fill(0);

      if (!this.isRunning || this.isMuted) {
        if (this.onVolumeChange) this.onVolumeChange(0);
        return;
      }

      const inputBuffer = e.inputBuffer.getChannelData(0);
      const sampleRate = e.inputBuffer.sampleRate;

      // 1. Calculate Root-Mean-Square (RMS) amplitude
      let sumSquares = 0;
      for (let i = 0; i < inputBuffer.length; i++) {
        sumSquares += inputBuffer[i] * inputBuffer[i];
      }
      const rms = Math.sqrt(sumSquares / inputBuffer.length);

      // Dynamically adapt ambient noise baseline during low-energy periods
      if (rms < 0.05) {
        this.ambientNoiseFloor = this.ambientNoiseFloor * 0.95 + rms * 0.05;
      }

      // 2. Report volume for UI waveform display (boosted for responsiveness)
      if (this.onVolumeChange) {
        const normalized = Math.min(1, rms * 4.5);
        this.onVolumeChange(normalized);
      }

      // 3. Resample to 16kHz PCM16 Little-Endian
      const base64Chunk = this.resampleTo16kPCM16(inputBuffer, sampleRate);
      if (!base64Chunk) return;

      // Maintain rolling pre-roll buffer (2 frames ~ 85ms) so speech onset is never clipped
      this.preRollBuffer.push(base64Chunk);
      if (this.preRollBuffer.length > 3) {
        this.preRollBuffer.shift();
      }

      // 4. Voice Activity Detection & Interruption Shield Logic
      if (this.isAssistantSpeaking) {
        /**
         * ANTI-NOISE SHIELD (While MYRAA is speaking):
         *
         * Background noise (chatter, TV, typing, room hiss, or acoustic speaker bleed)
         * typically has RMS below 0.09.
         * If we send low/medium background noise to Gemini Live, the server's VAD triggers
         * and prematurely cancels playback.
         *
         * We enforce an intentional barge-in energy threshold and require sustained speech
         * (at least 3 consecutive frames ~130ms) before forwarding audio and triggering interruption.
         */
        const bargeInThreshold =
          this.shieldMode === 'voice_only'
            ? 0.16
            : this.shieldMode === 'high_protection'
            ? 0.12
            : 0.09;

        if (rms >= bargeInThreshold) {
          this.sustainedBargeInFrames++;
        } else {
          this.sustainedBargeInFrames = Math.max(0, this.sustainedBargeInFrames - 1);
        }

        // Genuine intentional user interruption confirmed (user spoke loudly/deliberately)
        if (this.sustainedBargeInFrames >= 3) {
          this.onIntentionalBargeIn?.();

          // Flush pre-roll so user's interruption statement is complete
          while (this.preRollBuffer.length > 0) {
            const buffered = this.preRollBuffer.shift()!;
            this.onAudioChunk(buffered, true);
          }
          this.onAudioChunk(base64Chunk, true);
        }
        // Otherwise: SUPPRESS background noise and speaker echo! Do NOT send to Gemini!
      } else {
        /**
         * NORMAL LISTENING MODE (While MYRAA is waiting for user speech):
         *
         * Sensitive speech threshold to capture regular user voice immediately.
         * Filters out continuous silence and AC hum below noise floor.
         */
        const speechThreshold = Math.max(0.018, this.ambientNoiseFloor * 2.2);

        if (rms >= speechThreshold) {
          // User is actively speaking
          this.speechHangoverFrames = 12; // ~500ms hangover to retain pauses between words

          // Flush pre-roll buffer if starting speech
          while (this.preRollBuffer.length > 0) {
            const buffered = this.preRollBuffer.shift()!;
            this.onAudioChunk(buffered, false);
          }
          this.onAudioChunk(base64Chunk, false);
        } else if (this.speechHangoverFrames > 0) {
          // In hangover window: continue streaming natural trailing speech
          this.speechHangoverFrames--;
          this.onAudioChunk(base64Chunk, false);
        }
      }
    };

    this.sourceNode.connect(this.processorNode);
    this.processorNode.connect(this.zeroGainNode);
    this.zeroGainNode.connect(this.audioCtx.destination);

    this.isRunning = true;
  }

  public setMuted(muted: boolean): void {
    this.isMuted = muted;
    if (this.mediaStream) {
      this.mediaStream.getAudioTracks().forEach((track) => {
        track.enabled = !muted;
      });
    }
  }

  public getIsMuted(): boolean {
    return this.isMuted;
  }

  public getIsRunning(): boolean {
    return this.isRunning;
  }

  public stop(): void {
    this.isRunning = false;
    this.isAssistantSpeaking = false;
    this.sustainedBargeInFrames = 0;
    this.speechHangoverFrames = 0;
    this.preRollBuffer = [];

    if (this.processorNode) {
      this.processorNode.disconnect();
      this.processorNode.onaudioprocess = null;
      this.processorNode = null;
    }

    if (this.zeroGainNode) {
      this.zeroGainNode.disconnect();
      this.zeroGainNode = null;
    }

    if (this.sourceNode) {
      this.sourceNode.disconnect();
      this.sourceNode = null;
    }

    if (this.analyserNode) {
      this.analyserNode.disconnect();
      this.analyserNode = null;
    }

    if (this.mediaStream) {
      this.mediaStream.getTracks().forEach((track) => track.stop());
      this.mediaStream = null;
    }

    if (this.audioCtx && this.audioCtx.state !== 'closed') {
      this.audioCtx.close().catch(() => {});
      this.audioCtx = null;
    }

    if (this.onVolumeChange) {
      this.onVolumeChange(0);
    }
  }

  /**
   * Resamples float32 PCM data from source sample rate to 16000Hz 16-bit linear PCM.
   */
  private resampleTo16kPCM16(input: Float32Array, sourceRate: number): string {
    const targetRate = 16000;
    let outputLength: number;
    let pcm16: Int16Array;

    if (sourceRate === targetRate) {
      outputLength = input.length;
      pcm16 = new Int16Array(outputLength);
      for (let i = 0; i < outputLength; i++) {
        const s = Math.max(-1, Math.min(1, input[i]));
        pcm16[i] = s < 0 ? s * 0x8000 : s * 0x7fff;
      }
    } else {
      const ratio = sourceRate / targetRate;
      outputLength = Math.round(input.length / ratio);
      pcm16 = new Int16Array(outputLength);
      for (let i = 0; i < outputLength; i++) {
        const srcIdx = Math.floor(i * ratio);
        const s = Math.max(-1, Math.min(1, input[srcIdx] || 0));
        pcm16[i] = s < 0 ? s * 0x8000 : s * 0x7fff;
      }
    }

    // Convert Int16Array buffer to base64 string
    const bytes = new Uint8Array(pcm16.buffer);
    let binary = '';
    const chunkStep = 8192;
    for (let i = 0; i < bytes.length; i += chunkStep) {
      const slice = bytes.subarray(i, i + chunkStep);
      binary += String.fromCharCode.apply(null, Array.from(slice));
    }
    return btoa(binary);
  }
}
