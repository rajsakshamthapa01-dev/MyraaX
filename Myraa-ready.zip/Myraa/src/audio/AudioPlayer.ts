/**
 * AudioPlayer - High-Fidelity Gapless Playback Queue for Gemini Live Audio
 *
 * Implements:
 * 1. Sequential FIFO audio chunk queue for 24kHz raw PCM16 base64 from Gemini Live.
 * 2. Gapless Web Audio API scheduling with jitter buffering / pre-roll.
 * 3. Hysteresis-aware playback state tracking (prevents rapid flickering between chunks).
 * 4. Resilient turn management (does not drop chunks when new chunks arrive).
 * 5. Instantaneous, clean cancellation when genuine user interruption is confirmed.
 * 6. Real-time frequency analysis for anime hologram & waveform HUD visualizers.
 */

export class AudioPlayer {
  private audioCtx: AudioContext | null = null;
  private gainNode: GainNode | null = null;
  private analyserNode: AnalyserNode | null = null;
  private nextScheduledTime: number = 0;
  private activeSources: Set<AudioBufferSourceNode> = new Set();
  private chunkQueue: AudioBuffer[] = [];
  private isProcessingQueue: boolean = false;
  private isPlayingState: boolean = false;
  private isTurnComplete: boolean = false;
  private onPlaybackStateChange?: (isPlaying: boolean) => void;
  private volume: number = 1.0;
  private idleCheckTimeout: number | null = null;

  constructor(onPlaybackStateChange?: (isPlaying: boolean) => void) {
    this.onPlaybackStateChange = onPlaybackStateChange;
  }

  private initContextIfNeeded(): AudioContext {
    if (!this.audioCtx || this.audioCtx.state === 'closed') {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      // Output sample rate for Gemini Live audio is 24000Hz mono PCM16
      this.audioCtx = new AudioContextClass({ sampleRate: 24000 });
      this.gainNode = this.audioCtx.createGain();
      this.gainNode.gain.value = this.volume;

      this.analyserNode = this.audioCtx.createAnalyser();
      this.analyserNode.fftSize = 256;
      this.analyserNode.smoothingTimeConstant = 0.6;

      this.gainNode.connect(this.analyserNode);
      this.analyserNode.connect(this.audioCtx.destination);
      this.nextScheduledTime = 0;
    }
    return this.audioCtx;
  }

  public async resume(): Promise<void> {
    const ctx = this.initContextIfNeeded();
    if (ctx.state === 'suspended') {
      await ctx.resume();
    }
  }

  public setVolume(vol: number): void {
    this.volume = Math.max(0, Math.min(1, vol));
    if (this.gainNode) {
      this.gainNode.gain.value = this.volume;
    }
  }

  public getVolume(): number {
    return this.volume;
  }

  public getAnalyser(): AnalyserNode | null {
    return this.analyserNode;
  }

  public isPlaying(): boolean {
    return this.isPlayingState;
  }

  /**
   * Decodes a base64-encoded 24kHz 16-bit linear PCM little-endian chunk into an AudioBuffer.
   */
  private decodePcm16Chunk(base64Data: string, ctx: AudioContext): AudioBuffer | null {
    try {
      const binaryString = atob(base64Data);
      const len = binaryString.length;
      if (len === 0) return null;

      // PCM16 requires 2 bytes per sample
      const sampleCount = Math.floor(len / 2);
      if (sampleCount === 0) return null;

      const bytes = new Uint8Array(len);
      for (let i = 0; i < len; i++) {
        bytes[i] = binaryString.charCodeAt(i);
      }

      const int16Array = new Int16Array(bytes.buffer, 0, sampleCount);
      const float32Array = new Float32Array(sampleCount);
      for (let i = 0; i < sampleCount; i++) {
        float32Array[i] = int16Array[i] / 32768.0;
      }

      const audioBuffer = ctx.createBuffer(1, sampleCount, 24000);
      audioBuffer.copyToChannel(float32Array, 0);
      return audioBuffer;
    } catch (err) {
      console.error('[AudioPlayer] Error decoding PCM16 chunk:', err);
      return null;
    }
  }

  /**
   * Enqueues an incoming 24kHz PCM16 audio chunk from Gemini Live and schedules playback.
   * Chunks are preserved in original sequence and scheduled gaplessly.
   */
  public playChunk(base64Data: string): void {
    if (!base64Data) return;

    try {
      const ctx = this.initContextIfNeeded();
      if (ctx.state === 'suspended') {
        ctx.resume().catch(() => {});
      }

      const audioBuffer = this.decodePcm16Chunk(base64Data, ctx);
      if (!audioBuffer) return;

      this.isTurnComplete = false;
      this.chunkQueue.push(audioBuffer);

      // Cancel any pending idle timeout since new audio arrived
      if (this.idleCheckTimeout !== null) {
        window.clearTimeout(this.idleCheckTimeout);
        this.idleCheckTimeout = null;
      }

      this.drainQueue(ctx);
    } catch (err) {
      console.error('[AudioPlayer] Error enqueuing chunk:', err);
    }
  }

  /**
   * Drains the FIFO chunk queue, scheduling nodes gaplessly on the Web Audio timeline.
   */
  private drainQueue(ctx: AudioContext): void {
    if (this.isProcessingQueue) return;
    this.isProcessingQueue = true;

    try {
      const currentTime = ctx.currentTime;

      while (this.chunkQueue.length > 0) {
        const audioBuffer = this.chunkQueue.shift()!;

        // When starting from idle or if buffer underrun occurred, apply a 45ms safety jitter offset
        if (this.nextScheduledTime < currentTime) {
          this.nextScheduledTime = currentTime + 0.045;
        }

        const source = ctx.createBufferSource();
        source.buffer = audioBuffer;
        source.connect(this.gainNode!);

        source.start(this.nextScheduledTime);
        this.activeSources.add(source);

        this.nextScheduledTime += audioBuffer.duration;

        if (!this.isPlayingState) {
          this.isPlayingState = true;
          this.onPlaybackStateChange?.(true);
        }

        source.onended = () => {
          this.activeSources.delete(source);
          try {
            source.disconnect();
          } catch {
            // Ignore if already disconnected
          }
          this.checkIdleState(ctx);
        };
      }
    } finally {
      this.isProcessingQueue = false;
    }
  }

  /**
   * Called by LiveSession when Gemini signals that the current turn's audio generation is complete.
   */
  public markTurnComplete(): void {
    this.isTurnComplete = true;
    if (this.audioCtx) {
      this.checkIdleState(this.audioCtx);
    }
  }

  /**
   * Checks whether playback has truly completed or if scheduled chunks are still playing.
   * Applies hysteresis to prevent state flipping on brief network jitter.
   */
  private checkIdleState(ctx: AudioContext): void {
    if (this.idleCheckTimeout !== null) {
      window.clearTimeout(this.idleCheckTimeout);
      this.idleCheckTimeout = null;
    }

    const check = () => {
      const now = ctx.currentTime;
      const isBufferEmpty = this.chunkQueue.length === 0;
      const noActiveSources = this.activeSources.size === 0;
      const timePastScheduled = now >= this.nextScheduledTime - 0.015;

      if (isBufferEmpty && noActiveSources && timePastScheduled) {
        if (this.isPlayingState) {
          this.isPlayingState = false;
          this.nextScheduledTime = 0;
          this.onPlaybackStateChange?.(false);
        }
      }
    };

    // Use a small 90ms hysteresis window so if another chunk is in transit, we don't flash LISTENING
    this.idleCheckTimeout = window.setTimeout(check, 90);
  }

  /**
   * Instantly stops playback, clears all scheduled audio chunks, and resets the queue.
   * ONLY called when genuine user interruption is confirmed or session disconnects.
   */
  public stopAndClear(): void {
    if (this.idleCheckTimeout !== null) {
      window.clearTimeout(this.idleCheckTimeout);
      this.idleCheckTimeout = null;
    }

    this.chunkQueue = [];
    this.isTurnComplete = false;

    for (const source of this.activeSources) {
      try {
        source.onended = null;
        source.stop();
        source.disconnect();
      } catch {
        // Source might already have ended
      }
    }
    this.activeSources.clear();

    if (this.audioCtx) {
      this.nextScheduledTime = this.audioCtx.currentTime;
    }

    if (this.isPlayingState) {
      this.isPlayingState = false;
      this.onPlaybackStateChange?.(false);
    }
  }

  public getPlaybackEnergy(): number {
    if (!this.analyserNode || !this.isPlayingState) return 0;
    const buffer = new Uint8Array(this.analyserNode.frequencyBinCount);
    this.analyserNode.getByteFrequencyData(buffer);
    let sum = 0;
    for (let i = 0; i < buffer.length; i++) {
      sum += buffer[i];
    }
    return Math.min(1, (sum / buffer.length) / 128);
  }

  public close(): void {
    this.stopAndClear();
    if (this.audioCtx && this.audioCtx.state !== 'closed') {
      this.audioCtx.close().catch(() => {});
      this.audioCtx = null;
    }
    this.gainNode = null;
    this.analyserNode = null;
  }
}
