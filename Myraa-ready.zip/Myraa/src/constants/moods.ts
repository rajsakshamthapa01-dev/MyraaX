import { AssistantMood, MoodConfig } from '../types/live';

export const MOODS: Record<AssistantMood, MoodConfig> = {
  electric_cyan: {
    name: 'electric_cyan',
    label: 'Electric Cyan (Default)',
    primaryColor: '#00f0ff', // bright neon cyan
    secondaryColor: '#0066ff', // electric blue
    glowColor: 'rgba(0, 240, 255, 0.65)',
    accentBg: 'bg-cyan-500/10',
    borderColor: 'border-cyan-400/40',
    hologramHue: 'hue-rotate(0deg)',
  },
  neon_blue: {
    name: 'neon_blue',
    label: 'Deep Neon Blue',
    primaryColor: '#3b82f6',
    secondaryColor: '#6366f1',
    glowColor: 'rgba(59, 130, 246, 0.65)',
    accentBg: 'bg-blue-500/10',
    borderColor: 'border-blue-400/40',
    hologramHue: 'hue-rotate(210deg)',
  },
  crimson_core: {
    name: 'crimson_core',
    label: 'Crimson Matrix',
    primaryColor: '#ff2247',
    secondaryColor: '#b91c1c',
    glowColor: 'rgba(255, 34, 71, 0.65)',
    accentBg: 'bg-red-500/10',
    borderColor: 'border-red-400/40',
    hologramHue: 'hue-rotate(330deg)',
  },
  matrix_green: {
    name: 'matrix_green',
    label: 'Matrix Emerald',
    primaryColor: '#00ffaa',
    secondaryColor: '#059669',
    glowColor: 'rgba(0, 255, 170, 0.65)',
    accentBg: 'bg-emerald-500/10',
    borderColor: 'border-emerald-400/40',
    hologramHue: 'hue-rotate(90deg)',
  },
  amethyst_void: {
    name: 'amethyst_void',
    label: 'Amethyst Void',
    primaryColor: '#c084fc',
    secondaryColor: '#9333ea',
    glowColor: 'rgba(192, 132, 252, 0.65)',
    accentBg: 'bg-purple-500/10',
    borderColor: 'border-purple-400/40',
    hologramHue: 'hue-rotate(270deg)',
  },
};
