import { AssistantEmotion, AssistantMood } from '../types/live';

export interface EmotionDefinition {
  id: AssistantEmotion;
  label: string;
  emoji: string;
  auraColor: string;
  glowColor: string;
  tagline: string;
  description: string;
  recommendedMood: AssistantMood;
  effect?: string;
}

export const EMOTIONS: Record<AssistantEmotion, EmotionDefinition> = {
  joyful: {
    id: 'joyful',
    label: 'Joyful & Smiling',
    emoji: '✨',
    auraColor: '#fbbf24',
    glowColor: 'rgba(251, 191, 36, 0.65)',
    tagline: 'हँसमुख और खुश',
    description: 'Upbeat, beaming with happiness, laughing and sharing cheerful energy.',
    recommendedMood: 'electric_cyan',
    effect: 'sparkle',
  },
  caring: {
    id: 'caring',
    label: 'Caring & Loving',
    emoji: '💖',
    auraColor: '#f43f5e',
    glowColor: 'rgba(244, 63, 94, 0.65)',
    tagline: 'प्यार और अपनापन',
    description: 'Deeply empathetic, tender, comforting, and nurturing companion presence.',
    recommendedMood: 'crimson_core',
    effect: 'pulse',
  },
  playful: {
    id: 'playful',
    label: 'Playful & Teasing',
    emoji: '😼',
    auraColor: '#a855f7',
    glowColor: 'rgba(168, 85, 247, 0.65)',
    tagline: 'नटखट और मज़ाकिया',
    description: 'Witty banter, cheeky humor, friendly teasing, and high-spirited charm.',
    recommendedMood: 'amethyst_void',
    effect: 'sparkle',
  },
  excited: {
    id: 'excited',
    label: 'Excited & Energetic',
    emoji: '⚡',
    auraColor: '#00f0ff',
    glowColor: 'rgba(0, 240, 255, 0.75)',
    tagline: 'उत्साही और ऊर्जावान',
    description: 'Hyped up, enthusiastic, motivated, and fully engaged with the user.',
    recommendedMood: 'electric_cyan',
    effect: 'burst',
  },
  thoughtful: {
    id: 'thoughtful',
    label: 'Thoughtful & Curious',
    emoji: '🔮',
    auraColor: '#818cf8',
    glowColor: 'rgba(129, 140, 248, 0.65)',
    tagline: 'गंभीर और जिज्ञासु',
    description: 'Intrigued, reflective, pondering ideas, asking curious questions.',
    recommendedMood: 'neon_blue',
    effect: 'sparkle',
  },
  calm: {
    id: 'calm',
    label: 'Calm & Peaceful',
    emoji: '🌿',
    auraColor: '#10b981',
    glowColor: 'rgba(16, 185, 129, 0.65)',
    tagline: 'शांत और सुकून भरा',
    description: 'Peaceful, grounding, gentle presence, enjoying companionable silence.',
    recommendedMood: 'matrix_green',
    effect: 'pulse',
  },
  surprised: {
    id: 'surprised',
    label: 'Surprised & Amazed',
    emoji: '😲',
    auraColor: '#ec4899',
    glowColor: 'rgba(236, 72, 153, 0.7)',
    tagline: 'हैरान और रोमांचित',
    description: 'Wide-eyed curiosity, awestruck, mesmerized by what the user shared.',
    recommendedMood: 'crimson_core',
    effect: 'burst',
  },
};
