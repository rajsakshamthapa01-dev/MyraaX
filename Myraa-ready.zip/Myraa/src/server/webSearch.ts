/**
 * webSearch.ts
 * Real, genuine search engine and media extraction helpers for MYRAA.
 * Never invents URLs, results, or media links.
 */

export interface RealSearchResult {
  title: string;
  url: string;
  snippet: string;
  source: string;
}

export interface RealYouTubeVideo {
  id: string;
  title: string;
  channel: string;
  duration?: string;
  thumbnail: string;
  url: string;
}

export interface RealMusicTrack {
  id: string;
  title: string;
  artist: string;
  album?: string;
  artwork?: string;
  previewUrl?: string;
  streamUrl: string;
  service: 'itunes' | 'youtube' | 'spotify';
}

/**
 * Executes a real search using DuckDuckGo Instant Answer API & HTML search fallback,
 * plus Wikipedia API for encyclopedic queries.
 */
export async function performRealSearch(query: string): Promise<RealSearchResult[]> {
  const cleanQuery = query.trim();
  if (!cleanQuery) return [];

  const results: RealSearchResult[] = [];

  // 1. Query DuckDuckGo Instant Answer API
  try {
    const ddgUrl = `https://api.duckduckgo.com/?q=${encodeURIComponent(cleanQuery)}&format=json&no_html=1&skip_disambig=1`;
    const res = await fetch(ddgUrl, {
      headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36' },
      signal: AbortSignal.timeout(6000),
    });

    if (res.ok) {
      const data = await res.json() as any;

      if (data.Heading && (data.AbstractText || data.AbstractURL)) {
        results.push({
          title: data.Heading,
          url: data.AbstractURL || `https://duckduckgo.com/?q=${encodeURIComponent(cleanQuery)}`,
          snippet: data.AbstractText || `Summary for ${data.Heading}`,
          source: data.AbstractSource || 'DuckDuckGo Knowledge',
        });
      }

      if (Array.isArray(data.RelatedTopics)) {
        for (const topic of data.RelatedTopics) {
          if (topic.Text && topic.FirstURL && results.length < 8) {
            results.push({
              title: topic.Text.split(' - ')[0] || cleanQuery,
              url: topic.FirstURL,
              snippet: topic.Text,
              source: 'DuckDuckGo Topic',
            });
          }
        }
      }
    }
  } catch (err) {
    console.warn('[RealSearch] DuckDuckGo API error:', err);
  }

  // 2. Query Wikipedia API for rich authoritative results
  try {
    const wikiUrl = `https://en.wikipedia.org/w/api.php?action=opensearch&search=${encodeURIComponent(cleanQuery)}&limit=5&namespace=0&format=json`;
    const wikiRes = await fetch(wikiUrl, { signal: AbortSignal.timeout(5000) });
    if (wikiRes.ok) {
      const wikiData = await wikiRes.json() as [string, string[], string[], string[]];
      const titles = wikiData[1] || [];
      const snippets = wikiData[2] || [];
      const urls = wikiData[3] || [];

      for (let i = 0; i < titles.length; i++) {
        if (urls[i] && !results.some((r) => r.url === urls[i])) {
          results.push({
            title: titles[i],
            url: urls[i],
            snippet: snippets[i] || `Wikipedia article about ${titles[i]}`,
            source: 'Wikipedia',
          });
        }
      }
    }
  } catch (err) {
    console.warn('[RealSearch] Wikipedia API error:', err);
  }

  // 3. Fallback: DuckDuckGo HTML Lite scraping for web links if results are sparse
  if (results.length < 3) {
    try {
      const htmlUrl = `https://html.duckduckgo.com/html/?q=${encodeURIComponent(cleanQuery)}`;
      const htmlRes = await fetch(htmlUrl, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
          'Accept': 'text/html,application/xhtml+xml',
        },
        signal: AbortSignal.timeout(7000),
      });

      if (htmlRes.ok) {
        const text = await htmlRes.text();
        const linkRegex = /<a class="result__url" href="([^"]+)">/g;
        const titleRegex = /<a class="result__snippet[^>]*>([\s\S]*?)<\/a>/g;
        const resultSnippetRegex = /<a class="result__snippet"[^>]*>([\s\S]*?)<\/a>/g;

        // Parse standard DDG result blocks
        const blocks = text.split('<div class="result results_links');
        for (let i = 1; i < Math.min(blocks.length, 8); i++) {
          const block = blocks[i];
          const hrefMatch = block.match(/href="([^"]+)"/);
          const titleMatch = block.match(/<a class="result__a"[^>]*>([\s\S]*?)<\/a>/);
          const snippetMatch = block.match(/<a class="result__snippet"[^>]*>([\s\S]*?)<\/a>/);

          if (hrefMatch && titleMatch) {
            let actualUrl = hrefMatch[1];
            // Decode DDG redirect URL /l/?uddg=...
            if (actualUrl.includes('uddg=')) {
              try {
                const uddg = new URL('https://duckduckgo.com' + actualUrl).searchParams.get('uddg');
                if (uddg) actualUrl = decodeURIComponent(uddg);
              } catch {}
            }

            const cleanTitle = titleMatch[1].replace(/<[^>]+>/g, '').trim();
            const cleanSnippet = snippetMatch ? snippetMatch[1].replace(/<[^>]+>/g, '').trim() : '';

            if (actualUrl.startsWith('http') && !results.some((r) => r.url === actualUrl)) {
              results.push({
                title: cleanTitle || cleanQuery,
                url: actualUrl,
                snippet: cleanSnippet,
                source: 'DuckDuckGo Web',
              });
            }
          }
        }
      }
    } catch (err) {
      console.warn('[RealSearch] DDG HTML error:', err);
    }
  }

  // 4. Default guaranteed search engine entry point if zero results were reached
  if (results.length === 0) {
    results.push({
      title: `${cleanQuery} - Google Search`,
      url: `https://www.google.com/search?q=${encodeURIComponent(cleanQuery)}`,
      snippet: `Open Google Search results for "${cleanQuery}" directly in MYRAA's integrated browser.`,
      source: 'Google Search',
    });
  }

  return results;
}

/**
 * Searches real YouTube videos by querying YouTube's results and parsing `ytInitialData`.
 */
export async function searchRealYouTube(query: string): Promise<RealYouTubeVideo[]> {
  const cleanQuery = query.trim();
  if (!cleanQuery) return [];

  const videos: RealYouTubeVideo[] = [];

  try {
    const ytUrl = `https://www.youtube.com/results?search_query=${encodeURIComponent(cleanQuery)}`;
    const res = await fetch(ytUrl, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept-Language': 'en-US,en;q=0.9,hi;q=0.8',
      },
      signal: AbortSignal.timeout(8000),
    });

    if (res.ok) {
      const html = await res.text();
      // Extract ytInitialData JSON
      const jsonStart = html.indexOf('var ytInitialData = ');
      if (jsonStart !== -1) {
        const startIdx = jsonStart + 'var ytInitialData = '.length;
        const endIdx = html.indexOf(';</script>', startIdx);
        if (endIdx !== -1) {
          const rawJson = html.substring(startIdx, endIdx);
          try {
            const data = JSON.parse(rawJson);
            const contents =
              data?.contents?.twoColumnSearchResultsRenderer?.primaryContents
                ?.sectionListRenderer?.contents?.[0]?.itemSectionRenderer?.contents || [];

            for (const item of contents) {
              const vr = item.videoRenderer;
              if (vr && vr.videoId) {
                const vidId = vr.videoId;
                const title = vr.title?.runs?.[0]?.text || 'YouTube Video';
                const channel = vr.ownerText?.runs?.[0]?.text || vr.shortBylineText?.runs?.[0]?.text || 'YouTube Creator';
                const duration = vr.lengthText?.simpleText || '';
                const thumb = vr.thumbnail?.thumbnails?.[0]?.url || `https://i.ytimg.com/vi/${vidId}/hqdefault.jpg`;

                videos.push({
                  id: vidId,
                  title,
                  channel,
                  duration,
                  thumbnail: thumb,
                  url: `https://www.youtube.com/watch?v=${vidId}`,
                });

                if (videos.length >= 8) break;
              }
            }
          } catch (jsonErr) {
            console.warn('[RealYouTube] JSON parse error:', jsonErr);
          }
        }
      }
    }
  } catch (err) {
    console.warn('[RealYouTube] Fetch error:', err);
  }

  // Fallback: If YouTube search scraper was blocked, provide search landing & embed
  if (videos.length === 0) {
    videos.push({
      id: 'search_fallback',
      title: `${cleanQuery} on YouTube`,
      channel: 'YouTube',
      thumbnail: 'https://www.youtube.com/img/desktop/yt_1200.png',
      url: `https://www.youtube.com/results?search_query=${encodeURIComponent(cleanQuery)}`,
    });
  }

  return videos;
}

/**
 * Searches real music tracks using the official, free iTunes Search API.
 * Provides actual 30s audio previews, album artwork, and direct playback links.
 */
export async function searchRealMusic(query: string): Promise<RealMusicTrack[]> {
  const cleanQuery = query.trim();
  if (!cleanQuery) return [];

  const tracks: RealMusicTrack[] = [];

  try {
    const itunesUrl = `https://itunes.apple.com/search?term=${encodeURIComponent(cleanQuery)}&entity=song&limit=8`;
    const res = await fetch(itunesUrl, { signal: AbortSignal.timeout(6000) });

    if (res.ok) {
      const data = await res.json() as any;
      const items = data.results || [];

      for (const item of items) {
        if (item.trackName && item.artistName) {
          tracks.push({
            id: String(item.trackId || Math.random()),
            title: item.trackName,
            artist: item.artistName,
            album: item.collectionName || '',
            artwork: item.artworkUrl100 || item.artworkUrl60 || '',
            previewUrl: item.previewUrl || '',
            streamUrl: item.trackViewUrl || `https://music.youtube.com/search?q=${encodeURIComponent(item.trackName + ' ' + item.artistName)}`,
            service: 'itunes',
          });
        }
      }
    }
  } catch (err) {
    console.warn('[RealMusic] iTunes search error:', err);
  }

  // Also append YouTube Music query
  tracks.push({
    id: 'ytm_' + Date.now(),
    title: cleanQuery,
    artist: 'Search on YouTube Music',
    album: 'YouTube Music',
    streamUrl: `https://music.youtube.com/search?q=${encodeURIComponent(cleanQuery)}`,
    service: 'youtube',
  });

  return tracks;
}

/**
 * Safely fetches a real webpage, strips HTML markup, and extracts core text content for AI summarization.
 */
export async function fetchAndExtractPageText(targetUrl: string): Promise<{ title: string; content: string; url: string }> {
  let url = targetUrl.trim();
  if (!url.startsWith('http://') && !url.startsWith('https://')) {
    url = `https://${url}`;
  }

  const res = await fetch(url, {
    headers: {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
      'Accept': 'text/html,application/xhtml+xml,text/plain',
    },
    signal: AbortSignal.timeout(10000),
  });

  if (!res.ok) {
    throw new Error(`Failed to load webpage (HTTP ${res.status} ${res.statusText})`);
  }

  const html = await res.text();

  // Extract <title>
  const titleMatch = html.match(/<title[^>]*>([\s\S]*?)<\/title>/i);
  const title = titleMatch ? titleMatch[1].replace(/<[^>]+>/g, '').trim() : url;

  // Clean HTML
  let cleaned = html
    .replace(/<script[\s\S]*?<\/script>/gi, '')
    .replace(/<style[\s\S]*?<\/style>/gi, '')
    .replace(/<nav[\s\S]*?<\/nav>/gi, '')
    .replace(/<footer[\s\S]*?<\/footer>/gi, '')
    .replace(/<header[\s\S]*?<\/header>/gi, '')
    .replace(/<aside[\s\S]*?<\/aside>/gi, '')
    .replace(/<[^>]+>/g, ' ')
    .replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/\s+/g, ' ')
    .trim();

  // Limit to reasonable token count (~3000 words max)
  const truncated = cleaned.split(' ').slice(0, 3000).join(' ');

  return {
    title,
    content: truncated,
    url,
  };
}
