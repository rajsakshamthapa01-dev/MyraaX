/**
 * Types for V.Y.R.O.N — Advanced AI Voice Assistant with Hologram Interface
 */

export type ConnectionState =
  | 'READY'
  | 'LISTENING'
  | 'THINKING'
  | 'SPEAKING'
  | 'BROWSER_ACTIVE'
  | 'DEVICE_CONNECTED'
  | 'DISCONNECTED';

export type AssistantMood = 'electric_cyan' | 'neon_blue' | 'crimson_core' | 'matrix_green' | 'amethyst_void';

export type AssistantEmotion =
  | 'joyful'
  | 'caring'
  | 'playful'
  | 'excited'
  | 'thoughtful'
  | 'calm'
  | 'surprised';

export interface EmotionState {
  current: AssistantEmotion;
  label: string;
  emoji: string;
  auraColor: string;
  glowColor: string;
  tagline: string;
  description: string;
  timestamp: number;
}

export type VoiceName = 'Aoede' | 'Kore' | 'Zephyr' | 'Fenrir' | 'Puck' | 'Charon';

export interface MoodConfig {
  name: AssistantMood;
  label: string;
  primaryColor: string;
  secondaryColor: string;
  glowColor: string;
  accentBg: string;
  borderColor: string;
  hologramHue: string;
  orbGradient?: string;
  coreGlow?: string;
}

export interface MemoryItem {
  id: string;
  category: 'preference' | 'fact' | 'conversation' | 'relationship' | 'goal';
  text: string;
  timestamp: number;
  importance?: 'high' | 'medium' | 'low';
}

export interface BrowserTab {
  id: string;
  url: string;
  title: string;
  favicon?: string;
}

export interface BrowserHistoryItem {
  url: string;
  title: string;
  timestamp: number;
}

export interface BrowserBookmark {
  id: string;
  title: string;
  url: string;
  category?: string;
}

export interface BrowserState {
  isOpen: boolean;
  isMinimized: boolean;
  activeTabId: string;
  tabs: BrowserTab[];
  history: BrowserHistoryItem[];
  bookmarks: BrowserBookmark[];
  isLoading: boolean;
  searchProvider: 'google' | 'duckduckgo' | 'bing' | 'youtube' | 'wikipedia';
}

export interface DeviceTelemetry {
  batteryLevel?: number;
  isCharging?: boolean;
  isOnline: boolean;
  networkType?: string;
  hasTorch: boolean;
  isTorchOn: boolean;
  isScreenLocked: boolean;
}

export interface ActiveTimer {
  id: string;
  label: string;
  durationSeconds: number;
  remainingSeconds: number;
  isRunning: boolean;
}

export interface PCCompanionState {
  isConnected: boolean;
  pairingCode: string;
  deviceName?: string;
  pcIpAddress?: string;
  lastHeartbeat?: number;
  approvedApps: string[];
}

export interface ClientInitConfig {
  voice?: VoiceName;
  mood?: AssistantMood;
  userName?: string;
  language?: 'hi' | 'hi-IN';
  memories?: MemoryItem[];
}

export interface ToolCallData {
  callId: string;
  name: string;
  args: Record<string, any>;
  timestamp: number;
}

export interface ToolExecutionNotification {
  id: string;
  toolName: string;
  summary: string;
  iconName?: string;
  url?: string;
  timestamp: number;
  status?: 'success' | 'warning' | 'error';
}

export interface LatencyMetrics {
  roundTripMs: number;
  lastPingTime: number;
}

export interface CommandRouteResult {
  type: 'CONVERSATION' | 'BROWSER' | 'MOBILE_DEVICE' | 'PC_CONTROL' | 'MEMORY' | 'SYSTEM' | 'MEDIA' | 'SCREEN';
  action: string;
  params: Record<string, any>;
  confirmationRequired?: boolean;
  description: string;
}
