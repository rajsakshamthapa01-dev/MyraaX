/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef, useState, useCallback, useMemo } from 'react';
import {
  AssistantMood,
  AssistantEmotion,
  ConnectionState,
  LatencyMetrics,
  MemoryItem,
  ToolExecutionNotification,
  VoiceName,
} from './types/live';
import { MOODS } from './constants/moods';
import { LiveSession } from './services/LiveSession';
import { InterruptionShieldMode } from './audio/AudioStreamer';
import { memoryCore } from './services/MemoryCore';
import { deviceController } from './services/DeviceController';
import { desktopCompanion } from './services/DesktopCompanion';
import { CommandRouter } from './services/CommandRouter';
import { androidBridge } from './services/AndroidBridge';
import { hindiSpeechService } from './services/HindiSpeechService';
import { HologramCharacter } from './components/HologramCharacter';
import { MinimalVoiceControl } from './components/MinimalVoiceControl';
import { ToolActivityHUD } from './components/ToolActivityHUD';
import { SettingsModal } from './components/SettingsModal';
import { IntegratedBrowser } from './components/IntegratedBrowser';
import { ScreenShareModal } from './components/ScreenShareModal';
import { SparkleEffect } from './components/SparkleEffect';
import { ErrorBoundary } from './components/ErrorBoundary';
import { realBrowser } from './services/RealBrowserService';
import { realMedia } from './services/RealMediaService';
import { geminiTts } from './services/GeminiTtsService';
import { screenShareService } from './services/ScreenShareService';
import { wakeWordService } from './services/WakeWordService';
import {
  Sparkles,
  Settings as SettingsIcon,
  Info,
  Globe,
  Youtube,
  Music,
  Monitor,
} from 'lucide-react';

export default function App() {
  const [connectionState, setConnectionState] = useState<ConnectionState>('DISCONNECTED');
  const [userVolume, setUserVolume] = useState<number>(0);
  const [assistantVolume, setAssistantVolume] = useState<number>(0);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [speakerVolume, setSpeakerVolume] = useState<number>(1.0);
  const [currentMood, setCurrentMood] = useState<AssistantMood>('electric_cyan');
  const [currentVoice, setCurrentVoice] = useState<VoiceName>('Aoede');
  const [latency, setLatency] = useState<LatencyMetrics>({ roundTripMs: 0, lastPingTime: 0 });
  const [notifications, setNotifications] = useState<ToolExecutionNotification[]>([]);
  const [activeEffect, setActiveEffect] = useState<string | null>(null);

  // Settings, Browser & Screen Sharing Panels
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isBrowserOpen, setIsBrowserOpen] = useState(false);
  const [isScreenShareOpen, setIsScreenShareOpen] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isInitializing, setIsInitializing] = useState<boolean>(false);
  const [shieldMode, setShieldMode] = useState<InterruptionShieldMode>('high_protection');
  const [activeModel, setActiveModel] = useState<string>('gemini-3.8-live');
  const [isFallbackModel, setIsFallbackModel] = useState<boolean>(false);
  const [fallbackNotice, setFallbackNotice] = useState<string | undefined>(undefined);
  const [currentEmotion, setCurrentEmotion] = useState<AssistantEmotion>('joyful');

  // Memories
  const [memories, setMemories] = useState<MemoryItem[]>(() => memoryCore.getMemories());

  useEffect(() => {
    const unsubscribe = memoryCore.subscribe((updated) => setMemories(updated));
    return unsubscribe;
  }, []);

  const moodConfig = MOODS[currentMood] || MOODS.electric_cyan;
  const sessionRef = useRef<LiveSession | null>(null);

  const addNotification = useCallback(
    (
      summary: string,
      iconName?: string,
      status: 'success' | 'warning' | 'error' = 'success',
      url?: string
    ) => {
      const notif: ToolExecutionNotification = {
        id: Math.random().toString(36).substring(2, 9),
        toolName: 'Action',
        summary,
        iconName,
        timestamp: Date.now(),
        status,
        url,
      };
      setNotifications((prev) => [notif, ...prev.slice(0, 3)]);
      setTimeout(() => {
        setNotifications((prev) => prev.filter((n) => n.id !== notif.id));
      }, 5000);
    },
    []
  );

  // Initialize LiveSession
  useEffect(() => {
    const session = new LiveSession({
      onStateChange: (state) => {
        setConnectionState(state);
        if (state !== 'DISCONNECTED' && state !== 'READY') {
          setIsInitializing(false);
        }
      },
      onUserVolume: (vol) => setUserVolume(vol),
      onAssistantVolume: (vol) => setAssistantVolume(vol),
      onNotification: (notif) => {
        setNotifications((prev) => [notif, ...prev.slice(0, 3)]);
        setTimeout(() => {
          setNotifications((prev) => prev.filter((n) => n.id !== notif.id));
        }, 5000);
      },
      onMoodChange: (newMood) => setCurrentMood(newMood),
      onEffectTrigger: (effect) => setActiveEffect(effect),
      onOpenBrowser: (url) => {
        realBrowser.navigate(url);
        setIsBrowserOpen(true);
        addNotification(`Opened in Integrated Browser: ${url}`, 'Globe', 'success', url);
      },
      onLatencyChange: (metrics) => setLatency(metrics),
      onError: (err) => {
        setIsInitializing(false);
        setErrorMessage(err);
        setTimeout(() => setErrorMessage(null), 6000);
      },
      onModelChange: (model, isFallback, notice) => {
        setActiveModel(model);
        setIsFallbackModel(isFallback);
        setFallbackNotice(notice);
      },
      onEmotionChange: (emotion) => {
        setCurrentEmotion(emotion);
      },
    });

    sessionRef.current = session;

    return () => {
      session.disconnect();
    };
  }, [addNotification]);

  const handleToggleConnect = useCallback(async () => {
    const session = sessionRef.current;
    if (!session) return;

    if (connectionState === 'DISCONNECTED') {
      setErrorMessage(null);
      setIsInitializing(true);
      try {
        await session.connect({
          voice: currentVoice,
          mood: currentMood,
          language: 'hi',
        });
      } catch (err: any) {
        setIsInitializing(false);
        const msg = err?.message || 'Microphone access denied or connection failed.';
        setErrorMessage(msg);
        addNotification(msg, 'AlertCircle', 'error');
      }
    } else {
      setIsInitializing(false);
      session.disconnect();
      hindiSpeechService.stop();
      geminiTts.stop();
      setIsMuted(false);
      addNotification('MYRAA voice assistant powered off.', 'Power', 'warning');
    }
  }, [connectionState, currentVoice, currentMood, addNotification]);

  const handleTogglePause = useCallback(() => {
    const session = sessionRef.current;
    if (!session || connectionState === 'DISCONNECTED') {
      addNotification('Turn on MYRAA first using the power button or say "Hey Myraa".', 'Power', 'warning');
      return;
    }
    const nextMuted = !isMuted;
    setIsMuted(nextMuted);
    session.setMuted(nextMuted);
    if (nextMuted) {
      session.interrupt();
      hindiSpeechService.stop();
      geminiTts.pause();
      addNotification('Voice interaction paused.', 'Pause', 'warning');
    } else {
      geminiTts.resume();
      addNotification('Voice interaction resumed.', 'Play', 'success');
    }
  }, [isMuted, connectionState, addNotification]);

  // Real Hands-Free Wake Word Service Listener ("Hey Alya", "Wake up Alya")
  useEffect(() => {
    const unsubWake = wakeWordService.onWake((phrase) => {
      addNotification(`Wake word recognized: "${phrase}"`, 'Sparkles', 'success');
      if (connectionState === 'DISCONNECTED') {
        handleToggleConnect();
      } else if (isMuted) {
        handleTogglePause();
      }
    });

    if (wakeWordService.getStatus().isEnabled) {
      wakeWordService.start();
    }

    return () => {
      unsubWake();
    };
  }, [connectionState, isMuted, handleToggleConnect, handleTogglePause, addNotification]);

  const handleStopInteraction = useCallback(() => {
    setIsInitializing(false);
    hindiSpeechService.stop();
    geminiTts.stop();
    if (sessionRef.current) {
      sessionRef.current.disconnect();
    }
    setIsMuted(false);
    setErrorMessage(null);
    addNotification('Voice interaction stopped.', 'X', 'warning');
  }, [addNotification]);

  const handleChangeSpeakerVolume = useCallback((vol: number) => {
    setSpeakerVolume(vol);
    if (sessionRef.current) {
      sessionRef.current.setOutputVolume(vol);
    }
  }, []);

  const handleSelectVoice = useCallback((voice: VoiceName) => {
    setCurrentVoice(voice);
    if (sessionRef.current) {
      sessionRef.current.updateVoice(voice);
    }
  }, []);

  const handleSelectMood = useCallback((mood: AssistantMood) => {
    setCurrentMood(mood);
    if (sessionRef.current) {
      sessionRef.current.updateMood(mood);
    }
  }, []);

  const handleInterrupt = useCallback(() => {
    hindiSpeechService.stop();
    if (sessionRef.current) {
      sessionRef.current.interrupt();
    }
  }, []);

  const handleChangeShieldMode = useCallback(
    (mode: InterruptionShieldMode) => {
      setShieldMode(mode);
      if (sessionRef.current) {
        sessionRef.current.setShieldMode(mode);
      }
      const label = mode === 'high_protection' ? 'High Protection' : mode === 'voice_only' ? 'Voice Only' : 'Balanced';
      addNotification(`Anti-Noise Shield set to ${label}.`, 'ShieldCheck');
    },
    [addNotification]
  );

  const handleSendMessage = useCallback(
    async (text: string) => {
      const lower = text.toLowerCase().trim();
      if (lower === 'settings' || lower === 'config') {
        setIsSettingsOpen(true);
        return;
      }

      const routed = CommandRouter.route(text);

      switch (routed.type) {
        case 'SYSTEM':
          handleInterrupt();
          addNotification('Voice output stopped.', 'VolumeX');
          break;

        case 'SCREEN':
          if (routed.action === 'STOP_SCREEN_SHARE') {
            screenShareService.stopCapture();
            setIsScreenShareOpen(false);
            addNotification('Screen sharing stopped.', 'Square', 'warning');
          } else if (routed.action === 'START_SCREEN_SHARE') {
            setIsScreenShareOpen(true);
            screenShareService.startCapture();
            addNotification('Screen sharing initiated.', 'Monitor', 'success');
          } else if (routed.action === 'ANALYZE_SCREEN') {
            setIsScreenShareOpen(true);
            addNotification('Analyzing screen with Gemini Vision...', 'Sparkles', 'success');
            screenShareService.analyzeScreen(routed.params.query);
          }
          break;

        case 'BROWSER':
          if (routed.action === 'CLOSE_BROWSER') {
            setIsBrowserOpen(false);
            addNotification('Browser closed', 'Globe');
          } else if (routed.action === 'OPEN_BROWSER') {
            setIsBrowserOpen(true);
            addNotification('Integrated Browser opened', 'Globe', 'success');
          } else if (routed.action === 'SUMMARIZE') {
            setIsBrowserOpen(true);
            const activeTab = realBrowser.getActiveTab();
            if (activeTab?.url) {
              addNotification(`Summarizing ${activeTab.title}...`, 'Sparkles');
              realMedia.summarizeWebpage(activeTab.url).then((sum) => {
                geminiTts.speak(`Here is what this page is about: ${sum.summary}`);
                addNotification(`Summary ready: "${sum.title}"`, 'Sparkles', 'success');
              }).catch((e) => {
                addNotification(e.message || 'Summarization failed', 'AlertCircle', 'error');
              });
            }
          } else {
            const url = routed.params.url || 'https://www.google.com';
            realBrowser.navigate(url);
            setIsBrowserOpen(true);
            addNotification(`Navigating in Browser: ${url}`, 'Globe', 'success', url);
          }
          break;

        case 'MEDIA':
          if (routed.action === 'PLAY_YOUTUBE') {
            const query = routed.params.query || 'music';
            addNotification(`Searching YouTube for "${query}"...`, 'Youtube');
            realMedia.searchYouTube(query).then((videos) => {
              if (videos && videos.length > 0) {
                const video = videos[0];
                realMedia.playVideo(video);
                setIsBrowserOpen(true);
                geminiTts.speak(`Playing ${video.title} on YouTube.`);
                addNotification(`Now playing: ${video.title}`, 'Youtube', 'success');
              } else {
                addNotification(`No YouTube videos found for "${query}"`, 'Youtube', 'warning');
                geminiTts.speak(`Could not find YouTube results for ${query}.`);
              }
            }).catch((err) => {
              addNotification(err.message || 'YouTube search failed', 'Youtube', 'error');
            });
          } else if (routed.action === 'PLAY_MUSIC') {
            const query = routed.params.query || 'hits';
            addNotification(`Searching music for "${query}"...`, 'Music');
            realMedia.searchMusic(query).then((tracks) => {
              if (tracks && tracks.length > 0) {
                const track = tracks[0];
                realMedia.playMusic(track);
                setIsBrowserOpen(true);
                geminiTts.speak(`Playing ${track.title} by ${track.artist}.`);
                addNotification(`Playing: ${track.title} - ${track.artist}`, 'Music', 'success');
              } else {
                addNotification(`No music tracks found for "${query}"`, 'Music', 'warning');
                geminiTts.speak(`Could not find music for ${query}.`);
              }
            }).catch((err) => {
              addNotification(err.message || 'Music search failed', 'Music', 'error');
            });
          }
          break;

        case 'MOBILE_DEVICE':
          if (routed.action === 'OPEN_APP') {
            const res = await androidBridge.executeCommand({ action: 'open_app', target: routed.params.app });
            addNotification(
              res.message,
              'Smartphone',
              res.status === 'APP_OPENED' ? 'success' : 'warning',
              res.intentUrl
            );
          } else if (routed.action === 'PRESS_BACK') {
            const res = await androidBridge.executeCommand({ action: 'press_back' });
            addNotification(res.message, 'ArrowLeft', res.status === 'SUCCESS' ? 'success' : 'warning');
          } else if (routed.action === 'PRESS_HOME') {
            const res = await androidBridge.executeCommand({ action: 'press_home' });
            addNotification(res.message, 'Home', res.status === 'SUCCESS' ? 'success' : 'warning');
          } else if (routed.action === 'PRESS_RECENTS') {
            const res = await androidBridge.executeCommand({ action: 'press_recents' });
            addNotification(res.message, 'Layers', res.status === 'SUCCESS' ? 'success' : 'warning');
          } else if (routed.action === 'OPEN_NOTIFICATIONS') {
            const res = await androidBridge.executeCommand({ action: 'open_notifications' });
            addNotification(res.message, 'Bell', res.status === 'SUCCESS' ? 'success' : 'warning');
          } else if (routed.action === 'OPEN_QUICK_SETTINGS') {
            const res = await androidBridge.executeCommand({ action: 'open_quick_settings' });
            addNotification(res.message, 'Sliders', res.status === 'SUCCESS' ? 'success' : 'warning');
          } else if (routed.action === 'LOCK_SCREEN') {
            const res = await androidBridge.executeCommand({ action: 'lock_screen' });
            addNotification(res.message, 'Lock', res.status === 'SUCCESS' ? 'success' : 'warning');
          } else if (routed.action === 'TAKE_SCREENSHOT') {
            const res = await androidBridge.executeCommand({ action: 'take_screenshot' });
            addNotification(res.message, 'Camera', res.status === 'SUCCESS' ? 'success' : 'warning');
          } else if (routed.action === 'SCROLL') {
            const res = await androidBridge.executeCommand({ action: 'scroll', direction: routed.params.direction });
            addNotification(res.message, 'Smartphone', res.status === 'SUCCESS' ? 'success' : 'warning');
          } else if (routed.action === 'TOGGLE_TORCH') {
            const res = await androidBridge.executeCommand({ action: 'toggle_torch' });
            addNotification(res.message, 'Flashlight', res.status === 'SUCCESS' ? 'success' : 'warning');
          } else if (routed.action === 'OPEN_DIALER') {
            const res = await androidBridge.executeCommand({ action: 'open_dialer', number: routed.params.number });
            addNotification(res.message, 'Phone');
          } else if (routed.action === 'OPEN_SETTINGS') {
            const res = await androidBridge.executeCommand({ action: 'open_settings' });
            addNotification(res.message, 'Settings');
          } else if (routed.action === 'SET_TIMER') {
            deviceController.setTimer(routed.params.minutes, routed.params.label);
            addNotification(`Timer set for ${routed.params.minutes} minutes.`, 'Timer');
          }
          break;

        case 'PC_CONTROL':
          desktopCompanion
            .executeCommand(routed.action, { ...routed.params, simulate: true })
            .then((r) => {
              addNotification(r.message, 'Monitor');
            });
          break;

        case 'MEMORY':
          if (routed.action === 'SAVE_MEMORY') {
            memoryCore.addMemory(routed.params.text, 'fact', 'high');
            addNotification(
              `Memory saved: "${routed.params.text.substring(0, 24)}..."`,
              'Brain'
            );
          } else {
            setIsSettingsOpen(true);
          }
          break;

        case 'CONVERSATION':
        default:
          if (sessionRef.current && connectionState !== 'DISCONNECTED') {
            sessionRef.current.sendText(text);
            addNotification(`Sent: "${text}"`, 'MessageSquare');
          } else {
            handleToggleConnect();
            setTimeout(() => {
              if (sessionRef.current) {
                sessionRef.current.sendText(text);
              }
            }, 1200);
          }
          break;
      }
    },
    [connectionState, handleInterrupt, addNotification, handleToggleConnect]
  );

  const handleDismissNotification = useCallback((id: string) => {
    setNotifications((prev) => prev.filter((n) => n.id !== id));
  }, []);

  const displayState = useMemo(() => {
    switch (connectionState) {
      case 'READY':
        return {
          label: 'READY',
          color: 'text-cyan-400 bg-cyan-500/15 border-cyan-400/40',
        };
      case 'LISTENING':
        return {
          label: 'LISTENING...',
          color: 'text-emerald-300 bg-emerald-500/20 border-emerald-400/60 animate-pulse',
        };
      case 'THINKING':
        return {
          label: 'THINKING...',
          color: 'text-amber-300 bg-amber-500/20 border-amber-400/60 animate-pulse',
        };
      case 'SPEAKING':
        return {
          label: 'SPEAKING...',
          color:
            'text-cyan-200 bg-cyan-500/25 border-cyan-300/80 shadow-[0_0_15px_rgba(0,240,255,0.4)] animate-pulse',
        };
      case 'DISCONNECTED':
      default:
        return {
          label: 'READY',
          color: 'text-zinc-400 bg-zinc-900/80 border-zinc-700/60',
        };
    }
  }, [connectionState]);

  return (
    <div className="relative min-h-screen w-full bg-[#020612] text-white flex flex-col justify-between overflow-hidden font-sans select-none">
      {/* 1. FULL-SCREEN ANIME HOLOGRAM BACKGROUND (Character fills screen, subtle particles, tap anywhere to talk) */}
      <ErrorBoundary fallbackName="MYRAA Hologram Visualizer">
        <HologramCharacter
          state={connectionState}
          userVolume={userVolume}
          assistantVolume={assistantVolume}
          mood={moodConfig}
          emotion={currentEmotion}
          isMuted={isMuted}
          onToggleConnect={handleToggleConnect}
          onInterrupt={handleInterrupt}
        />
      </ErrorBoundary>

      {/* Particle Effect Layer */}
      <SparkleEffect effect={activeEffect} onComplete={() => setActiveEffect(null)} />

      {/* Action Notification HUD */}
      <ToolActivityHUD
        notifications={notifications}
        onDismiss={handleDismissNotification}
      />

      {/* 2. MINIMAL FUTURISTIC TOP STATUS BAR */}
      <header className="relative z-30 w-full px-4 sm:px-6 py-3 flex items-center justify-between backdrop-blur-md bg-zinc-950/30 border-b border-cyan-500/20">
        {/* Left: ALYA Branding & Online Status Indicator */}
        <div className="flex items-center space-x-2.5">
          <div className="w-8 h-8 rounded-xl flex items-center justify-center bg-cyan-500/20 border border-cyan-400/40 shadow-[0_0_12px_rgba(0,240,255,0.3)]">
            <Sparkles className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="flex flex-col">
            <div className="flex items-center space-x-2">
              <span className="text-base font-bold font-mono tracking-widest text-white">
                MYRAA
              </span>
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
              <span
                className={`px-2 py-0.5 text-[10px] font-mono font-semibold rounded-full border whitespace-nowrap ${displayState.color}`}
              >
                {displayState.label}
              </span>
            </div>
          </div>
        </div>

        {/* Center: Compact Status Info */}
        <div className="hidden sm:flex items-center space-x-2 px-3 py-1 rounded-full bg-zinc-950/60 border border-zinc-800 text-[11px] font-mono text-cyan-300">
          <span>MYRAA AI • {activeModel} • Hands-Free & Vision Ready</span>
        </div>

        {/* Right: Screen Share, Browser & Settings Icons */}
        <div className="flex items-center space-x-2">
          <button
            type="button"
            onClick={() => setIsScreenShareOpen(true)}
            className="p-2.5 rounded-2xl bg-zinc-900/70 hover:bg-zinc-800 border border-zinc-700/70 hover:border-cyan-400/80 text-zinc-300 hover:text-cyan-300 backdrop-blur-md transition-all shadow-md active:scale-95 flex items-center space-x-1.5"
            title="MYRAA Real Screen Sharing & Visual Understanding"
          >
            <Monitor className="w-4 h-4 text-cyan-400" />
            <span className="hidden sm:inline text-xs font-mono font-medium">Screen</span>
          </button>

          <button
            type="button"
            onClick={() => setIsBrowserOpen(true)}
            className="p-2.5 rounded-2xl bg-zinc-900/70 hover:bg-zinc-800 border border-zinc-700/70 hover:border-cyan-400/80 text-zinc-300 hover:text-cyan-300 backdrop-blur-md transition-all shadow-md active:scale-95 flex items-center space-x-1.5"
            title="Open MYRAA Real Browser, Web Search & YouTube"
          >
            <Globe className="w-4 h-4 text-cyan-400" />
            <span className="hidden sm:inline text-xs font-mono font-medium">Browser</span>
          </button>

          <button
            type="button"
            onClick={() => setIsSettingsOpen(true)}
            className="p-2.5 rounded-2xl bg-zinc-900/70 hover:bg-zinc-800 border border-zinc-700/70 hover:border-cyan-400/80 text-zinc-300 hover:text-cyan-300 backdrop-blur-md transition-all shadow-md active:scale-95"
            title="MYRAA Settings, Android Digital Assistant & Wake Word"
          >
            <SettingsIcon className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* Error Notice */}
      {errorMessage && (
        <div className="relative z-40 mx-auto mt-2 px-4 py-1.5 rounded-2xl bg-red-500/20 border border-red-500/50 text-red-200 text-xs flex items-center space-x-2 animate-in fade-in">
          <Info className="w-4 h-4 text-red-400 flex-shrink-0" />
          <span>{errorMessage}</span>
        </div>
      )}

      {/* 3. CENTER BREATHING SPACE: Unobstructed Anime Character Hologram */}
      <main className="relative z-10 flex-1 flex flex-col justify-end items-center px-4 py-2 w-full max-w-xl mx-auto pointer-events-none" />

      {/* 4. REAL HARDWARE-INSPIRED VOICE CONTROL PANEL (Inspired by reference photo) */}
      <footer className="relative z-30 w-full">
        <MinimalVoiceControl
          state={connectionState}
          userVolume={userVolume}
          assistantVolume={assistantVolume}
          mood={moodConfig}
          isMuted={isMuted}
          isInitializing={isInitializing}
          errorMessage={errorMessage}
          onToggleConnect={handleToggleConnect}
          onTogglePause={handleTogglePause}
          onInterrupt={handleInterrupt}
          onStop={handleStopInteraction}
          onOpenSettings={() => setIsSettingsOpen(true)}
          onClearError={() => setErrorMessage(null)}
          onQuickPrompt={handleSendMessage}
        />
      </footer>

      {/* Real Screen Sharing & Visual Understanding Modal */}
      <ErrorBoundary fallbackName="Screen Sharing Module">
        <ScreenShareModal
          isOpen={isScreenShareOpen}
          onClose={() => setIsScreenShareOpen(false)}
          onNotification={(msg, icon, status) => addNotification(msg, icon, status)}
        />
      </ErrorBoundary>

      {/* Real Integrated Browser Modal (Tabs, Address Bar, Real Web Search, YouTube, Music, AI Summarizer) */}
      <ErrorBoundary fallbackName="Integrated Browser Engine">
        <IntegratedBrowser
          isOpen={isBrowserOpen}
          onClose={() => setIsBrowserOpen(false)}
          onNotification={(msg, icon, status) => addNotification(msg, icon, status)}
        />
      </ErrorBoundary>

      {/* Comprehensive Settings Modal (Relocated Android Controls, AI Config, Voice, Memories, PC Companion) */}
      <ErrorBoundary fallbackName="Settings & Controls">
        <SettingsModal
          isOpen={isSettingsOpen}
          onClose={() => setIsSettingsOpen(false)}
          currentVoice={currentVoice}
          onSelectVoice={handleSelectVoice}
          currentMood={currentMood}
          onSelectMood={handleSelectMood}
          volume={speakerVolume}
          onChangeVolume={handleChangeSpeakerVolume}
          shieldMode={shieldMode}
          onChangeShieldMode={handleChangeShieldMode}
          memories={memories}
          onAddMemory={(text, cat) => memoryCore.addMemory(text, cat, 'high')}
          onClearMemories={() => memoryCore.clearAllMemories()}
          onNotification={(msg, icon, status) => addNotification(msg, icon, status)}
          activeModel={activeModel}
          isFallbackModel={isFallbackModel}
          fallbackNotice={fallbackNotice}
          onSendMessage={handleSendMessage}
        />
      </ErrorBoundary>
    </div>
  );
}
