import React, { useState } from 'react';
import { MemoryItem } from '../types/live';
import { memoryCore } from '../services/MemoryCore';
import {
  Brain,
  X,
  Plus,
  Trash2,
  Search,
  Sparkles,
  Database,
  CheckCircle2,
  RotateCcw,
  Tag,
} from 'lucide-react';

interface MemoryCoreModalProps {
  isOpen: boolean;
  onClose: () => void;
  memories: MemoryItem[];
}

export const MemoryCoreModal: React.FC<MemoryCoreModalProps> = ({
  isOpen,
  onClose,
  memories,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [newMemoryText, setNewMemoryText] = useState('');
  const [newCategory, setNewCategory] = useState<MemoryItem['category']>('preference');
  const [isAdding, setIsAdding] = useState(false);

  if (!isOpen) return null;

  const filtered = memories.filter(
    (m) =>
      m.text.toLowerCase().includes(searchQuery.toLowerCase()) ||
      m.category.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMemoryText.trim()) return;
    memoryCore.addMemory(newMemoryText, newCategory, 'high');
    setNewMemoryText('');
    setIsAdding(false);
  };

  const handleDelete = (id: string) => {
    memoryCore.removeMemory(id);
  };

  const handleReset = () => {
    if (window.confirm('Reset Memory Core to default memories?')) {
      memoryCore.resetToDefaults();
    }
  };

  const getCategoryColor = (cat: MemoryItem['category']) => {
    switch (cat) {
      case 'preference':
        return 'bg-purple-500/20 text-purple-300 border-purple-500/40';
      case 'relationship':
        return 'bg-red-500/20 text-red-300 border-red-500/40';
      case 'fact':
        return 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40';
      case 'goal':
        return 'bg-amber-500/20 text-amber-300 border-amber-500/40';
      default:
        return 'bg-zinc-800 text-zinc-300 border-zinc-700';
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div
        className="relative w-full max-w-xl max-h-[85vh] flex flex-col rounded-3xl bg-zinc-950 border-2 border-red-500/50 shadow-[0_0_60px_rgba(255,34,71,0.25)] overflow-hidden text-white"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-zinc-800/80 bg-zinc-900/60">
          <div className="flex items-center space-x-3">
            <div className="p-2.5 rounded-2xl bg-red-500/15 border border-red-500/30 text-red-400 shadow-[0_0_15px_rgba(255,34,71,0.3)]">
              <Brain className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h2 className="text-base font-bold tracking-wide">VYRON NEURAL MEMORY CORE</h2>
                <span className="px-2 py-0.5 rounded-full bg-red-500/10 text-red-400 border border-red-500/30 text-[10px] font-mono">
                  Active
                </span>
              </div>
              <p className="text-xs text-zinc-400 font-mono">
                Persistent Long-Term Memory Synapses ({memories.length} Nodes)
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search & Actions Bar */}
        <div className="px-6 py-3 border-b border-zinc-800/60 flex items-center justify-between gap-3 bg-zinc-900/30">
          <div className="relative flex-1">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search recollections..."
              className="w-full pl-9 pr-3 py-1.5 rounded-xl bg-zinc-900/80 border border-zinc-800 text-xs text-white placeholder-zinc-500 font-mono focus:outline-none focus:border-red-500/60"
            />
          </div>

          <button
            onClick={() => setIsAdding(!isAdding)}
            className="flex items-center space-x-1.5 px-3 py-1.5 rounded-xl bg-red-600/80 hover:bg-red-500 text-xs font-medium text-white transition-colors"
          >
            <Plus className="w-4 h-4" />
            <span>Add Memory</span>
          </button>

          <button
            onClick={handleReset}
            className="p-1.5 rounded-xl text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800 transition-colors"
            title="Reset to defaults"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>

        {/* Add Memory Form Tray */}
        {isAdding && (
          <form onSubmit={handleAdd} className="px-6 py-3 border-b border-zinc-800 bg-red-950/20 space-y-2">
            <input
              type="text"
              value={newMemoryText}
              onChange={(e) => setNewMemoryText(e.target.value)}
              placeholder="E.g., User loves cyberpunk movies and works as a fullstack engineer..."
              className="w-full px-3 py-2 rounded-xl bg-zinc-900 border border-zinc-700 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-red-500"
              autoFocus
            />
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Tag className="w-3.5 h-3.5 text-zinc-400" />
                <select
                  value={newCategory}
                  onChange={(e) => setNewCategory(e.target.value as any)}
                  className="px-2 py-1 rounded-lg bg-zinc-900 border border-zinc-700 text-xs text-zinc-300"
                >
                  <option value="preference">Preference</option>
                  <option value="fact">Fact</option>
                  <option value="relationship">Relationship</option>
                  <option value="conversation">Conversation</option>
                  <option value="goal">Goal</option>
                </select>
              </div>
              <div className="flex items-center space-x-2">
                <button
                  type="button"
                  onClick={() => setIsAdding(false)}
                  className="px-2.5 py-1 text-xs text-zinc-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-3 py-1 rounded-lg bg-red-600 text-xs font-medium text-white hover:bg-red-500"
                >
                  Save to Core
                </button>
              </div>
            </div>
          </form>
        )}

        {/* Memory List Container */}
        <div className="flex-1 overflow-y-auto p-6 space-y-2.5">
          {filtered.length === 0 ? (
            <div className="py-12 flex flex-col items-center justify-center text-center space-y-2 text-zinc-500">
              <Database className="w-8 h-8 opacity-40" />
              <p className="text-xs font-mono">No matching memory nodes in storage.</p>
            </div>
          ) : (
            filtered.map((item) => (
              <div
                key={item.id}
                className="group p-3.5 rounded-2xl bg-zinc-900/60 border border-zinc-800/80 hover:border-red-500/40 transition-all flex items-start justify-between gap-3 shadow-md"
              >
                <div className="space-y-1.5 flex-1">
                  <div className="flex items-center space-x-2">
                    <span
                      className={`px-2 py-0.5 rounded-md text-[10px] font-mono uppercase tracking-wider border ${getCategoryColor(
                        item.category
                      )}`}
                    >
                      {item.category}
                    </span>
                    <span className="text-[10px] font-mono text-zinc-500">
                      {new Date(item.timestamp).toLocaleDateString([], {
                        month: 'short',
                        day: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </span>
                  </div>
                  <p className="text-xs text-zinc-200 leading-relaxed font-light">{item.text}</p>
                </div>

                <button
                  onClick={() => handleDelete(item.id)}
                  className="opacity-0 group-hover:opacity-100 p-1.5 rounded-lg text-zinc-500 hover:text-red-400 hover:bg-zinc-800 transition-all"
                  title="Erase memory"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))
          )}
        </div>

        {/* Footer Info */}
        <div className="px-6 py-3 bg-zinc-900/70 border-t border-zinc-800/80 flex items-center justify-between text-[11px] font-mono text-zinc-400">
          <div className="flex items-center space-x-1.5">
            <CheckCircle2 className="w-3.5 h-3.5 text-red-400" />
            <span>Injected into every live session</span>
          </div>
          <span className="text-zinc-500">Local Neural Cache • 100% Private</span>
        </div>
      </div>
    </div>
  );
};
