import React, { useEffect, useRef } from 'react';
import { ConnectionState, MoodConfig } from '../types/live';

interface WaveformBarProps {
  state: ConnectionState;
  userVolume: number;
  assistantVolume: number;
  mood: MoodConfig;
}

export const WaveformBar: React.FC<WaveformBarProps> = ({
  state,
  userVolume,
  assistantVolume,
  mood,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const phaseRef = useRef<number>(0);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;

    const render = () => {
      const width = canvas.width;
      const height = canvas.height;
      ctx.clearRect(0, 0, width, height);

      const isSpeaking = state === 'SPEAKING';
      const isListening = state === 'LISTENING';
      const isDisconnected = state === 'DISCONNECTED';

      const activeVol = isSpeaking ? assistantVolume : isListening ? userVolume : 0;
      phaseRef.current += isDisconnected ? 0.015 : 0.05 + activeVol * 0.12;

      const numBars = 36;
      const barWidth = 3;
      const gap = (width - numBars * barWidth) / (numBars - 1);
      const centerY = height / 2;

      // Draw mirrored harmonic bars
      for (let i = 0; i < numBars; i++) {
        const x = i * (barWidth + gap);
        const norm = i / (numBars - 1);
        const envelope = Math.sin(norm * Math.PI);

        let amplitude: number;
        if (isDisconnected) {
          amplitude = (Math.sin(phaseRef.current * 1.5 + i * 0.3) * 0.5 + 0.5) * 6 * envelope + 2;
        } else if (state === 'READY' || state === 'THINKING') {
          amplitude = (Math.sin(phaseRef.current * 3 + i * 0.5) * 0.5 + 0.5) * 16 * envelope + 4;
        } else {
          const harmonic1 = Math.sin(phaseRef.current * 2 + i * 0.35);
          const harmonic2 = Math.cos(phaseRef.current * 3 - i * 0.2);
          const wave = Math.abs(harmonic1 * 0.6 + harmonic2 * 0.4);
          amplitude = (wave * (activeVol * 42 + 4)) * envelope + 3;
        }

        const barHeight = Math.max(3, Math.min(height - 4, amplitude));
        const yTop = centerY - barHeight / 2;

        const gradient = ctx.createLinearGradient(0, yTop, 0, yTop + barHeight);
        if (isSpeaking) {
          gradient.addColorStop(0, '#ffffff');
          gradient.addColorStop(0.5, mood.primaryColor);
          gradient.addColorStop(1, mood.secondaryColor);
        } else if (isListening) {
          gradient.addColorStop(0, '#a5f3fc');
          gradient.addColorStop(0.5, '#00f0ff');
          gradient.addColorStop(1, '#0e7490');
        } else {
          gradient.addColorStop(0, '#38bdf8');
          gradient.addColorStop(1, '#0f172a');
        }

        ctx.fillStyle = gradient;
        ctx.beginPath();
        ctx.roundRect(x, yTop, barWidth, barHeight, 2);
        ctx.fill();
      }

      animId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animId);
    };
  }, [state, userVolume, assistantVolume, mood]);

  const isSpeaking = state === 'SPEAKING';
  const isListening = state === 'LISTENING';

  return (
    <div className="w-full flex flex-col items-center justify-center py-1 px-4">
      <div className="relative w-full max-w-xs h-14 flex items-center justify-center">
        <canvas
          ref={canvasRef}
          width={280}
          height={56}
          className="w-full h-full max-w-[280px]"
        />
      </div>
      <div className="flex items-center space-x-2 text-[10px] font-mono tracking-wider text-zinc-500">
        <span>AUDIO STREAM</span>
        <span>•</span>
        <span
          className={
            isSpeaking
              ? 'text-cyan-300 font-bold'
              : isListening
              ? 'text-emerald-400 font-bold'
              : 'text-zinc-500'
          }
        >
          {isSpeaking
            ? 'MYRAA HINDI VOICE (24kHz)'
            : isListening
            ? 'MIC INPUT (16kHz PCM)'
            : 'READY'}
        </span>
      </div>
    </div>
  );
};
