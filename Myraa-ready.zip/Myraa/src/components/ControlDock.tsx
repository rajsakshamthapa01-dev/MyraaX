import React from 'react';
import { ConnectionState, MoodConfig } from '../types/live';
import {
  Smartphone,
  Monitor,
  Brain,
  Power,
  Zap,
} from 'lucide-react';

interface ControlDockProps {
  state: ConnectionState;
  isMuted: boolean;
  volume: number;
  mood: MoodConfig;
  roundTripMs: number;
  memoryCount: number;
  isBrowserOpen?: boolean;
  onToggleConnect: () => void;
  onToggleMute: () => void;
  onChangeVolume: (vol: number) => void;
  onOpenSettings?: () => void;
  onOpenMemoryCore: () => void;
  onToggleBrowser?: () => void;
  onOpenMobileControls: () => void;
  onOpenPCControls: () => void;
  onQuickPrompt?: (prompt: string) => void;
}

export const ControlDock: React.FC<ControlDockProps> = ({
  state,
  roundTripMs,
  memoryCount,
  onToggleConnect,
  onOpenMemoryCore,
  onOpenMobileControls,
  onOpenPCControls,
  onQuickPrompt,
}) => {
  const isConnected = state !== 'DISCONNECTED';

  // Quick Action Prompts for Android apps & features (English only)
  const quickActionPrompts = [
    'Open YouTube',
    'Open Instagram',
    'Open WhatsApp',
    'Open Maps',
    'Turn On Torch',
    'Set 5 Min Timer',
    'Talk to Me',
  ];

  return (
    <div className="w-full max-w-xl mx-auto flex flex-col items-center space-y-2.5 px-4 pb-4 select-none">
      {/* Quick Action Suggestion Bar (English Only) */}
      <div className="w-full flex items-center justify-center overflow-x-auto no-scrollbar py-0.5 space-x-2">
        {quickActionPrompts.map((promptText, idx) => (
          <button
            key={idx}
            type="button"
            onClick={() => onQuickPrompt?.(promptText)}
            className="flex-shrink-0 px-3 py-1 rounded-full bg-black/60 hover:bg-zinc-900 border border-cyan-500/25 hover:border-cyan-400 text-[11px] text-cyan-300 font-mono backdrop-blur-md shadow-sm transition-all"
          >
            {promptText}
          </button>
        ))}
      </div>

      {/* Main Minimal Futuristic Capsule Bar (NO Mic Icon, NO Settings Icon, In-App Browser removed) */}
      <div className="w-full flex items-center justify-between px-3 sm:px-5 py-2.5 rounded-2xl bg-zinc-950/85 border border-cyan-500/40 shadow-[0_0_30px_rgba(0,240,255,0.25)] backdrop-blur-xl">
        {/* Left Tool: Mobile Controls & Android Apps */}
        <div className="flex items-center space-x-2">
          <button
            type="button"
            onClick={onOpenMobileControls}
            className="px-3 py-2 rounded-xl text-xs font-mono bg-zinc-900/80 text-zinc-300 hover:text-cyan-300 hover:bg-zinc-800 border border-zinc-700/60 transition-colors flex items-center space-x-1.5"
            title="Mobile Controls & Android Apps"
          >
            <Smartphone className="w-4 h-4 text-cyan-400" />
            <span className="hidden sm:inline">Mobile</span>
          </button>
        </div>

        {/* Center: Main Hologram Status & Voice Interaction Action Capsule */}
        <button
          type="button"
          onClick={onToggleConnect}
          className={`flex-1 mx-2 sm:mx-4 px-4 py-2.5 rounded-xl font-mono text-xs font-bold tracking-wider flex items-center justify-center space-x-2 transition-all duration-300 shadow-lg active:scale-95 ${
            state === 'DISCONNECTED'
              ? 'bg-gradient-to-r from-cyan-500 via-blue-600 to-cyan-500 hover:from-cyan-400 hover:to-blue-500 text-black font-extrabold shadow-cyan-500/40 border border-cyan-300/80'
              : state === 'SPEAKING'
              ? 'bg-cyan-500/20 text-cyan-200 border border-cyan-400/80 shadow-[0_0_20px_rgba(0,240,255,0.4)] animate-pulse'
              : state === 'LISTENING'
              ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-400/80 shadow-[0_0_20px_rgba(16,185,129,0.4)]'
              : state === 'THINKING'
              ? 'bg-amber-500/20 text-amber-300 border border-amber-400/80 animate-pulse'
              : 'bg-zinc-900 hover:bg-zinc-800 text-cyan-300 border border-cyan-500/50'
          }`}
          title={isConnected ? 'Tap: Stop Speaking / Disconnect' : 'Tap: Talk to Me'}
        >
          <Power className={`w-3.5 h-3.5 ${state === 'DISCONNECTED' ? 'text-black' : 'text-cyan-400'}`} />
          <span className="truncate">
            {state === 'DISCONNECTED'
              ? 'Talk to Me'
              : state === 'LISTENING'
              ? 'LISTENING...'
              : state === 'THINKING'
              ? 'THINKING...'
              : state === 'SPEAKING'
              ? 'SPEAKING... (Stop)'
              : 'LIVE'}
          </span>
        </button>

        {/* Right Tools: PC Companion Link & Neural Memory Core */}
        <div className="flex items-center space-x-2">
          {/* PC Companion Link Trigger */}
          <button
            type="button"
            onClick={onOpenPCControls}
            className="px-3 py-2 rounded-xl text-xs font-mono bg-zinc-900/80 text-zinc-300 hover:text-blue-400 hover:bg-zinc-800 border border-zinc-700/60 transition-colors flex items-center space-x-1.5"
            title="PC Companion"
          >
            <Monitor className="w-4 h-4 text-blue-400" />
            <span className="hidden sm:inline">PC Link</span>
          </button>

          {/* Neural Memory Core Trigger */}
          <button
            type="button"
            onClick={onOpenMemoryCore}
            className="relative px-3 py-2 rounded-xl text-xs font-mono bg-zinc-900/80 text-zinc-300 hover:text-cyan-300 hover:bg-zinc-800 border border-zinc-700/60 transition-colors flex items-center space-x-1.5"
            title="Memories"
          >
            <Brain className="w-4 h-4 text-cyan-400" />
            <span className="hidden sm:inline">Memories</span>
            {memoryCount > 0 && (
              <span className="px-1.5 py-0.2 rounded-full bg-cyan-600 text-[10px] font-mono text-white font-bold border border-black shadow">
                {memoryCount}
              </span>
            )}
          </button>
        </div>
      </div>

      {/* Futuristic Telemetry Status Indicator (English Only) */}
      <div className="flex items-center space-x-3 text-[10px] font-mono text-zinc-400">
        <div className="flex items-center space-x-1">
          <Zap className="w-3 h-3 text-cyan-400" />
          <span>{isConnected ? `${roundTripMs || 20}ms` : 'Offline'}</span>
        </div>
        <span>•</span>
        <span className="text-cyan-400 font-bold">Voice-to-Voice AI • Spoken Hindi</span>
        <span>•</span>
        <span className="text-zinc-500">Tap anywhere to speak</span>
      </div>
    </div>
  );
};
