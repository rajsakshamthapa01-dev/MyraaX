import React, { useState, useEffect } from 'react';
import {
  deviceController,
  DeviceTelemetry,
  ActiveTimer,
} from '../services/DeviceController';
import {
  Smartphone,
  X,
  Battery,
  BatteryCharging,
  Wifi,
  WifiOff,
  Flashlight,
  Timer,
  Lock,
  Unlock,
  Vibrate,
  MessageCircle,
  Video,
  Navigation,
  Phone,
  Camera,
  Settings,
  Bell,
  Trash2,
  Globe,
  Share2,
} from 'lucide-react';

interface DeviceControlPanelProps {
  isOpen: boolean;
  onClose: () => void;
  onNotification?: (msg: string) => void;
}

export const DeviceControlPanel: React.FC<DeviceControlPanelProps> = ({
  isOpen,
  onClose,
  onNotification,
}) => {
  const [telemetry, setTelemetry] = useState<DeviceTelemetry>(() =>
    deviceController.getTelemetry()
  );
  const [timers, setTimers] = useState<ActiveTimer[]>([]);
  const [timerMinutes, setTimerMinutes] = useState('5');
  const [timerLabel, setTimerLabel] = useState('Timer');

  useEffect(() => {
    const unsub = deviceController.subscribe((data) => setTelemetry(data));
    const interval = setInterval(() => {
      setTimers(deviceController.getActiveTimers());
    }, 1000);
    return () => {
      unsub();
      clearInterval(interval);
    };
  }, []);

  if (!isOpen) return null;

  const handleToggleTorch = async () => {
    const res = await deviceController.toggleTorch();
    onNotification?.(res.message);
  };

  const handleSetTimer = (e: React.FormEvent) => {
    e.preventDefault();
    const mins = parseFloat(timerMinutes) || 5;
    deviceController.setTimer(mins, timerLabel || 'Timer');
    onNotification?.(`Timer set for ${mins} minutes.`);
  };

  const handleCancelTimer = (id: string) => {
    deviceController.cancelTimer(id);
    setTimers(deviceController.getActiveTimers());
  };

  const handleOpenApp = (appName: string) => {
    const res = deviceController.openApp(appName);
    onNotification?.(res.message);
  };

  const handleVibrate = () => {
    deviceController.vibrate([100, 50, 100]);
    onNotification?.('Vibration triggered.');
  };

  const handleToggleWakeLock = async () => {
    const nextState = !telemetry.isScreenLocked;
    const ok = await deviceController.toggleWakeLock(nextState);
    if (ok) {
      onNotification?.(
        nextState ? 'Screen wake-lock activated.' : 'Screen wake-lock released.'
      );
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div
        className="relative w-full max-w-xl max-h-[88vh] flex flex-col rounded-3xl bg-zinc-950 border-2 border-cyan-500/50 shadow-[0_0_50px_rgba(0,240,255,0.25)] text-white overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-zinc-800 bg-zinc-900/60">
          <div className="flex items-center space-x-3">
            <div className="p-2.5 rounded-2xl bg-cyan-500/15 text-cyan-400 border border-cyan-500/40 shadow-[0_0_12px_rgba(0,240,255,0.3)]">
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h2 className="text-base font-bold font-mono tracking-wider">
                  MYRAA MOBILE CONTROLLER
                </h2>
                <span className="px-2 py-0.5 rounded-full bg-cyan-500/10 text-cyan-300 border border-cyan-500/30 text-[10px] font-mono">
                  Android & Web
                </span>
              </div>
              <p className="text-xs text-zinc-400 font-mono">
                Device Controls & Installed Android Apps Hub
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* Section 1: Device Telemetry Overview */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
            <div className="p-3 rounded-2xl bg-zinc-900/60 border border-zinc-800 flex items-center space-x-2.5">
              {telemetry.isCharging ? (
                <BatteryCharging className="w-5 h-5 text-emerald-400" />
              ) : (
                <Battery className="w-5 h-5 text-cyan-400" />
              )}
              <div className="flex flex-col">
                <span className="text-[10px] font-mono text-zinc-500">BATTERY</span>
                <span className="text-xs font-mono font-bold text-white">
                  {telemetry.batteryLevel !== undefined
                    ? `${telemetry.batteryLevel}%`
                    : 'Standard'}
                </span>
              </div>
            </div>

            <div className="p-3 rounded-2xl bg-zinc-900/60 border border-zinc-800 flex items-center space-x-2.5">
              {telemetry.isOnline ? (
                <Wifi className="w-5 h-5 text-emerald-400" />
              ) : (
                <WifiOff className="w-5 h-5 text-red-400" />
              )}
              <div className="flex flex-col">
                <span className="text-[10px] font-mono text-zinc-500">NETWORK</span>
                <span className="text-xs font-mono font-bold text-white">
                  {telemetry.isOnline ? 'ONLINE' : 'OFFLINE'}
                </span>
              </div>
            </div>

            <button
              onClick={handleToggleTorch}
              className={`p-3 rounded-2xl border transition-all flex items-center space-x-2.5 ${
                telemetry.isTorchOn
                  ? 'bg-amber-500/20 text-amber-300 border-amber-500/60 shadow-[0_0_15px_rgba(245,158,11,0.3)]'
                  : 'bg-zinc-900/60 text-zinc-400 border-zinc-800 hover:text-white'
              }`}
            >
              <Flashlight className="w-5 h-5" />
              <div className="flex flex-col text-left">
                <span className="text-[10px] font-mono text-zinc-500">TORCH</span>
                <span className="text-xs font-mono font-bold">
                  {telemetry.isTorchOn ? 'ACTIVE' : 'OFF'}
                </span>
              </div>
            </button>

            <button
              onClick={handleToggleWakeLock}
              className={`p-3 rounded-2xl border transition-all flex items-center space-x-2.5 ${
                telemetry.isScreenLocked
                  ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/60 shadow-[0_0_15px_rgba(0,240,255,0.3)]'
                  : 'bg-zinc-900/60 text-zinc-400 border-zinc-800 hover:text-white'
              }`}
            >
              {telemetry.isScreenLocked ? (
                <Lock className="w-5 h-5" />
              ) : (
                <Unlock className="w-5 h-5" />
              )}
              <div className="flex flex-col text-left">
                <span className="text-[10px] font-mono text-zinc-500">WAKE LOCK</span>
                <span className="text-xs font-mono font-bold">
                  {telemetry.isScreenLocked ? 'ACTIVE' : 'OFF'}
                </span>
              </div>
            </button>
          </div>

          {/* Section 2: Installed Android Apps Quick Launchers */}
          <div className="space-y-2.5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-mono font-medium tracking-wider text-zinc-400 uppercase">
                Installed Android Apps (Direct Intents)
              </span>
              <span className="text-[10px] font-mono text-cyan-400">Chrome Intent Bridge</span>
            </div>
            <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
              {[
                {
                  name: 'YouTube',
                  key: 'youtube',
                  icon: <Video className="w-4 h-4 text-red-400" />,
                },
                {
                  name: 'Instagram',
                  key: 'instagram',
                  icon: <Share2 className="w-4 h-4 text-pink-400" />,
                },
                {
                  name: 'WhatsApp',
                  key: 'whatsapp',
                  icon: <MessageCircle className="w-4 h-4 text-emerald-400" />,
                },
                {
                  name: 'Chrome',
                  key: 'chrome',
                  icon: <Globe className="w-4 h-4 text-blue-400" />,
                },
                {
                  name: 'Maps',
                  key: 'maps',
                  icon: <Navigation className="w-4 h-4 text-cyan-400" />,
                },
                {
                  name: 'Camera',
                  key: 'camera',
                  icon: <Camera className="w-4 h-4 text-purple-400" />,
                },
              ].map((app) => (
                <button
                  key={app.key}
                  onClick={() => handleOpenApp(app.key)}
                  className="p-3 rounded-2xl bg-zinc-900/70 border border-zinc-800 hover:border-cyan-500/50 hover:bg-zinc-850 flex flex-col items-center justify-center space-y-1.5 transition-all group"
                  title={`Open ${app.name} on Android`}
                >
                  <div className="p-2 rounded-xl bg-zinc-800 group-hover:scale-110 transition-transform">
                    {app.icon}
                  </div>
                  <span className="text-[11px] font-mono text-zinc-300 truncate w-full text-center">
                    {app.name}
                  </span>
                </button>
              ))}
            </div>
            <p className="text-[10px] font-mono text-zinc-500">
              Note: Launchees via Android Chrome intent schemes. If the app is not installed, web fallback is used.
            </p>
          </div>

          {/* Section 3: Alarms & Timers Hub */}
          <div className="space-y-3 p-4 rounded-2xl bg-zinc-900/50 border border-zinc-800">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Timer className="w-4 h-4 text-cyan-400" />
                <span className="text-xs font-mono font-semibold tracking-wide text-white uppercase">
                  Alarm & Timer Management
                </span>
              </div>
              <button
                onClick={handleVibrate}
                className="text-[10px] font-mono text-cyan-400 hover:underline flex items-center space-x-1"
              >
                <Vibrate className="w-3 h-3" />
                <span>Vibration Test</span>
              </button>
            </div>

            <form onSubmit={handleSetTimer} className="flex items-center space-x-2">
              <input
                type="text"
                value={timerLabel}
                onChange={(e) => setTimerLabel(e.target.value)}
                placeholder="Timer label..."
                className="flex-1 px-3 py-1.5 rounded-xl bg-zinc-950 border border-zinc-700 text-xs text-white placeholder-zinc-500 font-mono"
              />
              <div className="flex items-center space-x-1">
                <input
                  type="number"
                  min="0.5"
                  step="0.5"
                  value={timerMinutes}
                  onChange={(e) => setTimerMinutes(e.target.value)}
                  className="w-16 px-2 py-1.5 rounded-xl bg-zinc-950 border border-zinc-700 text-xs text-white font-mono text-center"
                />
                <span className="text-xs text-zinc-400 font-mono">min</span>
              </div>
              <button
                type="submit"
                className="px-3.5 py-1.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-xs font-mono font-bold text-white transition-colors"
              >
                Set Timer
              </button>
            </form>

            {/* Active Timers List */}
            {timers.length > 0 && (
              <div className="space-y-2 pt-2">
                <span className="text-[11px] font-mono text-zinc-500">Active Timers:</span>
                {timers.map((timer) => (
                  <div
                    key={timer.id}
                    className="flex items-center justify-between p-2.5 rounded-xl bg-zinc-950/80 border border-zinc-800"
                  >
                    <div className="flex items-center space-x-2">
                      <Bell className="w-4 h-4 text-cyan-400 animate-pulse" />
                      <span className="text-xs font-medium text-white">{timer.label}</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <span className="font-mono text-xs font-bold text-cyan-300">
                        {Math.floor(timer.remainingSeconds / 60)}:
                        {(timer.remainingSeconds % 60).toString().padStart(2, '0')}
                      </span>
                      <button
                        onClick={() => handleCancelTimer(timer.id)}
                        className="text-zinc-500 hover:text-red-400 p-1"
                        title="Cancel"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3 bg-zinc-900/80 border-t border-zinc-800 flex items-center justify-between text-[11px] font-mono text-zinc-400">
          <span>Android Chrome Intents & Web Sensors</span>
          <span className="text-cyan-400">Voice-Controlled</span>
        </div>
      </div>
    </div>
  );
};
