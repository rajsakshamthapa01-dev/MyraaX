import React, { useState, useEffect } from 'react';
import { AssistantMood, MoodConfig, VoiceName, MemoryItem } from '../types/live';
import { InterruptionShieldMode } from '../audio/AudioStreamer';
import { androidBridge, SUPPORTED_ANDROID_APPS, AndroidExecutionResult } from '../services/AndroidBridge';
import { deviceController, DeviceTelemetry } from '../services/DeviceController';
import { desktopCompanion } from '../services/DesktopCompanion';
import { MOODS } from '../constants/moods';
import { geminiTts, TtsStatus } from '../services/GeminiTtsService';
import {
  X,
  Volume2,
  VolumeX,
  Play,
  Square,
  Sparkles,
  Brain,
  Cpu,
  ShieldCheck,
  Check,
  Smartphone,
  Monitor,
  Flashlight,
  Timer,
  Phone,
  Settings as SettingsIcon,
  RotateCcw,
  Sliders,
  Radio,
  FileCode,
  Info,
  ChevronRight,
  Plus,
  Trash2,
  ArrowLeft,
  ChevronsDown,
  ChevronsUp,
  Home,
  Layers,
  Bell,
  AlertCircle,
} from 'lucide-react';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentVoice: VoiceName;
  onSelectVoice: (voice: VoiceName) => void;
  currentMood: AssistantMood;
  onSelectMood: (mood: AssistantMood) => void;
  volume: number;
  onChangeVolume: (vol: number) => void;
  shieldMode: InterruptionShieldMode;
  onChangeShieldMode: (mode: InterruptionShieldMode) => void;
  memories: MemoryItem[];
  onAddMemory: (text: string, category: 'fact' | 'preference' | 'goal') => void;
  onClearMemories: () => void;
  onNotification: (msg: string, icon?: string, status?: 'success' | 'warning' | 'error') => void;
  activeModel?: string;
  isFallbackModel?: boolean;
  fallbackNotice?: string;
  onSendMessage?: (text: string) => void;
}

type SettingsTab = 'android' | 'ai' | 'voice' | 'memory' | 'appearance' | 'pc';

const AVAILABLE_VOICES: { id: VoiceName; label: string; desc: string; tag: string }[] = [
  { id: 'Aoede', label: 'Aoede', desc: 'Expressive, confident, emotionally nuanced feminine tone', tag: 'Recommended' },
  { id: 'Fenrir', label: 'Fenrir', desc: 'Deep, resonant, commanding, focused neural voice', tag: 'Deep' },
  { id: 'Zephyr', label: 'Zephyr', desc: 'Smooth, charismatic, relaxed conversational cadence', tag: 'Charismatic' },
  { id: 'Kore', label: 'Kore', desc: 'Warm, calm, empathetic, grounded emotional tone', tag: 'Empathetic' },
  { id: 'Puck', label: 'Puck', desc: 'Sharp, energetic, witty, playful conversational style', tag: 'Witty' },
  { id: 'Charon', label: 'Charon', desc: 'Quiet, measured, philosophical masculine voice', tag: 'Reflective' },
];

const SHIELD_OPTIONS: { id: InterruptionShieldMode; label: string; desc: string; badge: string }[] = [
  {
    id: 'high_protection',
    label: 'High Protection',
    desc: 'Shields against background chatter, TV noise, and speaker echo. Interrupted by deliberate speech or tapping.',
    badge: 'Recommended',
  },
  {
    id: 'voice_only',
    label: 'Voice Only',
    desc: 'Maximum shield against noisy rooms. Only direct, close user voice or screen tap can stop speech.',
    badge: 'Strict',
  },
  {
    id: 'balanced',
    label: 'Balanced',
    desc: 'Standard sensitivity for quiet rooms with minimal background audio.',
    badge: 'Standard',
  },
];

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  currentVoice,
  onSelectVoice,
  currentMood,
  onSelectMood,
  volume,
  onChangeVolume,
  shieldMode,
  onChangeShieldMode,
  memories,
  onAddMemory,
  onClearMemories,
  onNotification,
  activeModel = 'gemini-3.8-live',
  isFallbackModel = false,
  fallbackNotice,
  onSendMessage,
}) => {
  const [activeTab, setActiveTab] = useState<SettingsTab>('android');
  const [newMemoryText, setNewMemoryText] = useState('');
  const [testCommandText, setTestCommandText] = useState('');
  const [telemetry, setTelemetry] = useState<DeviceTelemetry>(() => deviceController.getTelemetry());
  const [timerMinutes, setTimerMinutes] = useState('5');
  const [showAndroidGuide, setShowAndroidGuide] = useState(false);
  const [actionFeedback, setActionFeedback] = useState<AndroidExecutionResult | null>(null);

  const [ttsStatus, setTtsStatus] = useState<TtsStatus>(() => geminiTts.getStatus());
  const [ttsTestText, setTtsTestText] = useState(
    'Hello! I am Myraa, your personal AI voice companion. Gemini text-to-speech is working properly.'
  );
  const [ttsModel, setTtsModel] = useState<string>('gemini-3.8-flash-tts');
  const [ttsProvider, setTtsProvider] = useState<'gemini' | 'system_fallback'>('gemini');
  const [isSynthesizing, setIsSynthesizing] = useState(false);

  const isNative = androidBridge.isNative();

  useEffect(() => {
    const unsub = deviceController.subscribe((data) => setTelemetry(data));
    const unsubTts = geminiTts.subscribe((s) => setTtsStatus(s));
    return () => {
      unsub();
      unsubTts();
    };
  }, []);

  if (!isOpen) return null;

  const handleLaunchApp = async (target: string) => {
    const res = await androidBridge.executeCommand({ action: 'open_app', target });
    setActionFeedback(res);
    onNotification(res.message, 'Smartphone', res.status === 'APP_OPENED' ? 'success' : 'warning');
  };

  const handleAccessibilityAction = async (action: any, params?: Record<string, any>) => {
    const res = await androidBridge.executeCommand({ action, ...params });
    setActionFeedback(res);
    onNotification(
      res.message,
      'Smartphone',
      res.status === 'SUCCESS' ? 'success' : res.status === 'ACTION_NOT_SUPPORTED' ? 'warning' : 'error'
    );
  };

  const handleToggleTorch = async () => {
    const res = await androidBridge.executeCommand({ action: 'toggle_torch' });
    setActionFeedback(res);
    onNotification(res.message, 'Flashlight', res.status === 'SUCCESS' ? 'success' : 'warning');
  };

  const handleOpenDialer = async () => {
    const res = await androidBridge.executeCommand({ action: 'open_dialer' });
    setActionFeedback(res);
    onNotification(res.message, 'Phone');
  };

  const handleOpenSettings = async () => {
    const res = await androidBridge.executeCommand({ action: 'open_settings' });
    setActionFeedback(res);
    onNotification(res.message, 'Settings');
  };

  const handleSetTimer = () => {
    const mins = parseFloat(timerMinutes) || 5;
    deviceController.setTimer(mins, `Timer (${mins}m)`);
    onNotification(`Timer set for ${mins} minutes.`, 'Timer');
  };

  const handleAddMemorySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMemoryText.trim()) return;
    onAddMemory(newMemoryText.trim(), 'fact');
    setNewMemoryText('');
    onNotification('Saved new memory synapse.', 'Brain');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div
        className="relative w-full max-w-2xl max-h-[92vh] flex flex-col rounded-3xl bg-zinc-950 border border-cyan-500/40 shadow-[0_0_60px_rgba(0,240,255,0.25)] text-white overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-zinc-800 bg-zinc-950/90 backdrop-blur-md">
          <div className="flex items-center space-x-3">
            <div className="p-2 rounded-xl bg-cyan-500/20 text-cyan-400 border border-cyan-400/40 shadow-[0_0_12px_rgba(0,240,255,0.3)]">
              <SettingsIcon className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold font-mono tracking-wider flex items-center space-x-2">
                <span>MYRAA CORE SETTINGS</span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 font-mono">
                  v3.1.0
                </span>
              </h2>
              <p className="text-xs text-zinc-400">Autonomous Neural Voice & Android Device Agent</p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="flex items-center px-4 py-2 border-b border-zinc-800/80 bg-zinc-900/50 overflow-x-auto no-scrollbar space-x-1 sm:space-x-2">
          {[
            { id: 'android', label: 'Android Agent', icon: Smartphone },
            { id: 'ai', label: 'AI & Shield', icon: Cpu },
            { id: 'voice', label: 'Voice', icon: Volume2 },
            { id: 'memory', label: `Memories (${memories.length})`, icon: Brain },
            { id: 'appearance', label: 'Appearance', icon: Sparkles },
            { id: 'pc', label: 'PC Remote', icon: Monitor },
          ].map((tab) => {
            const Icon = tab.icon;
            const isTabActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => setActiveTab(tab.id as SettingsTab)}
                className={`flex-shrink-0 flex items-center space-x-1.5 px-3 py-2 rounded-xl text-xs font-mono font-medium transition-all ${
                  isTabActive
                    ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-400/60 shadow-sm'
                    : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800/60'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Body Content */}
        <div className="flex-1 overflow-y-auto p-5 sm:p-6 space-y-6">
          {/* TAB 1: ANDROID AGENT & DEVICE INTEGRATION */}
          {activeTab === 'android' && (
            <div className="space-y-6 animate-in fade-in">
              {/* Native Bridge Environment Banner */}
              <div className="p-4 rounded-2xl bg-zinc-900/80 border border-zinc-700/80 space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Smartphone className="w-4 h-4 text-cyan-400" />
                    <span className="text-xs font-mono font-bold tracking-wider uppercase text-zinc-300">
                      Android Execution Engine
                    </span>
                  </div>
                  <span
                    className={`text-[11px] font-mono font-semibold px-2.5 py-0.5 rounded-full border ${
                      isNative
                        ? 'bg-emerald-500/20 text-emerald-300 border-emerald-400/60'
                        : 'bg-cyan-500/15 text-cyan-300 border-cyan-400/40'
                    }`}
                  >
                    {isNative ? 'Native WebView Bridge Connected' : 'Android Chrome (Intent Mode)'}
                  </span>
                </div>
                <p className="text-xs text-zinc-400">
                  {isNative
                    ? 'Connected to Android Java bridge. Direct app package launching and AccessibilityService are available.'
                    : 'Running in mobile browser. Launches installed apps via Android Intent URLs. OS-level gestures (Back, Scroll) require the Native Android APK wrapper.'}
                </p>

                <div className="flex items-center justify-between pt-2 border-t border-zinc-800">
                  <span className="text-[11px] font-mono text-zinc-400">
                    Native Java & Accessibility files generated in <code className="text-cyan-400">/android</code>
                  </span>
                  <button
                    type="button"
                    onClick={() => setShowAndroidGuide(!showAndroidGuide)}
                    className="text-xs font-mono text-cyan-400 hover:underline flex items-center space-x-1"
                  >
                    <FileCode className="w-3.5 h-3.5" />
                    <span>{showAndroidGuide ? 'Hide Guide' : 'View APK Setup Guide'}</span>
                  </button>
                </div>

                {showAndroidGuide && (
                  <div className="p-3 mt-2 rounded-xl bg-black/60 border border-cyan-500/30 text-xs font-mono space-y-2 text-zinc-300">
                    <p className="font-bold text-cyan-300">Native Android Architecture:</p>
                    <ul className="list-disc list-inside space-y-1 text-zinc-400">
                      <li><code>android/AndroidNativeBridge.java</code>: Secure @JavascriptInterface with validated command whitelist.</li>
                      <li><code>android/MyraaAccessibilityService.java</code>: Handles Global Back, Scroll, and UI clicks.</li>
                      <li><code>android/MyraaForegroundVoiceService.java</code>: Background microphone listener with persistent notification.</li>
                      <li><code>android/AndroidManifest.xml</code>: Android 11+ package queries and permissions.</li>
                    </ul>
                  </div>
                )}
              </div>

              {/* Action Execution Feedback Notice */}
              {actionFeedback && (
                <div
                  className={`p-3 rounded-xl border text-xs font-mono flex items-center justify-between animate-in fade-in ${
                    actionFeedback.status === 'APP_OPENED' || actionFeedback.status === 'SUCCESS'
                      ? 'bg-emerald-500/15 border-emerald-400/50 text-emerald-300'
                      : 'bg-amber-500/15 border-amber-400/50 text-amber-300'
                  }`}
                >
                  <div className="flex items-center space-x-2">
                    <span className="font-bold">[{actionFeedback.status}]</span>
                    <span>{actionFeedback.message}</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => setActionFeedback(null)}
                    className="text-zinc-400 hover:text-white"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}

              {/* Installed Android Apps Launcher */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-mono font-medium tracking-wider text-zinc-400 uppercase">
                    Launch Installed Android Apps
                  </label>
                  <span className="text-[10px] font-mono text-cyan-400">Voice or Tap to Open</span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                  {Object.values(SUPPORTED_ANDROID_APPS).map((app) => (
                    <button
                      key={app.id}
                      type="button"
                      onClick={() => handleLaunchApp(app.name)}
                      className="p-3 rounded-2xl bg-zinc-900/60 border border-zinc-800 hover:border-cyan-400/70 hover:bg-zinc-800/80 transition-all text-left flex flex-col justify-between space-y-1.5 group active:scale-95"
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-semibold text-white group-hover:text-cyan-300">
                          {app.name}
                        </span>
                        <ChevronRight className="w-3 h-3 text-zinc-500 group-hover:text-cyan-400" />
                      </div>
                      <span className="text-[10px] font-mono text-zinc-500 truncate">{app.packageName}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Hardware & System Controls */}
              <div className="space-y-3">
                <label className="text-xs font-mono font-medium tracking-wider text-zinc-400 uppercase">
                  Hardware & System Actions
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                  <button
                    type="button"
                    onClick={handleToggleTorch}
                    className="p-3 rounded-2xl bg-zinc-900/60 border border-zinc-800 hover:border-amber-400 text-left flex items-center space-x-2.5 transition-all active:scale-95"
                  >
                    <Flashlight className="w-4 h-4 text-amber-400" />
                    <div>
                      <div className="text-xs font-semibold text-white">Flashlight</div>
                      <div className="text-[10px] font-mono text-zinc-500">Toggle Torch</div>
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={handleOpenDialer}
                    className="p-3 rounded-2xl bg-zinc-900/60 border border-zinc-800 hover:border-green-400 text-left flex items-center space-x-2.5 transition-all active:scale-95"
                  >
                    <Phone className="w-4 h-4 text-green-400" />
                    <div>
                      <div className="text-xs font-semibold text-white">Phone Dialer</div>
                      <div className="text-[10px] font-mono text-zinc-500">Open Tel</div>
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={handleOpenSettings}
                    className="p-3 rounded-2xl bg-zinc-900/60 border border-zinc-800 hover:border-blue-400 text-left flex items-center space-x-2.5 transition-all active:scale-95"
                  >
                    <SettingsIcon className="w-4 h-4 text-blue-400" />
                    <div>
                      <div className="text-xs font-semibold text-white">Settings</div>
                      <div className="text-[10px] font-mono text-zinc-500">Android OS</div>
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleAccessibilityAction('press_back')}
                    className="p-3 rounded-2xl bg-zinc-900/60 border border-zinc-800 hover:border-purple-400 text-left flex items-center space-x-2.5 transition-all active:scale-95"
                  >
                    <ArrowLeft className="w-4 h-4 text-purple-400" />
                    <div>
                      <div className="text-xs font-semibold text-white">Back</div>
                      <div className="text-[10px] font-mono text-zinc-500">Accessibility</div>
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleAccessibilityAction('press_home')}
                    className="p-3 rounded-2xl bg-zinc-900/60 border border-zinc-800 hover:border-cyan-400 text-left flex items-center space-x-2.5 transition-all active:scale-95"
                  >
                    <Home className="w-4 h-4 text-cyan-400" />
                    <div>
                      <div className="text-xs font-semibold text-white">Home</div>
                      <div className="text-[10px] font-mono text-zinc-500">Accessibility</div>
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleAccessibilityAction('press_recents')}
                    className="p-3 rounded-2xl bg-zinc-900/60 border border-zinc-800 hover:border-indigo-400 text-left flex items-center space-x-2.5 transition-all active:scale-95"
                  >
                    <Layers className="w-4 h-4 text-indigo-400" />
                    <div>
                      <div className="text-xs font-semibold text-white">Recents</div>
                      <div className="text-[10px] font-mono text-zinc-500">Overview</div>
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleAccessibilityAction('open_notifications')}
                    className="p-3 rounded-2xl bg-zinc-900/60 border border-zinc-800 hover:border-amber-400 text-left flex items-center space-x-2.5 transition-all active:scale-95"
                  >
                    <Bell className="w-4 h-4 text-amber-400" />
                    <div>
                      <div className="text-xs font-semibold text-white">Notifications</div>
                      <div className="text-[10px] font-mono text-zinc-500">Drawer</div>
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleAccessibilityAction('scroll', { direction: 'down' })}
                    className="p-3 rounded-2xl bg-zinc-900/60 border border-zinc-800 hover:border-teal-400 text-left flex items-center space-x-2.5 transition-all active:scale-95"
                  >
                    <ChevronsDown className="w-4 h-4 text-teal-400" />
                    <div>
                      <div className="text-xs font-semibold text-white">Scroll Down</div>
                      <div className="text-[10px] font-mono text-zinc-500">Gesture</div>
                    </div>
                  </button>
                </div>
              </div>

              {/* Timer & Alarm Controller */}
              <div className="p-4 rounded-2xl bg-zinc-900/60 border border-zinc-800 flex items-center justify-between">
                <div className="flex items-center space-x-2.5">
                  <Timer className="w-4 h-4 text-cyan-400" />
                  <div>
                    <span className="text-xs font-semibold text-white">Quick Device Timer</span>
                    <p className="text-[11px] text-zinc-400">Sets Android alarm or web timer notification.</p>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <input
                    type="number"
                    min="1"
                    max="60"
                    value={timerMinutes}
                    onChange={(e) => setTimerMinutes(e.target.value)}
                    className="w-14 px-2 py-1 rounded-xl bg-black border border-zinc-700 text-center font-mono text-xs text-white"
                  />
                  <span className="text-xs font-mono text-zinc-400">min</span>
                  <button
                    type="button"
                    onClick={handleSetTimer}
                    className="px-3 py-1 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-xs font-semibold text-black transition-colors"
                  >
                    Set
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: AI & ANTI-NOISE SHIELD */}
          {activeTab === 'ai' && (
            <div className="space-y-6 animate-in fade-in">
              {/* Shield Settings */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2 text-xs font-mono font-medium tracking-wider text-zinc-300 uppercase">
                    <ShieldCheck className="w-4 h-4 text-emerald-400" />
                    <span>Anti-Noise Interruption Shield</span>
                  </div>
                  <span className="text-[11px] text-emerald-400 font-mono">Active</span>
                </div>
                <p className="text-xs text-zinc-400">
                  Prevents unexpected room sounds, background voices, and speaker echo from prematurely cutting off MYRAA.
                </p>

                <div className="grid grid-cols-1 gap-2.5">
                  {SHIELD_OPTIONS.map((opt) => {
                    const isSelected = shieldMode === opt.id;
                    return (
                      <button
                        key={opt.id}
                        type="button"
                        onClick={() => onChangeShieldMode(opt.id)}
                        className={`p-3 rounded-2xl text-left border transition-all duration-200 flex items-start justify-between ${
                          isSelected
                            ? 'bg-emerald-500/15 border-emerald-500/70 shadow-lg shadow-emerald-500/10'
                            : 'bg-zinc-900/60 border-zinc-800 hover:border-zinc-700 hover:bg-zinc-800/70'
                        }`}
                      >
                        <div className="space-y-1 pr-3">
                          <div className="flex items-center space-x-2">
                            <span className="text-sm font-semibold text-white">{opt.label}</span>
                            <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-zinc-800 text-zinc-300 border border-zinc-700/60">
                              {opt.badge}
                            </span>
                          </div>
                          <p className="text-xs text-zinc-400">{opt.desc}</p>
                        </div>
                        {isSelected && (
                          <div className="w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center flex-shrink-0 mt-0.5">
                            <Check className="w-3.5 h-3.5" />
                          </div>
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* AI Architecture Overview */}
              <div className="p-4 rounded-2xl bg-zinc-900/60 border border-zinc-800 space-y-2.5 text-xs font-mono text-zinc-400">
                <div className="flex items-center justify-between text-white font-semibold">
                  <span>Gemini Model</span>
                  <div className="flex items-center space-x-1.5">
                    <span className="text-cyan-400 font-bold">{activeModel}</span>
                    {isFallbackModel ? (
                      <span className="px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 text-[10px] border border-amber-500/40">
                        Fallback Active
                      </span>
                    ) : (
                      <span className="px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 text-[10px] border border-emerald-500/40">
                        Verified Live
                      </span>
                    )}
                  </div>
                </div>

                {isFallbackModel && fallbackNotice && (
                  <div className="p-2.5 rounded-xl bg-amber-500/15 border border-amber-500/40 text-[11px] text-amber-200">
                    <span className="font-semibold block mb-0.5 text-amber-300">Model Availability Note:</span>
                    <span>{fallbackNotice}</span>
                  </div>
                )}

                <div className="flex items-center justify-between">
                  <span>Protocol</span>
                  <span className="text-zinc-300">Google Gemini Live WebSocket API</span>
                </div>
                <div className="flex items-center justify-between">
                  <span>Input Stream</span>
                  <span className="text-zinc-300">16kHz PCM16 Mono</span>
                </div>
                <div className="flex items-center justify-between">
                  <span>Output Playback</span>
                  <span className="text-zinc-300">24kHz PCM16 Gapless Queue</span>
                </div>
                <div className="flex items-center justify-between">
                  <span>Conversational Style</span>
                  <span className="text-zinc-300">Concise, Expressive, Adaptive</span>
                </div>
              </div>

              {/* Optional Text Command Input (Moved inside Settings to keep main view pure voice) */}
              <div className="p-4 rounded-2xl bg-zinc-900/60 border border-zinc-800 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold text-white">Manual Text Prompt (Optional)</span>
                  <span className="text-[10px] font-mono text-zinc-500">Voice is Primary</span>
                </div>
                <div className="flex items-center space-x-2">
                  <input
                    type="text"
                    value={testCommandText}
                    onChange={(e) => setTestCommandText(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' && testCommandText.trim() && onSendMessage) {
                        onSendMessage(testCommandText.trim());
                        setTestCommandText('');
                        onClose();
                      }
                    }}
                    placeholder="Type command or prompt..."
                    className="flex-1 px-3 py-1.5 rounded-xl bg-black border border-zinc-700 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-cyan-400"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      if (testCommandText.trim() && onSendMessage) {
                        onSendMessage(testCommandText.trim());
                        setTestCommandText('');
                        onClose();
                      }
                    }}
                    disabled={!testCommandText.trim()}
                    className="px-3 py-1.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 disabled:opacity-40 text-black text-xs font-semibold"
                  >
                    Send
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: VOICE CONFIGURATION */}
          {activeTab === 'voice' && (
            <div className="space-y-6 animate-in fade-in">
              {/* Voice Persona Selection */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-mono font-medium tracking-wider text-zinc-400 uppercase">
                    Vocal Synthesizer Voice
                  </label>
                  <span className="text-[11px] text-cyan-400 font-mono">24kHz Low-Latency</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {AVAILABLE_VOICES.map((v) => {
                    const isSelected = currentVoice === v.id;
                    return (
                      <button
                        key={v.id}
                        type="button"
                        onClick={() => onSelectVoice(v.id)}
                        className={`p-3 rounded-2xl text-left border transition-all duration-200 flex flex-col justify-between ${
                          isSelected
                            ? 'bg-cyan-500/15 border-cyan-500/70 shadow-lg shadow-cyan-500/10'
                            : 'bg-zinc-900/60 border-zinc-800 hover:border-zinc-700 hover:bg-zinc-800/70'
                        }`}
                      >
                        <div className="flex items-center justify-between w-full mb-1">
                          <span className="text-sm font-semibold text-white">{v.label}</span>
                          <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-zinc-800 text-zinc-300 border border-zinc-700/60">
                            {v.tag}
                          </span>
                        </div>
                        <p className="text-xs text-zinc-400 line-clamp-2">{v.desc}</p>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Volume Slider */}
              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-mono text-zinc-400 uppercase">Speaker Output Level</span>
                  <span className="font-mono text-white">{Math.round(volume * 100)}%</span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={1}
                  step={0.01}
                  value={volume}
                  onChange={(e) => onChangeVolume(parseFloat(e.target.value))}
                  className="w-full accent-cyan-400 bg-zinc-800 h-2 rounded-lg cursor-pointer"
                />
              </div>

              {/* REAL GEMINI TEXT-TO-SPEECH (TTS) CONFIGURATION */}
              <div className="p-4 rounded-2xl bg-zinc-900/60 border border-zinc-800 space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Radio className="w-4 h-4 text-cyan-400" />
                    <span className="text-xs font-semibold text-white">Google Gemini Neural TTS Engine</span>
                  </div>
                  <span className={`text-[10px] font-mono px-2 py-0.5 rounded-full border ${
                    ttsStatus.provider === 'gemini'
                      ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                      : 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                  }`}>
                    {ttsStatus.provider === 'gemini' ? 'Gemini 3.8 Audio Active' : 'System TTS Fallback'}
                  </span>
                </div>

                {/* Model Selection */}
                <div className="space-y-2">
                  <label className="text-[11px] font-mono text-zinc-400 uppercase">TTS Synthesis Model</label>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        setTtsModel('gemini-3.8-flash-tts');
                        geminiTts.setModel('gemini-3.8-flash-tts');
                      }}
                      className={`p-2.5 rounded-xl text-left border transition-all text-xs ${
                        ttsModel === 'gemini-3.8-flash-tts'
                          ? 'bg-cyan-500/20 border-cyan-400 text-white shadow-sm'
                          : 'bg-zinc-950/60 border-zinc-800 text-zinc-400 hover:text-white'
                      }`}
                    >
                      <div className="font-semibold text-cyan-300">gemini-3.8-flash-tts</div>
                      <div className="text-[10px] text-zinc-400 mt-0.5">Expressive voice design, emotion & nuance (Primary)</div>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        setTtsModel('gemini-3.8-flash-lite-tts');
                        geminiTts.setModel('gemini-3.8-flash-lite-tts');
                      }}
                      className={`p-2.5 rounded-xl text-left border transition-all text-xs ${
                        ttsModel === 'gemini-3.8-flash-lite-tts'
                          ? 'bg-cyan-500/20 border-cyan-400 text-white shadow-sm'
                          : 'bg-zinc-950/60 border-zinc-800 text-zinc-400 hover:text-white'
                      }`}
                    >
                      <div className="font-semibold text-cyan-300">gemini-3.8-flash-lite-tts</div>
                      <div className="text-[10px] text-zinc-400 mt-0.5">High-efficiency, 24kHz low-latency alternative</div>
                    </button>
                  </div>
                </div>

                {/* Model Availability & Gemini 3.1 Note */}
                <div className="p-3 rounded-xl bg-cyan-950/30 border border-cyan-500/30 text-[11px] text-cyan-200/90 space-y-1">
                  <div className="font-semibold flex items-center space-x-1.5 text-cyan-300">
                    <Info className="w-3.5 h-3.5 flex-shrink-0" />
                    <span>Gemini Audio Architecture Note</span>
                  </div>
                  <p className="text-zinc-300 text-[11px] leading-relaxed">
                    Google officially designates <strong>gemini-3.8-flash-lite-tts</strong> and <strong>gemini-3.8-flash-tts</strong> for audio speech synthesis. Previews like <em>gemini-3.1-preview</em> are text reasoning models that do not output native audio waves; MYRAA automatically pairs Gemini text intelligence with the official Gemini TTS engine.
                  </p>
                </div>

                {/* Interactive Test Voice Bench */}
                <div className="space-y-2 pt-1 border-t border-zinc-800">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-semibold text-white">Test Speech Synthesis</span>
                    {ttsStatus.isSpeaking && (
                      <span className="text-[10px] font-mono text-cyan-300 animate-pulse flex items-center space-x-1">
                        <Volume2 className="w-3.5 h-3.5" />
                        <span>Playing 24kHz Audio...</span>
                      </span>
                    )}
                  </div>

                  <div className="space-y-2">
                    <input
                      type="text"
                      value={ttsTestText}
                      onChange={(e) => setTtsTestText(e.target.value)}
                      placeholder="Enter test phrase..."
                      className="w-full px-3 py-2 rounded-xl bg-black border border-zinc-700 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-cyan-400"
                    />

                    <div className="flex items-center space-x-2">
                      <button
                        type="button"
                        disabled={isSynthesizing || !ttsTestText.trim()}
                        onClick={async () => {
                          setIsSynthesizing(true);
                          try {
                            await geminiTts.speak(ttsTestText.trim(), {
                              voice: currentVoice,
                              model: ttsModel,
                            });
                            onNotification('Spoken with Gemini TTS', 'Volume2', 'success');
                          } catch (err: any) {
                            onNotification(err.message || 'TTS Error', 'AlertCircle', 'error');
                          } finally {
                            setIsSynthesizing(false);
                          }
                        }}
                        className="flex-1 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 disabled:opacity-50 text-black text-xs font-bold flex items-center justify-center space-x-1.5 transition-colors"
                      >
                        <Play className="w-3.5 h-3.5 fill-black" />
                        <span>{isSynthesizing ? 'Synthesizing with Gemini...' : 'Synthesize & Play Audio'}</span>
                      </button>

                      {ttsStatus.isSpeaking && (
                        <button
                          type="button"
                          onClick={() => {
                            geminiTts.stop();
                            onNotification('Playback stopped', 'VolumeX');
                          }}
                          className="px-3 py-2 rounded-xl bg-red-600/30 hover:bg-red-600/50 text-red-200 text-xs font-semibold flex items-center space-x-1 transition-colors"
                        >
                          <Square className="w-3.5 h-3.5" />
                          <span>Stop</span>
                        </button>
                      )}
                    </div>
                  </div>

                  {ttsStatus.lastError && (
                    <div className="p-2 rounded-lg bg-red-500/15 border border-red-500/30 text-[11px] text-red-300 flex items-center space-x-1.5">
                      <AlertCircle className="w-3.5 h-3.5 flex-shrink-0" />
                      <span>{ttsStatus.lastError}</span>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: MEMORY CORE */}
          {activeTab === 'memory' && (
            <div className="space-y-5 animate-in fade-in">
              {/* Add Memory Form */}
              <form onSubmit={handleAddMemorySubmit} className="space-y-2">
                <label className="text-xs font-mono font-medium tracking-wider text-zinc-400 uppercase">
                  Imprint New Memory Synapse
                </label>
                <div className="flex space-x-2">
                  <input
                    type="text"
                    value={newMemoryText}
                    onChange={(e) => setNewMemoryText(e.target.value)}
                    placeholder="Enter a fact, user preference, or note..."
                    className="flex-1 px-3.5 py-2 rounded-xl bg-zinc-900 border border-zinc-800 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-cyan-500"
                  />
                  <button
                    type="submit"
                    className="px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-xs font-bold text-black flex items-center space-x-1.5 transition-colors"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Save</span>
                  </button>
                </div>
              </form>

              {/* Memory List */}
              <div className="space-y-2.5">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono text-zinc-400 uppercase">
                    Stored Synapses ({memories.length})
                  </span>
                  {memories.length > 0 && (
                    <button
                      type="button"
                      onClick={onClearMemories}
                      className="text-xs font-mono text-red-400 hover:underline flex items-center space-x-1"
                    >
                      <Trash2 className="w-3 h-3" />
                      <span>Clear All</span>
                    </button>
                  )}
                </div>

                <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
                  {memories.length === 0 ? (
                    <div className="p-6 text-center text-xs font-mono text-zinc-500 border border-dashed border-zinc-800 rounded-2xl">
                      No memories stored yet. Tell MYRAA "Remember that..." or add one above.
                    </div>
                  ) : (
                    memories.map((m) => (
                      <div
                        key={m.id}
                        className="p-3 rounded-2xl bg-zinc-900/60 border border-zinc-800/80 flex items-start justify-between text-xs space-x-3"
                      >
                        <div className="space-y-1">
                          <p className="text-zinc-200">{m.text}</p>
                          <span className="text-[10px] font-mono text-cyan-400/80">
                            {new Date(m.timestamp).toLocaleDateString()}
                          </span>
                        </div>
                        <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-zinc-800 text-zinc-400 uppercase">
                          {m.category}
                        </span>
                      </div>
                    ))
                  )}
                </div>
              </div>
            </div>
          )}

          {/* TAB 5: APPEARANCE & MOOD */}
          {activeTab === 'appearance' && (
            <div className="space-y-6 animate-in fade-in">
              <div className="space-y-3">
                <label className="text-xs font-mono font-medium tracking-wider text-zinc-400 uppercase">
                  Containment Chamber Hologram Aura
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                  {Object.values(MOODS).map((m: MoodConfig) => {
                    const isSelected = currentMood === m.name;
                    return (
                      <button
                        key={m.name}
                        type="button"
                        onClick={() => onSelectMood(m.name)}
                        className={`p-3 rounded-2xl border text-left flex items-center space-x-2.5 transition-all ${
                          isSelected
                            ? 'border-cyan-400 bg-cyan-950/40 shadow-md ring-1 ring-cyan-400/50'
                            : 'border-zinc-800/80 bg-zinc-900/40 hover:border-zinc-700'
                        }`}
                      >
                        <div
                          className="w-5 h-5 rounded-full flex-shrink-0 border border-white/20 shadow-sm"
                          style={{ background: m.orbGradient || m.primaryColor }}
                        />
                        <span className="text-xs font-medium truncate">{m.label}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-zinc-900/60 border border-zinc-800 space-y-1 text-xs text-zinc-400">
                <span className="text-white font-semibold">Full-Screen Anime Hologram</span>
                <p>Character background fills the entire display with subtle cyber particles and audio-reactive scaling.</p>
              </div>
            </div>
          )}

          {/* TAB 6: PC REMOTE COMPANION */}
          {activeTab === 'pc' && (
            <div className="space-y-5 animate-in fade-in">
              <div className="p-4 rounded-2xl bg-zinc-900/60 border border-zinc-800 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2 text-xs font-semibold text-white">
                    <Monitor className="w-4 h-4 text-blue-400" />
                    <span>Windows PC Remote Companion</span>
                  </div>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-blue-500/20 text-blue-300 border border-blue-400/40">
                    Pairing Ready
                  </span>
                </div>
                <p className="text-xs text-zinc-400">
                  Control your PC volume, launch apps, or lock your workstation using voice commands.
                </p>
                <div className="flex items-center space-x-2 text-xs font-mono text-zinc-300 bg-black/60 p-2.5 rounded-xl border border-zinc-800">
                  <span className="text-zinc-500">Pairing Code:</span>
                  <span className="text-blue-400 font-bold tracking-widest">MYRAA-PC-7701</span>
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-xs font-mono font-medium tracking-wider text-zinc-400 uppercase">
                  Simulated PC Actions
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {[
                    { label: 'Volume Mute', action: 'MUTE_AUDIO' },
                    { label: 'Lock PC', action: 'LOCK_SCREEN' },
                    { label: 'Open Browser', action: 'OPEN_CHROME' },
                    { label: 'Next Track', action: 'MEDIA_NEXT' },
                  ].map((pcCmd) => (
                    <button
                      key={pcCmd.action}
                      type="button"
                      onClick={() => {
                        desktopCompanion.executeCommand(pcCmd.action, { simulate: true });
                        onNotification(`PC Command: ${pcCmd.label} sent.`, 'Monitor');
                      }}
                      className="p-2.5 rounded-xl bg-zinc-900 border border-zinc-800 hover:border-blue-400 text-xs font-mono text-zinc-300 text-left transition-all"
                    >
                      {pcCmd.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-zinc-800 bg-zinc-950/80 flex items-center justify-between text-[11px] font-mono text-zinc-500">
          <div className="flex items-center space-x-1.5">
            <Cpu className="w-3.5 h-3.5 text-cyan-400" />
            <span>gemini-3.1-flash-live-preview</span>
          </div>
          <span>Hindi Spoken • English UI</span>
        </div>
      </div>
    </div>
  );
};
