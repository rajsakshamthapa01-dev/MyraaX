import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  X,
  Plus,
  ArrowLeft,
  ArrowRight,
  RotateCw,
  Home,
  Lock,
  Star,
  ExternalLink,
  Sparkles,
  Search,
  Youtube,
  Music,
  Volume2,
  Play,
  Pause,
  AlertCircle,
  Globe,
  Check,
  RefreshCw,
} from 'lucide-react';
import { realBrowser, BrowserTab } from '../services/RealBrowserService';
import { realMedia, YouTubeVideo, MusicTrack, WebSummary } from '../services/RealMediaService';
import { geminiTts } from '../services/GeminiTtsService';

interface IntegratedBrowserProps {
  isOpen: boolean;
  onClose: () => void;
  onNotification?: (msg: string, icon?: string, status?: 'success' | 'warning' | 'error') => void;
}

export const IntegratedBrowser: React.FC<IntegratedBrowserProps> = ({
  isOpen,
  onClose,
  onNotification,
}) => {
  const [tabs, setTabs] = useState<BrowserTab[]>(() => realBrowser.getTabs());
  const [activeTab, setActiveTab] = useState<BrowserTab | undefined>(() => realBrowser.getActiveTab());
  const [urlInput, setUrlInput] = useState<string>(() => realBrowser.getActiveTab()?.displayUrl || '');
  const [activeVideo, setActiveVideo] = useState<YouTubeVideo | null>(null);
  const [activeTrack, setActiveTrack] = useState<MusicTrack | null>(null);
  const [isTrackPlaying, setIsTrackPlaying] = useState(false);
  const [webSummary, setWebSummary] = useState<WebSummary | null>(null);
  const [isSummarizing, setIsSummarizing] = useState(false);
  const [iframeError, setIframeError] = useState(false);
  const [isLoadingPage, setIsLoadingPage] = useState(false);

  // YouTube Companion Hub State
  const [ytSearchInput, setYtSearchInput] = useState('');
  const [ytResults, setYtResults] = useState<YouTubeVideo[]>([]);
  const [isSearchingYt, setIsSearchingYt] = useState(false);

  const iframeRef = useRef<HTMLIFrameElement | null>(null);
  const lastNavigationTapRef = useRef<number>(0);

  // Sync state with RealBrowserService and RealMediaService
  useEffect(() => {
    const unsubBrowser = realBrowser.subscribe(() => {
      const currentTabs = realBrowser.getTabs();
      const currentActive = realBrowser.getActiveTab();
      setTabs(currentTabs);
      setActiveTab(currentActive);
      if (currentActive) {
        setUrlInput(currentActive.displayUrl);
        setIframeError(false);
      }
    });

    const unsubMedia = realMedia.subscribe(() => {
      setActiveVideo(realMedia.getActiveVideo());
      setActiveTrack(realMedia.getActiveTrack());
      setIsTrackPlaying(realMedia.isTrackPlaying());
    });

    // Handle seamless links, form submissions, and page info from proxied websites
    const handleBridgeMessage = (e: MessageEvent) => {
      if (e.data && typeof e.data === 'object') {
        if (e.data.type === 'MYRAA_BROWSER_NAVIGATE' && typeof e.data.url === 'string') {
          console.log('[IntegratedBrowser] Bridge navigate to:', e.data.url);
          realBrowser.navigate(e.data.url);
        } else if (e.data.type === 'MYRAA_BROWSER_PAGE_INFO') {
          const active = realBrowser.getActiveTab();
          if (active && e.data.title) {
            realBrowser.updateTabTitle(active.id, e.data.title);
          }
        } else if (e.data.type === 'MYRAA_BROWSER_POPSTATE') {
          const active = realBrowser.getActiveTab();
          if (active && e.data.url && active.url !== e.data.url) {
            realBrowser.navigate(e.data.url);
          }
        } else if (e.data.type === 'MYRAA_YOUTUBE_SEARCH' && typeof e.data.query === 'string') {
          performYouTubeSearch(e.data.query);
        }
      }
    };

    window.addEventListener('message', handleBridgeMessage);

    return () => {
      unsubBrowser();
      unsubMedia();
      window.removeEventListener('message', handleBridgeMessage);
    };
  }, []);

  const currentTab = activeTab || tabs[0];
  const isBookmarked = currentTab ? realBrowser.isBookmarked(currentTab.url) : false;

  // Determine if the current tab is navigating the YouTube homepage/feed
  const isYouTubeHomePage = (url?: string): boolean => {
    if (!url) return false;
    return /^(https?:\/\/)?(www\.|m\.)?youtube\.com(\/)?(\?.*)?$/i.test(url.trim());
  };

  const isYtHome = isYouTubeHomePage(currentTab?.url);

  // Perform search in YouTube Companion Hub
  const performYouTubeSearch = useCallback(async (query: string) => {
    const q = query.trim();
    if (!q) return;
    setYtSearchInput(q);
    setIsSearchingYt(true);
    console.log('[IntegratedBrowser] Searching YouTube for:', q);
    try {
      const results = await realMedia.searchYouTube(q);
      setYtResults(results);
      if (results.length === 0) {
        onNotification?.(`No YouTube results for "${q}"`, 'Youtube', 'warning');
      }
    } catch (err: any) {
      console.warn('[IntegratedBrowser] YouTube search failed:', err);
      onNotification?.('YouTube search failed', 'Youtube', 'error');
    } finally {
      setIsSearchingYt(false);
    }
  }, [onNotification]);

  // Load initial recommended videos when YouTube hub is opened
  useEffect(() => {
    if (isYtHome && ytResults.length === 0 && !isSearchingYt) {
      performYouTubeSearch('trending lofi music');
    }
  }, [isYtHome, ytResults.length, isSearchingYt, performYouTubeSearch]);

  // Loading state and timeout management
  useEffect(() => {
    if (currentTab?.url) {
      setIsLoadingPage(true);
      setIframeError(false);

      // Safe navigation timeout: never leave skeleton or loader indefinitely
      const timeout = setTimeout(() => {
        console.log(`[IntegratedBrowser] Page load timeout reached for: ${currentTab.url}`);
        setIsLoadingPage(false);
        if (currentTab) {
          realBrowser.setTabLoading(currentTab.id, false);
        }
      }, 7000);

      return () => clearTimeout(timeout);
    }
  }, [currentTab?.url, currentTab?.reloadKey]);

  // Go Back
  const handleGoBack = useCallback(
    (e?: React.MouseEvent) => {
      e?.preventDefault();
      e?.stopPropagation();
      const now = Date.now();
      if (now - lastNavigationTapRef.current < 250) return;
      lastNavigationTapRef.current = now;

      // Native Android WebView back
      if (typeof window !== 'undefined' && (window as any).Android) {
        try {
          (window as any).Android.executeCommand(JSON.stringify({ action: 'browser_go_back' }));
        } catch {}
      }

      // History stack back
      if (currentTab && currentTab.canGoBack) {
        const didGoBack = realBrowser.goBack(currentTab.id);
        if (!didGoBack && iframeRef.current?.contentWindow) {
          try {
            iframeRef.current.contentWindow.history.back();
          } catch {}
        }
      } else if (iframeRef.current?.contentWindow) {
        try {
          iframeRef.current.contentWindow.history.back();
        } catch {}
      }
    },
    [currentTab]
  );

  // Go Forward
  const handleGoForward = useCallback(
    (e?: React.MouseEvent) => {
      e?.preventDefault();
      e?.stopPropagation();
      const now = Date.now();
      if (now - lastNavigationTapRef.current < 250) return;
      lastNavigationTapRef.current = now;

      if (typeof window !== 'undefined' && (window as any).Android) {
        try {
          (window as any).Android.executeCommand(JSON.stringify({ action: 'browser_go_forward' }));
        } catch {}
      }

      if (currentTab && currentTab.canGoForward) {
        const didGoForward = realBrowser.goForward(currentTab.id);
        if (!didGoForward && iframeRef.current?.contentWindow) {
          try {
            iframeRef.current.contentWindow.history.forward();
          } catch {}
        }
      } else if (iframeRef.current?.contentWindow) {
        try {
          iframeRef.current.contentWindow.history.forward();
        } catch {}
      }
    },
    [currentTab]
  );

  // Omnibox Navigation Handler
  const handleNavigateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const raw = urlInput.trim();
    if (!raw) return;

    console.log(`[IntegratedBrowser] Navigating to: ${raw}`);
    setIsLoadingPage(true);
    setIframeError(false);
    realBrowser.navigate(raw);
  };

  const handleNewTab = () => {
    realBrowser.createTab('https://www.google.com', 'Google');
  };

  const handleOpenExternally = () => {
    if (currentTab?.url) {
      console.log(`[IntegratedBrowser] Opening external URL: ${currentTab.url}`);
      window.open(currentTab.url, '_blank', 'noopener,noreferrer');
      onNotification?.('Opened in external browser window', 'ExternalLink');
    }
  };

  const handleSummarize = async () => {
    if (!currentTab || !currentTab.url) return;
    setIsSummarizing(true);
    setWebSummary(null);

    try {
      const summary = await realMedia.summarizeWebpage(currentTab.url);
      setWebSummary(summary);
      onNotification?.(`Summarized "${summary.title}"`, 'Sparkles', 'success');

      // Speak summary using Gemini TTS
      const spokenSummary = `Here is a summary of ${summary.title}. ${summary.summary}`;
      geminiTts.speak(spokenSummary);
    } catch (err: any) {
      onNotification?.(err.message || 'Could not summarize webpage', 'AlertCircle', 'error');
    } finally {
      setIsSummarizing(false);
    }
  };

  const handleToggleBookmark = () => {
    if (!currentTab) return;
    if (isBookmarked) {
      const bm = realBrowser.getBookmarks().find((b) => b.url === currentTab.url);
      if (bm) realBrowser.removeBookmark(bm.id);
      onNotification?.('Bookmark removed', 'Star');
    } else {
      realBrowser.addBookmark(currentTab.url, currentTab.title);
      onNotification?.('Page bookmarked', 'Star', 'success');
    }
  };

  const quickLinks = [
    { title: 'Google', url: 'https://www.google.com' },
    { title: 'YouTube', url: 'https://www.youtube.com' },
    { title: 'Wikipedia', url: 'https://en.wikipedia.org' },
    { title: 'GitHub', url: 'https://github.com' },
    { title: 'Reddit', url: 'https://www.reddit.com' },
  ];

  const suggestedYtTags = ['Lofi Beats', 'Coding Music', 'AI News', 'Synthwave', 'Documentary', 'Space 4K'];

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/85 backdrop-blur-md animate-in fade-in">
      <div className="relative w-full h-full max-w-6xl max-h-[92vh] flex flex-col bg-[#0b0f19] border border-cyan-500/30 rounded-2xl shadow-2xl overflow-hidden font-sans text-white">
        
        {/* 1. TOP TAB STRIP */}
        <div className="flex items-center justify-between px-3 pt-2 pb-1 bg-zinc-950/95 border-b border-zinc-800">
          <div className="flex items-center space-x-1.5 overflow-x-auto max-w-[80%] sm:max-w-[85%] no-scrollbar">
            {tabs.map((tab) => {
              const isActive = tab.id === currentTab?.id;
              return (
                <div
                  key={tab.id}
                  onClick={() => realBrowser.setActiveTab(tab.id)}
                  className={`group relative flex items-center space-x-2 px-3 py-1.5 rounded-t-xl text-xs font-mono cursor-pointer border-t border-x transition-all select-none min-w-[110px] sm:min-w-[130px] max-w-[180px] sm:max-w-[200px] ${
                    isActive
                      ? 'bg-[#121826] border-cyan-500/40 text-cyan-300 font-semibold shadow-inner'
                      : 'bg-zinc-900/60 border-zinc-800 text-zinc-400 hover:text-white hover:bg-zinc-800/60'
                  }`}
                >
                  <Globe className={`w-3.5 h-3.5 flex-shrink-0 ${isActive ? 'text-cyan-400' : 'text-zinc-500'}`} />
                  <span className="truncate flex-1">{tab.title || 'Tab'}</span>
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      realBrowser.closeTab(tab.id);
                    }}
                    className="p-0.5 rounded-md text-zinc-500 hover:text-white hover:bg-zinc-700/60 opacity-60 group-hover:opacity-100"
                    title="Close tab"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </div>
              );
            })}

            <button
              type="button"
              onClick={handleNewTab}
              className="p-1.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-zinc-400 hover:text-cyan-300 transition-colors"
              title="New Tab"
            >
              <Plus className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="flex items-center space-x-2">
            <span className="text-[10px] font-mono text-cyan-400/80 hidden sm:inline">MYRAA IN-BUILT BROWSER</span>
            <button
              type="button"
              onClick={onClose}
              className="p-1.5 rounded-xl bg-zinc-900 hover:bg-red-500/20 text-zinc-400 hover:text-red-400 border border-zinc-800 transition-colors cursor-pointer"
              title="Close Browser"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* 2. NAVIGATION & ADDRESS TOOLBAR */}
        <div className="flex items-center space-x-2 px-2.5 sm:px-3 py-2 bg-[#121826] border-b border-zinc-800">
          <div className="flex items-center space-x-1 text-zinc-400">
            <button
              type="button"
              onClick={handleGoBack}
              disabled={!currentTab?.canGoBack}
              className={`p-1.5 rounded-lg transition-all ${
                currentTab?.canGoBack
                  ? 'hover:bg-zinc-800 hover:text-cyan-300 text-zinc-200 cursor-pointer active:scale-95'
                  : 'opacity-30 cursor-not-allowed text-zinc-600'
              }`}
              title={currentTab?.canGoBack ? 'Go Back' : 'No previous webpage'}
            >
              <ArrowLeft className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={handleGoForward}
              disabled={!currentTab?.canGoForward}
              className={`p-1.5 rounded-lg transition-all ${
                currentTab?.canGoForward
                  ? 'hover:bg-zinc-800 hover:text-cyan-300 text-zinc-200 cursor-pointer active:scale-95'
                  : 'opacity-30 cursor-not-allowed text-zinc-600'
              }`}
              title={currentTab?.canGoForward ? 'Go Forward' : 'No forward webpage'}
            >
              <ArrowRight className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={() => realBrowser.reload()}
              className={`p-1.5 rounded-lg hover:bg-zinc-800 hover:text-white cursor-pointer ${
                isLoadingPage || currentTab?.isLoading ? 'animate-spin text-cyan-400' : ''
              }`}
              title="Reload Webpage"
            >
              <RotateCw className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={() => realBrowser.navigate('https://www.google.com')}
              className="p-1.5 rounded-lg hover:bg-zinc-800 text-zinc-400 hover:text-white cursor-pointer"
              title="Home"
            >
              <Home className="w-4 h-4" />
            </button>
          </div>

          {/* Unified Omnibox / Address Bar Form with Enter & Go button */}
          <form onSubmit={handleNavigateSubmit} className="flex-1 flex items-center space-x-1.5 min-w-0">
            <div className="relative flex-1 min-w-0 flex items-center">
              <div className="absolute left-2.5 flex items-center space-x-1.5 pointer-events-none text-zinc-500">
                <Lock className="w-3.5 h-3.5 text-emerald-400" />
              </div>
              <input
                type="text"
                value={urlInput}
                onChange={(e) => setUrlInput(e.target.value)}
                placeholder="Enter URL or search (e.g. youtube.com, wikipedia.org)..."
                className="w-full pl-8 pr-10 py-1.5 rounded-xl bg-zinc-950/80 border border-zinc-700/80 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400 font-mono"
              />
              <div className="absolute right-2 flex items-center space-x-1">
                <button
                  type="button"
                  onClick={handleToggleBookmark}
                  className={`p-1 rounded hover:bg-zinc-800 ${
                    isBookmarked ? 'text-amber-400' : 'text-zinc-500 hover:text-zinc-300'
                  }`}
                  title="Bookmark Page"
                >
                  <Star className={`w-3.5 h-3.5 ${isBookmarked ? 'fill-amber-400' : ''}`} />
                </button>
              </div>
            </div>

            {/* Explicit Go Button */}
            <button
              type="submit"
              className="px-2.5 sm:px-3 py-1.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-black text-xs font-mono font-bold transition-all active:scale-95 cursor-pointer flex-shrink-0"
              title="Navigate to URL"
            >
              <span>Go</span>
            </button>
          </form>

          {/* AI Summarize & External Launch Action Buttons */}
          <div className="flex items-center space-x-1 sm:space-x-1.5 flex-shrink-0">
            <button
              type="button"
              onClick={handleSummarize}
              disabled={isSummarizing || !currentTab?.url}
              className="px-2 sm:px-2.5 py-1.5 rounded-xl bg-cyan-600/20 hover:bg-cyan-600/40 border border-cyan-400/40 text-cyan-300 text-xs font-mono font-medium flex items-center space-x-1.5 transition-all disabled:opacity-40 cursor-pointer"
              title="Summarize webpage with MYRAA Neural Intelligence"
            >
              <Sparkles className={`w-3.5 h-3.5 text-cyan-400 ${isSummarizing ? 'animate-spin' : ''}`} />
              <span className="hidden md:inline">{isSummarizing ? 'Analyzing...' : 'Summarize'}</span>
            </button>

            <button
              type="button"
              onClick={handleOpenExternally}
              className="p-1.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-zinc-400 hover:text-white cursor-pointer"
              title="Open current webpage in Chrome / External browser"
            >
              <ExternalLink className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* 3. BOOKMARKS & QUICK SHORTCUTS STRIP */}
        <div className="flex items-center space-x-2 px-3 py-1 bg-[#0e1420] border-b border-zinc-800/60 overflow-x-auto no-scrollbar text-xs">
          <span className="text-[10px] font-mono text-zinc-500 uppercase flex-shrink-0">Quick:</span>
          {quickLinks.map((ql) => (
            <button
              key={ql.title}
              type="button"
              onClick={() => realBrowser.navigate(ql.url)}
              className="px-2 py-0.5 rounded-lg bg-zinc-900/60 hover:bg-cyan-950/60 border border-zinc-800/60 hover:border-cyan-500/40 text-zinc-300 hover:text-cyan-300 text-[11px] font-mono transition-colors whitespace-nowrap cursor-pointer"
            >
              {ql.title}
            </button>
          ))}
          {realBrowser.getBookmarks().map((bm) => (
            <button
              key={bm.id}
              type="button"
              onClick={() => realBrowser.navigate(bm.url)}
              className="px-2 py-0.5 rounded-lg bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/30 text-amber-300 text-[11px] font-mono transition-colors whitespace-nowrap flex items-center space-x-1 cursor-pointer"
            >
              <Star className="w-2.5 h-2.5 fill-amber-300" />
              <span>{bm.title.substring(0, 16)}</span>
            </button>
          ))}
        </div>

        {/* 4. MAIN BROWSER CONTENT CANVAS */}
        <div className="relative flex-1 bg-[#0b0f19] flex flex-col overflow-hidden">
          {/* Active YouTube Video Player Embed Overlay */}
          {activeVideo && (
            <div className="absolute top-0 left-0 right-0 z-30 p-3 bg-zinc-950/95 border-b border-cyan-500/30 shadow-2xl flex flex-col md:flex-row items-center justify-between space-y-2 md:space-y-0 md:space-x-4 animate-in slide-in-from-top">
              <div className="flex items-center space-x-3 w-full md:w-auto">
                <div className="w-10 h-10 rounded-xl bg-red-600/20 border border-red-500/50 flex items-center justify-center flex-shrink-0">
                  <Youtube className="w-5 h-5 text-red-500" />
                </div>
                <div className="min-w-0 flex-1">
                  <span className="text-xs font-bold text-white block truncate">{activeVideo.title}</span>
                  <span className="text-[11px] font-mono text-zinc-400">{activeVideo.channel} • YouTube Verified</span>
                </div>
              </div>

              <div className="flex items-center space-x-2">
                <button
                  type="button"
                  onClick={() => {
                    const videoUrl = activeVideo.url;
                    realBrowser.navigate(videoUrl);
                  }}
                  className="px-3 py-1.5 rounded-xl bg-cyan-600/20 hover:bg-cyan-600/30 border border-cyan-400/40 text-cyan-300 text-xs font-mono font-medium flex items-center space-x-1.5 cursor-pointer"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  <span>View in Tab</span>
                </button>
                <button
                  type="button"
                  onClick={() => realMedia.closeVideo()}
                  className="p-1.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-zinc-400 hover:text-white border border-zinc-800 cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          {/* Embedded Web View */}
          {currentTab?.url ? (
            <div className="relative w-full h-full flex flex-col bg-[#0b0f19]">
              {/* Visual Loading Progress Bar */}
              {(isLoadingPage || currentTab.isLoading) && (
                <div className="absolute top-0 left-0 right-0 h-1 z-40 bg-zinc-950/80 overflow-hidden">
                  <div className="h-full bg-gradient-to-r from-cyan-500 via-sky-400 to-teal-300 w-full animate-pulse transition-all"></div>
                </div>
              )}

              {/* CASE A: Active Video Modal Playing */}
              {activeVideo && activeVideo.id !== 'search_fallback' ? (
                <div className="w-full h-full flex items-center justify-center bg-black">
                  <iframe
                    src={`https://www.youtube.com/embed/${activeVideo.id}?autoplay=1&enablejsapi=1`}
                    title={activeVideo.title}
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                    allowFullScreen
                    className="w-full h-full border-0 bg-black"
                  />
                </div>
              ) : isYtHome ? (
                /* CASE B: YouTube Hub for Homepage / Search (Prevents desktop skeleton freeze) */
                <div className="w-full h-full overflow-y-auto p-4 sm:p-6 bg-[#0b0f19] flex flex-col items-center">
                  <div className="max-w-3xl w-full flex flex-col items-center text-center space-y-5 my-auto py-4">
                    {/* Header */}
                    <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-red-600/20 border border-red-500/40 text-red-400 text-xs font-mono font-semibold">
                      <Youtube className="w-4 h-4" />
                      <span>YouTube on MYRAA</span>
                    </div>

                    <div className="space-y-1.5">
                      <h2 className="text-xl sm:text-2xl font-bold text-white tracking-wide">
                        YouTube Companion Hub
                      </h2>
                      <p className="text-xs sm:text-sm text-zinc-400 max-w-lg mx-auto">
                        YouTube blocks full desktop website embedding inside iframes. Search and stream any video below directly in MYRAA's player, or launch YouTube in Chrome.
                      </p>
                    </div>

                    {/* YouTube Search Bar */}
                    <form
                      onSubmit={(e) => {
                        e.preventDefault();
                        performYouTubeSearch(ytSearchInput);
                      }}
                      className="w-full max-w-xl flex items-center space-x-2"
                    >
                      <div className="relative flex-1">
                        <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-zinc-400" />
                        <input
                          type="text"
                          value={ytSearchInput}
                          onChange={(e) => setYtSearchInput(e.target.value)}
                          placeholder="Search any YouTube video or topic..."
                          className="w-full pl-9 pr-4 py-2.5 rounded-xl bg-zinc-900 border border-zinc-700 text-sm text-white placeholder-zinc-500 focus:outline-none focus:border-red-500 focus:ring-1 focus:ring-red-500 font-sans"
                        />
                      </div>
                      <button
                        type="submit"
                        disabled={isSearchingYt}
                        className="px-4 py-2.5 rounded-xl bg-red-600 hover:bg-red-500 text-white font-semibold text-xs transition-all active:scale-95 cursor-pointer flex items-center space-x-1.5 disabled:opacity-50 flex-shrink-0"
                      >
                        <Search className={`w-3.5 h-3.5 ${isSearchingYt ? 'animate-spin' : ''}`} />
                        <span>{isSearchingYt ? 'Searching...' : 'Search'}</span>
                      </button>
                    </form>

                    {/* Quick Tag Recommendations */}
                    <div className="flex flex-wrap justify-center gap-1.5 max-w-xl">
                      {suggestedYtTags.map((tag) => (
                        <button
                          key={tag}
                          type="button"
                          onClick={() => performYouTubeSearch(tag)}
                          className="px-2.5 py-1 rounded-lg bg-zinc-900/80 hover:bg-zinc-800 border border-zinc-800 text-xs font-mono text-zinc-300 hover:text-cyan-300 transition-colors cursor-pointer"
                        >
                          #{tag}
                        </button>
                      ))}
                    </div>

                    {/* Primary Fallback: Open YouTube Externally */}
                    <div className="pt-2">
                      <a
                        href="https://www.youtube.com"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center space-x-2 px-5 py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-black font-bold text-xs font-mono transition-all shadow-[0_0_20px_rgba(0,240,255,0.25)]"
                      >
                        <ExternalLink className="w-4 h-4" />
                        <span>Open Full YouTube in Chrome / Browser</span>
                      </a>
                    </div>

                    {/* Search Results Display */}
                    {ytResults.length > 0 && (
                      <div className="w-full text-left pt-4 space-y-3">
                        <div className="flex items-center justify-between border-b border-zinc-800 pb-2">
                          <span className="text-xs font-mono font-bold text-zinc-300">
                            Results ({ytResults.length} videos)
                          </span>
                          <span className="text-[11px] font-mono text-zinc-500">Tap to play</span>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-h-72 overflow-y-auto pr-1">
                          {ytResults.map((v) => (
                            <div
                              key={v.id}
                              className="group p-2.5 rounded-xl bg-zinc-900/70 border border-zinc-800 hover:border-cyan-500/50 flex space-x-3 transition-all"
                            >
                              <div
                                onClick={() => realBrowser.navigate(v.url)}
                                className="relative w-28 h-18 rounded-lg overflow-hidden bg-black flex-shrink-0 cursor-pointer"
                              >
                                {v.thumbnail ? (
                                  <img
                                    src={v.thumbnail}
                                    alt={v.title}
                                    className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                                  />
                                ) : (
                                  <div className="w-full h-full flex items-center justify-center bg-zinc-800">
                                    <Youtube className="w-6 h-6 text-red-500" />
                                  </div>
                                )}
                                <div className="absolute inset-0 bg-black/30 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                                  <Play className="w-6 h-6 text-white fill-white" />
                                </div>
                              </div>

                              <div className="flex-1 min-w-0 flex flex-col justify-between">
                                <span
                                  onClick={() => realBrowser.navigate(v.url)}
                                  className="text-xs font-bold text-white line-clamp-2 hover:text-cyan-300 cursor-pointer"
                                  title={v.title}
                                >
                                  {v.title}
                                </span>
                                <div className="flex items-center justify-between pt-1">
                                  <span className="text-[10px] text-zinc-400 truncate max-w-[110px]">
                                    {v.channel}
                                  </span>
                                  <div className="flex items-center space-x-1.5">
                                    <button
                                      type="button"
                                      onClick={() => realBrowser.navigate(v.url)}
                                      className="px-2 py-0.5 rounded bg-cyan-600/20 hover:bg-cyan-600/40 text-cyan-300 text-[10px] font-mono font-semibold cursor-pointer"
                                    >
                                      Play
                                    </button>
                                    <a
                                      href={v.url}
                                      target="_blank"
                                      rel="noopener noreferrer"
                                      className="p-1 rounded text-zinc-400 hover:text-white hover:bg-zinc-800"
                                      title="Open in external browser"
                                    >
                                      <ExternalLink className="w-3 h-3" />
                                    </a>
                                  </div>
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              ) : currentTab.url.includes('youtube.com/embed/') ? (
                /* CASE C: YouTube Embed Direct Video Player */
                <iframe
                  ref={iframeRef}
                  key={`${currentTab.id}_${currentTab.reloadKey || 0}`}
                  src={currentTab.url}
                  title={currentTab.title}
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                  allowFullScreen
                  className="w-full h-full border-0 bg-black"
                  onLoad={() => {
                    console.log(`[IntegratedBrowser] YouTube video loaded: ${currentTab.url}`);
                    setIsLoadingPage(false);
                    setIframeError(false);
                    realBrowser.setTabLoading(currentTab.id, false);
                  }}
                  onError={() => {
                    console.warn(`[IntegratedBrowser] YouTube video load error: ${currentTab.url}`);
                    setIsLoadingPage(false);
                    setIframeError(true);
                    realBrowser.setTabLoading(currentTab.id, false);
                  }}
                />
              ) : (
                /* CASE D: Standard Webpage through Proxy */
                <iframe
                  ref={iframeRef}
                  key={`${currentTab.id}_${currentTab.reloadKey || 0}_${currentTab.historyIndex}`}
                  src={`/api/browser/render?url=${encodeURIComponent(currentTab.url)}`}
                  title={currentTab.title}
                  sandbox="allow-scripts allow-same-origin allow-forms allow-popups allow-modals allow-downloads"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  className="w-full h-full border-0 bg-[#0b0f19]"
                  onLoad={() => {
                    console.log(`[IntegratedBrowser] Webpage loaded: ${currentTab.url}`);
                    setIsLoadingPage(false);
                    setIframeError(false);
                    realBrowser.setTabLoading(currentTab.id, false);
                  }}
                  onError={() => {
                    console.warn(`[IntegratedBrowser] Webpage error: ${currentTab.url}`);
                    setIsLoadingPage(false);
                    setIframeError(true);
                    realBrowser.setTabLoading(currentTab.id, false);
                  }}
                />
              )}

              {/* Informational overlay for sites with frame protection, network failures, or timeouts */}
              {iframeError && (
                <div className="absolute inset-0 z-20 flex flex-col items-center justify-center p-6 bg-zinc-950/95 text-center space-y-4 animate-in fade-in">
                  <div className="w-12 h-12 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center">
                    <AlertCircle className="w-6 h-6 text-amber-400" />
                  </div>
                  <div className="space-y-1.5 max-w-md">
                    <h3 className="text-sm sm:text-base font-bold text-white">
                      Cannot Display Webpage Inline
                    </h3>
                    <p className="text-xs text-zinc-400 leading-relaxed">
                      This website restricts inline iframe embedding for security (via X-Frame-Options or Content-Security-Policy), requires direct authentication, or timed out.
                    </p>
                    <div className="mt-2 p-2 rounded-lg bg-zinc-900 border border-zinc-800 font-mono text-[11px] text-cyan-300 break-all select-all">
                      {currentTab.url}
                    </div>
                  </div>

                  <div className="flex flex-wrap items-center justify-center gap-2.5 pt-2">
                    <button
                      type="button"
                      onClick={handleOpenExternally}
                      className="px-4 py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-black text-xs font-bold font-mono flex items-center space-x-2 transition-all cursor-pointer shadow-[0_0_15px_rgba(0,240,255,0.3)] active:scale-95"
                    >
                      <ExternalLink className="w-4 h-4" />
                      <span>Open in Chrome / Browser</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => realBrowser.reload()}
                      className="px-4 py-2.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-white text-xs font-mono font-medium flex items-center space-x-2 transition-all cursor-pointer active:scale-95"
                    >
                      <RefreshCw className="w-3.5 h-3.5" />
                      <span>Retry</span>
                    </button>
                    <button
                      type="button"
                      onClick={handleSummarize}
                      className="px-4 py-2.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 text-cyan-300 text-xs font-semibold flex items-center space-x-2 transition-all cursor-pointer active:scale-95"
                    >
                      <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
                      <span>Summarize with AI</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center p-6 text-center space-y-4">
              <Globe className="w-12 h-12 text-zinc-600" />
              <div className="space-y-1">
                <h3 className="text-sm font-bold text-white">MYRAA Real Integrated Browser</h3>
                <p className="text-xs text-zinc-400">Enter a URL or search prompt above to browse live websites.</p>
              </div>
            </div>
          )}

          {/* 5. AI SUMMARIZATION DRAWER */}
          {webSummary && (
            <div className="absolute bottom-0 left-0 right-0 z-40 max-h-[50%] p-4 bg-zinc-950/95 border-t border-cyan-500/40 shadow-2xl overflow-y-auto space-y-2.5 animate-in slide-in-from-bottom">
              <div className="flex items-center justify-between border-b border-zinc-800 pb-2">
                <div className="flex items-center space-x-2">
                  <Sparkles className="w-4 h-4 text-cyan-400" />
                  <span className="text-xs font-bold text-white truncate max-w-sm">
                    AI Summary: {webSummary.title}
                  </span>
                  {webSummary.wordCount && (
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-zinc-800 text-zinc-400">
                      {webSummary.wordCount} words
                    </span>
                  )}
                </div>
                <div className="flex items-center space-x-2">
                  <button
                    type="button"
                    onClick={() => geminiTts.speak(webSummary.summary)}
                    className="p-1.5 rounded-lg bg-cyan-600/20 hover:bg-cyan-600/40 text-cyan-300 cursor-pointer"
                    title="Read Summary aloud with Gemini TTS"
                  >
                    <Volume2 className="w-4 h-4" />
                  </button>
                  <button
                    type="button"
                    onClick={() => setWebSummary(null)}
                    className="p-1 rounded-lg hover:bg-zinc-800 text-zinc-400 hover:text-white cursor-pointer"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              </div>
              <p className="text-xs text-zinc-300 leading-relaxed font-sans">{webSummary.summary}</p>
            </div>
          )}
        </div>

        {/* 6. BOTTOM AUDIO PREVIEW MINI-BAR (When music preview is playing) */}
        {activeTrack && (
          <div className="px-4 py-2 bg-gradient-to-r from-zinc-950 via-[#121826] to-zinc-950 border-t border-cyan-500/30 flex items-center justify-between">
            <div className="flex items-center space-x-3">
              {activeTrack.artwork ? (
                <img src={activeTrack.artwork} alt={activeTrack.title} className="w-9 h-9 rounded-lg object-cover border border-zinc-700" />
              ) : (
                <div className="w-9 h-9 rounded-lg bg-cyan-950 flex items-center justify-center border border-cyan-500/40">
                  <Music className="w-4 h-4 text-cyan-400" />
                </div>
              )}
              <div>
                <span className="text-xs font-bold text-white block truncate max-w-xs">{activeTrack.title}</span>
                <span className="text-[10px] font-mono text-zinc-400">{activeTrack.artist} • 30s Audio Preview</span>
              </div>
            </div>

            <div className="flex items-center space-x-3">
              <button
                type="button"
                onClick={() => {
                  if (isTrackPlaying) realMedia.pauseMusic();
                  else realMedia.resumeMusic();
                }}
                className="p-2 rounded-full bg-cyan-500 hover:bg-cyan-400 text-black font-bold transition-transform active:scale-95 cursor-pointer"
              >
                {isTrackPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 fill-black" />}
              </button>
              <button
                type="button"
                onClick={() => realMedia.stopMusic()}
                className="p-1.5 rounded-lg text-zinc-400 hover:text-white hover:bg-zinc-800 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
