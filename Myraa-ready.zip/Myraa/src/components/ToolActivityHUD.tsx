import React from 'react';
import { ToolExecutionNotification } from '../types/live';
import { ExternalLink, Palette, Clock, Search, Sparkles, CheckCircle2 } from 'lucide-react';

interface ToolActivityHUDProps {
  notifications: ToolExecutionNotification[];
  onDismiss: (id: string) => void;
}

export const ToolActivityHUD: React.FC<ToolActivityHUDProps> = ({
  notifications,
  onDismiss,
}) => {
  if (notifications.length === 0) return null;

  const renderIcon = (iconName?: string) => {
    switch (iconName) {
      case 'ExternalLink':
        return <ExternalLink className="w-4 h-4 text-cyan-400" />;
      case 'Palette':
        return <Palette className="w-4 h-4 text-purple-400" />;
      case 'Clock':
        return <Clock className="w-4 h-4 text-amber-400" />;
      case 'Search':
        return <Search className="w-4 h-4 text-blue-400" />;
      case 'Sparkles':
        return <Sparkles className="w-4 h-4 text-rose-400" />;
      default:
        return <CheckCircle2 className="w-4 h-4 text-emerald-400" />;
    }
  };

  return (
    <div className="fixed top-20 left-1/2 -translate-x-1/2 z-40 w-full max-w-sm px-4 pointer-events-none flex flex-col items-center space-y-2">
      {notifications.map((item) => (
        <div
          key={item.id}
          className="pointer-events-auto flex items-center justify-between w-full px-4 py-2.5 rounded-2xl bg-zinc-900/90 border border-zinc-700/60 shadow-2xl backdrop-blur-xl animate-in fade-in slide-in-from-top-4 duration-300"
        >
          <div className="flex items-center space-x-3 overflow-hidden">
            <div className="p-2 rounded-xl bg-zinc-800/80 border border-zinc-700/50 flex-shrink-0">
              {renderIcon(item.iconName)}
            </div>
            <div className="flex flex-col text-left truncate">
              <span className="text-[10px] font-mono uppercase tracking-wider text-zinc-400">
                Action Executed
              </span>
              <span className="text-xs font-medium text-white truncate">
                {item.summary}
              </span>
            </div>
          </div>

          <div className="flex items-center space-x-1.5 flex-shrink-0 pl-2">
            {item.url && (
              <a
                href={item.url}
                target="_blank"
                rel="noopener noreferrer"
                className="px-2.5 py-1 text-[11px] font-medium rounded-lg bg-cyan-500/20 text-cyan-300 hover:bg-cyan-500/30 border border-cyan-500/30 transition-colors"
              >
                Visit
              </a>
            )}
            <button
              onClick={() => onDismiss(item.id)}
              className="p-1 text-zinc-400 hover:text-zinc-200 text-xs font-mono rounded"
              title="Dismiss"
            >
              ✕
            </button>
          </div>
        </div>
      ))}
    </div>
  );
};
