import React, { useState, useEffect } from 'react';
import { desktopCompanion, DesktopTelemetry } from '../services/DesktopCompanion';
import {
  Monitor,
  X,
  RefreshCw,
  Power,
  Volume2,
  VolumeX,
  Play,
  Camera,
  Lock,
  Code2,
  FileText,
  Music,
  Terminal,
  FolderOpen,
  AppWindow,
  Download,
  AlertTriangle,
  Key,
} from 'lucide-react';

interface PCControlPanelProps {
  isOpen: boolean;
  onClose: () => void;
  onNotification?: (msg: string) => void;
}

export const PCControlPanel: React.FC<PCControlPanelProps> = ({
  isOpen,
  onClose,
  onNotification,
}) => {
  const [pcState, setPcState] = useState<DesktopTelemetry>(() =>
    desktopCompanion.getState()
  );
  const [ipAddress, setIpAddress] = useState('192.168.1.50');
  const [isConnecting, setIsConnecting] = useState(false);
  const [pendingConfirmAction, setPendingConfirmAction] = useState<{
    command: string;
    label: string;
    description: string;
    params?: any;
  } | null>(null);

  useEffect(() => {
    const unsub = desktopCompanion.subscribe((state) => setPcState(state));
    return unsub;
  }, []);

  if (!isOpen) return null;

  const handlePair = async () => {
    setIsConnecting(true);
    const ok = await desktopCompanion.connectToLocalCompanion(ipAddress);
    setIsConnecting(false);
    if (ok) {
      onNotification?.('Connected successfully to Windows PC!');
    } else {
      onNotification?.('PC connection failed: Ensure Python companion script is running.');
    }
  };

  const handleDownloadCompanion = () => {
    const script = desktopCompanion.getCompanionScript();
    const blob = new Blob([script], { type: 'text/x-python' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'myraa_pc_companion.py';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    onNotification?.('myraa_pc_companion.py downloaded successfully.');
  };

  const handleAction = async (
    command: string,
    params: any = {},
    sensitive: boolean = false,
    label: string = '',
    desc: string = ''
  ) => {
    if (sensitive) {
      setPendingConfirmAction({ command, params, label, description: desc });
      return;
    }
    const res = await desktopCompanion.executeCommand(command, {
      ...params,
      simulate: true,
    });
    onNotification?.(res.message);
  };

  const confirmAction = async () => {
    if (!pendingConfirmAction) return;
    const res = await desktopCompanion.executeCommand(
      pendingConfirmAction.command,
      { ...pendingConfirmAction.params, simulate: true }
    );
    onNotification?.(res.message);
    setPendingConfirmAction(null);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div
        className="relative w-full max-w-xl max-h-[88vh] flex flex-col rounded-3xl bg-zinc-950 border-2 border-blue-500/50 shadow-[0_0_50px_rgba(59,130,246,0.25)] text-white overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-zinc-800 bg-zinc-900/60">
          <div className="flex items-center space-x-3">
            <div className="p-2.5 rounded-2xl bg-blue-500/15 text-blue-400 border border-blue-500/40 shadow-[0_0_12px_rgba(59,130,246,0.3)]">
              <Monitor className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h2 className="text-base font-bold font-mono tracking-wider">
                  MYRAA PC COMPANION
                </h2>
                <span
                  className={`px-2 py-0.5 rounded-full text-[10px] font-mono border ${
                    pcState.isConnected
                      ? 'bg-emerald-500/10 text-emerald-300 border-emerald-500/30'
                      : 'bg-zinc-800 text-zinc-400 border-zinc-700'
                  }`}
                >
                  {pcState.isConnected ? 'LINKED' : 'STANDBY'}
                </span>
              </div>
              <p className="text-xs text-zinc-400 font-mono">
                Secure Windows Computer Remote Control
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Sensitive Action Confirmation Dialog */}
        {pendingConfirmAction && (
          <div className="absolute inset-0 z-50 flex items-center justify-center p-6 bg-black/90 backdrop-blur-sm animate-in fade-in">
            <div className="p-6 rounded-2xl bg-zinc-900 border border-red-500 max-w-sm w-full space-y-4 text-center">
              <AlertTriangle className="w-10 h-10 text-red-500 mx-auto" />
              <h3 className="text-sm font-bold text-white font-mono uppercase">
                Confirmation Required
              </h3>
              <p className="text-xs text-zinc-300">
                Are you sure you want to execute{' '}
                <strong>{pendingConfirmAction.label}</strong>?
              </p>
              <p className="text-[11px] text-zinc-500">
                {pendingConfirmAction.description}
              </p>
              <div className="flex items-center justify-center space-x-3 pt-2">
                <button
                  onClick={() => setPendingConfirmAction(null)}
                  className="px-4 py-2 rounded-xl text-xs bg-zinc-800 hover:bg-zinc-700 text-zinc-300"
                >
                  Cancel
                </button>
                <button
                  onClick={confirmAction}
                  className="px-4 py-2 rounded-xl text-xs bg-red-600 hover:bg-red-500 text-white font-bold"
                >
                  Confirm Execution
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-5">
          {/* Section 1: Pairing Hub */}
          <div className="p-4 rounded-2xl bg-zinc-900/60 border border-zinc-800 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-mono font-bold text-white uppercase">
                Pairing Key
              </span>
              <button
                onClick={() => desktopCompanion.generatePairingCode()}
                className="text-[11px] font-mono text-cyan-400 hover:underline flex items-center space-x-1"
              >
                <RefreshCw className="w-3 h-3" />
                <span>Generate New Key</span>
              </button>
            </div>

            <div className="flex items-center justify-between p-3 rounded-xl bg-zinc-950 border border-blue-500/40">
              <span className="text-lg font-mono font-bold tracking-widest text-cyan-300">
                {pcState.pairingCode}
              </span>
              <button
                onClick={handleDownloadCompanion}
                className="flex items-center space-x-1 px-3 py-1.5 rounded-lg bg-blue-600/30 text-blue-300 hover:bg-blue-600/40 border border-blue-500/40 text-xs font-mono"
                title="Download Python companion script"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Script (.py)</span>
              </button>
            </div>

            <div className="flex items-center space-x-2 pt-1">
              <input
                type="text"
                value={ipAddress}
                onChange={(e) => setIpAddress(e.target.value)}
                placeholder="PC IP (e.g. 192.168.1.50)"
                className="flex-1 px-3 py-1.5 rounded-xl bg-zinc-950 border border-zinc-700 text-xs text-white placeholder-zinc-500 font-mono"
              />
              <button
                onClick={handlePair}
                disabled={isConnecting}
                className="px-4 py-1.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 disabled:opacity-50 text-xs font-mono font-bold text-white"
              >
                {isConnecting ? 'Connecting...' : 'Connect'}
              </button>
            </div>
          </div>

          {/* Section 2: Approved PC Applications */}
          <div className="space-y-2.5">
            <span className="text-xs font-mono font-medium tracking-wider text-zinc-400 uppercase">
              Approved Applications
            </span>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {[
                {
                  name: 'Chrome',
                  app: 'chrome',
                  icon: <AppWindow className="w-4 h-4 text-blue-400" />,
                },
                {
                  name: 'VS Code',
                  app: 'vscode',
                  icon: <Code2 className="w-4 h-4 text-cyan-400" />,
                },
                {
                  name: 'Notepad',
                  app: 'notepad',
                  icon: <FileText className="w-4 h-4 text-amber-400" />,
                },
                {
                  name: 'Spotify',
                  app: 'spotify',
                  icon: <Music className="w-4 h-4 text-emerald-400" />,
                },
                {
                  name: 'Terminal',
                  app: 'terminal',
                  icon: <Terminal className="w-4 h-4 text-purple-400" />,
                },
                {
                  name: 'Calculator',
                  app: 'calc',
                  icon: <FolderOpen className="w-4 h-4 text-rose-400" />,
                },
              ].map((item) => (
                <button
                  key={item.app}
                  onClick={() =>
                    handleAction(
                      'open_app',
                      { app: item.name },
                      false,
                      `Launch ${item.name}`
                    )
                  }
                  className="p-3 rounded-2xl bg-zinc-900/60 border border-zinc-800 hover:border-blue-500/50 hover:bg-zinc-850 flex items-center space-x-2.5 transition-all text-left"
                >
                  <div className="p-2 rounded-xl bg-zinc-800">{item.icon}</div>
                  <span className="text-xs font-mono text-zinc-300 truncate">
                    {item.name}
                  </span>
                </button>
              ))}
            </div>
          </div>

          {/* Section 3: Media & System Remote Controls */}
          <div className="space-y-2.5">
            <span className="text-xs font-mono font-medium tracking-wider text-zinc-400 uppercase">
              Media & System Controls
            </span>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              <button
                onClick={() => handleAction('volume_up')}
                className="p-3 rounded-2xl bg-zinc-900/60 border border-zinc-800 hover:border-cyan-500/50 flex items-center justify-center space-x-2 text-xs font-mono text-zinc-300"
              >
                <Volume2 className="w-4 h-4 text-cyan-400" />
                <span>Volume +</span>
              </button>
              <button
                onClick={() => handleAction('volume_down')}
                className="p-3 rounded-2xl bg-zinc-900/60 border border-zinc-800 hover:border-cyan-500/50 flex items-center justify-center space-x-2 text-xs font-mono text-zinc-300"
              >
                <VolumeX className="w-4 h-4 text-cyan-400" />
                <span>Volume -</span>
              </button>
              <button
                onClick={() => handleAction('play_pause')}
                className="p-3 rounded-2xl bg-zinc-900/60 border border-zinc-800 hover:border-cyan-500/50 flex items-center justify-center space-x-2 text-xs font-mono text-zinc-300"
              >
                <Play className="w-4 h-4 text-emerald-400" />
                <span>Play / Pause</span>
              </button>
              <button
                onClick={() => handleAction('screenshot')}
                className="p-3 rounded-2xl bg-zinc-900/60 border border-zinc-800 hover:border-cyan-500/50 flex items-center justify-center space-x-2 text-xs font-mono text-zinc-300"
              >
                <Camera className="w-4 h-4 text-amber-400" />
                <span>Screenshot</span>
              </button>
            </div>
          </div>

          {/* Section 4: Sensitive Actions (Requires Explicit Confirmation) */}
          <div className="space-y-2 p-3.5 rounded-2xl bg-red-950/20 border border-red-500/30">
            <div className="flex items-center space-x-2 text-xs font-mono text-red-400 font-bold uppercase">
              <AlertTriangle className="w-4 h-4 text-red-400" />
              <span>Sensitive Actions (Confirmation Required)</span>
            </div>
            <div className="flex items-center space-x-2">
              <button
                onClick={() =>
                  handleAction(
                    'lock_pc',
                    {},
                    true,
                    'Lock PC Workstation',
                    'This will immediately lock your Windows PC workstation.'
                  )
                }
                className="flex-1 px-3 py-2 rounded-xl bg-zinc-900 border border-red-500/50 hover:bg-red-500/20 text-xs font-mono text-red-300 flex items-center justify-center space-x-2"
              >
                <Lock className="w-4 h-4" />
                <span>Lock Windows Screen</span>
              </button>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3 bg-zinc-900/80 border-t border-zinc-800 flex items-center justify-between text-[11px] font-mono text-zinc-400">
          <span>End-to-End Local WebSocket Token Auth</span>
          <span className="text-blue-400">Windows 10 / 11 Compatible</span>
        </div>
      </div>
    </div>
  );
};
