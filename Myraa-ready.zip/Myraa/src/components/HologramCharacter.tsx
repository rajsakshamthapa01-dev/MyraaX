import React, { useEffect, useRef, useState, useMemo } from 'react';
import { ConnectionState, MoodConfig, AssistantEmotion } from '../types/live';
import { EMOTIONS } from '../constants/emotions';

interface HologramCharacterProps {
  state: ConnectionState;
  userVolume: number;
  assistantVolume: number;
  mood: MoodConfig;
  emotion?: AssistantEmotion;
  isMuted: boolean;
  onToggleConnect: () => void;
  onInterrupt?: () => void;
}

interface Particle {
  x: number;
  y: number;
  size: number;
  speedY: number;
  speedX: number;
  opacity: number;
}

export const HologramCharacter: React.FC<HologramCharacterProps> = ({
  state,
  userVolume,
  assistantVolume,
  mood,
  emotion = 'joyful',
  onToggleConnect,
  onInterrupt,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const particlesRef = useRef<Particle[]>([]);
  const animFrameRef = useRef<number | null>(null);

  const emotionDef = useMemo(() => EMOTIONS[emotion] || EMOTIONS.joyful, [emotion]);

  const [useVideo, setUseVideo] = useState<boolean>(true);
  const [videoLoaded, setVideoLoaded] = useState<boolean>(false);

  const activeVol = state === 'SPEAKING' ? assistantVolume : state === 'LISTENING' ? userVolume : 0;

  // Dynamically adjust video playback rate depending on V.Y.R.O.N's real-time state
  useEffect(() => {
    const video = videoRef.current;
    if (!video || !useVideo) return;

    if (state === 'SPEAKING') {
      video.playbackRate = 1.05;
      video.play().catch(() => {});
    } else if (state === 'LISTENING') {
      video.playbackRate = 0.95;
      video.play().catch(() => {});
    } else if (state === 'THINKING') {
      video.playbackRate = 1.15;
      video.play().catch(() => {});
    } else if (state === 'DISCONNECTED') {
      video.playbackRate = 0.8;
      video.play().catch(() => {});
    } else {
      video.playbackRate = 1.0;
      video.play().catch(() => {});
    }
  }, [state, useVideo]);

  // Floating futuristic cyber particles canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const handleResize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };
    handleResize();
    window.addEventListener('resize', handleResize);

    const count = 40;
    particlesRef.current = Array.from({ length: count }, () => ({
      x: Math.random() * canvas.width,
      y: Math.random() * canvas.height,
      size: Math.random() * 2.2 + 0.8,
      speedY: -(Math.random() * 0.7 + 0.25),
      speedX: (Math.random() - 0.5) * 0.35,
      opacity: Math.random() * 0.7 + 0.2,
    }));

    const render = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      const speedMultiplier = state === 'SPEAKING' ? 2.0 : state === 'LISTENING' ? 1.3 : 0.75;

      for (const p of particlesRef.current) {
        p.y += p.speedY * speedMultiplier;
        p.x += p.speedX;

        if (p.y < 0) {
          p.y = canvas.height;
          p.x = Math.random() * canvas.width;
        }

        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fillStyle = mood.primaryColor || '#00f0ff';
        ctx.shadowColor = mood.primaryColor || '#00f0ff';
        ctx.shadowBlur = 8;
        ctx.globalAlpha = p.opacity * (state === 'DISCONNECTED' ? 0.35 : 0.85);
        ctx.fill();
        ctx.shadowBlur = 0;
      }
      ctx.globalAlpha = 1;

      animFrameRef.current = requestAnimationFrame(render);
    };

    render();

    return () => {
      window.removeEventListener('resize', handleResize);
      if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
    };
  }, [state, mood]);

  // Tap anywhere on the background toggles voice input or interrupts speech
  const handleTap = (e: React.MouseEvent) => {
    // Only handle if directly clicking background (not on buttons/inputs)
    const target = e.target as HTMLElement;
    if (target.closest('button') || target.closest('input') || target.closest('form')) {
      return;
    }

    if (state === 'DISCONNECTED') {
      onToggleConnect();
    } else if (state === 'SPEAKING' && onInterrupt) {
      onInterrupt();
    } else {
      onToggleConnect();
    }

    // Try playing video if audio/video got paused
    if (videoRef.current) {
      videoRef.current.play().catch(() => {});
    }
  };

  const scaleFactor = 1 + activeVol * 0.03;

  return (
    <div
      onClick={handleTap}
      className="fixed inset-0 w-full h-full overflow-hidden select-none cursor-pointer z-0"
      title={
        state === 'DISCONNECTED'
          ? 'Tap anywhere to start MYRAA'
          : state === 'SPEAKING'
          ? 'Tap anywhere to stop speaking'
          : 'Tap anywhere to talk to MYRAA'
      }
    >
      {/* FULL-SCREEN ANIME HOLOGRAM CHARACTER (Video with Image Fallback) */}
      <div
        className="absolute inset-0 w-full h-full transition-transform duration-300 ease-out pointer-events-none"
        style={{
          transform: `scale(${scaleFactor})`,
          filter:
            state === 'DISCONNECTED'
              ? 'brightness(0.85) contrast(1.02)'
              : state === 'SPEAKING'
              ? 'brightness(1.08) contrast(1.04)'
              : 'brightness(1.0) contrast(1.02)',
        }}
      >
        {useVideo ? (
          <video
            ref={videoRef}
            src="/vyron_character.mp4"
            poster="/anime_hologram_character.png"
            autoPlay
            loop
            muted
            playsInline
            onLoadedData={() => setVideoLoaded(true)}
            onError={() => {
              // Graceful fallback to static high-res anime hologram image
              setUseVideo(false);
            }}
            className="w-full h-full object-cover object-top sm:object-center pointer-events-none transition-opacity duration-700"
          />
        ) : (
          <img
            src="/anime_hologram_character.png"
            onError={(e) => {
              // Secondary fallback if png fails
              const target = e.currentTarget;
              target.src = '/vyron_hologram.jpg';
            }}
            alt="V.Y.R.O.N Anime Hologram"
            className="w-full h-full object-cover object-top sm:object-center pointer-events-none transition-opacity duration-700"
          />
        )}
      </div>

      {/* Cybernetic Radial Halo & Ambient Emotional Aura */}
      <div
        className="absolute inset-0 pointer-events-none transition-colors duration-1000"
        style={{
          background: `radial-gradient(circle at 50% 32%, ${emotionDef.auraColor}33 0%, ${mood.primaryColor}22 45%, transparent 70%)`,
          opacity: state === 'SPEAKING' ? 0.95 : state === 'LISTENING' ? 0.75 : 0.4,
        }}
      />

      {/* Subtle Holographic Scanlines Overlay */}
      <div
        className="absolute inset-0 pointer-events-none opacity-20 mix-blend-screen"
        style={{
          backgroundImage:
            'repeating-linear-gradient(0deg, rgba(0, 240, 255, 0.15) 0px, rgba(0, 240, 255, 0.15) 1px, transparent 2px, transparent 4px)',
        }}
      />

      {/* Soft Dark Navy Gradient at Bottom to Ensure Text / Controls Readability Without Covering Face */}
      <div className="absolute inset-0 bg-gradient-to-t from-[#020612]/95 via-[#020612]/45 to-transparent pointer-events-none" />

      {/* Subtle Top Gradient for Header Readability */}
      <div className="absolute top-0 inset-x-0 h-28 bg-gradient-to-b from-[#020612]/85 via-[#020612]/30 to-transparent pointer-events-none" />

      {/* Floating Hologram Cyber Particle Canvas */}
      <canvas
        ref={canvasRef}
        className="absolute inset-0 w-full h-full pointer-events-none z-10"
      />

      {/* Real-Time Hologram Speech Wave Ripple */}
      {state === 'SPEAKING' && (
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-10">
          <div
            className="w-72 h-72 sm:w-96 sm:h-96 rounded-full border border-cyan-400/40 animate-ping opacity-25"
            style={{ animationDuration: '1.6s' }}
          />
          <div
            className="w-56 h-56 sm:w-80 sm:h-80 rounded-full border border-blue-400/30 animate-pulse opacity-30"
            style={{ animationDuration: '1.2s' }}
          />
        </div>
      )}

      {/* Live Emotion & Human Presence Capsule */}
      {state !== 'DISCONNECTED' && (
        <div className="absolute top-16 sm:top-20 left-1/2 -translate-x-1/2 z-20 pointer-events-none transition-all duration-500 animate-in fade-in slide-in-from-top-2">
          <div
            className="px-3.5 py-1.5 rounded-full backdrop-blur-xl border flex items-center space-x-2 shadow-xl transition-all duration-700"
            style={{
              backgroundColor: `${emotionDef.auraColor}18`,
              borderColor: `${emotionDef.auraColor}55`,
              boxShadow: `0 0 25px ${emotionDef.auraColor}25`,
            }}
          >
            <span className="text-sm animate-bounce" style={{ animationDuration: '2s' }}>
              {emotionDef.emoji}
            </span>
            <span
              className="text-xs font-semibold tracking-wide drop-shadow-sm"
              style={{ color: emotionDef.auraColor }}
            >
              {emotionDef.label}
            </span>
            <span className="text-[10px] text-zinc-300/80 font-mono hidden sm:inline">
              • {emotionDef.tagline}
            </span>
          </div>
        </div>
      )}
    </div>
  );
};
