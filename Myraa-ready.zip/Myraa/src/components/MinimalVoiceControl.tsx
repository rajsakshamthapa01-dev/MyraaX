/**
 * MinimalVoiceControl - Real Functional Hardware-Inspired Voice Control Panel
 *
 * Faithfully matches the uploaded reference image:
 * 1. Sleek matte black horizontal control panel with rounded capsule edges.
 * 2. Real-time LED activity indicator above controls with dynamic light patterns:
 *    - OFF: Dim / inactive LEDs
 *    - INITIALIZING: Wave scanning animation
 *    - LISTENING: Cyan/teal dynamic glow reacting to user speech volume
 *    - PROCESSING: Amber/gold cycling neural pattern
 *    - SPEAKING: Pulsing cyan/white glow reacting to assistant volume
 *    - PAUSED: Steady warm amber indicator
 *    - ERROR: Solid alert red indicator
 * 3. Four functional controls arranged horizontally:
 *    - BUTTON A (Left): Settings / Configuration (opens MYRAA Settings Modal)
 *    - BUTTON B (Second): Pause / Resume (pauses mic input & stops speech output)
 *    - BUTTON C (Center-Right): Prominent Main Power button:
 *      * Pure white circular button with dark power icon and diffused white halo when ON
 *      * Dark matte circle with subtle power icon when OFF
 *      * Smooth press animation and complete session lifecycle management
 *    - BUTTON D (Right): Stop / Close X (stops interaction, releases mic, returns to idle)
 */

import React, { useEffect, useState } from 'react';
import { ConnectionState, MoodConfig } from '../types/live';
import {
  Power,
  Pause,
  Play,
  Settings,
  X,
  AlertCircle,
  Volume2,
} from 'lucide-react';

export type AssistantUIState =
  | 'OFF'
  | 'INITIALIZING'
  | 'LISTENING'
  | 'PROCESSING'
  | 'SPEAKING'
  | 'PAUSED'
  | 'ERROR';

interface MinimalVoiceControlProps {
  state: ConnectionState;
  userVolume: number;
  assistantVolume: number;
  mood: MoodConfig;
  isMuted: boolean;
  isInitializing?: boolean;
  errorMessage?: string | null;
  onToggleConnect: () => void;
  onTogglePause: () => void;
  onInterrupt: () => void;
  onStop: () => void;
  onOpenSettings: () => void;
  onClearError?: () => void;
  onQuickPrompt?: (prompt: string) => void;
}

export const MinimalVoiceControl: React.FC<MinimalVoiceControlProps> = ({
  state,
  userVolume,
  assistantVolume,
  mood,
  isMuted,
  isInitializing = false,
  errorMessage = null,
  onToggleConnect,
  onTogglePause,
  onInterrupt,
  onStop,
  onOpenSettings,
  onClearError,
}) => {
  const [scanStep, setScanStep] = useState(0);

  // Derive singular authoritative Assistant state
  const assistantState: AssistantUIState = (() => {
    if (errorMessage) return 'ERROR';
    if (isInitializing) return 'INITIALIZING';
    if (state === 'DISCONNECTED') return 'OFF';
    if (isMuted) return 'PAUSED';
    if (state === 'LISTENING') return 'LISTENING';
    if (state === 'THINKING') return 'PROCESSING';
    if (state === 'SPEAKING') return 'SPEAKING';
    if (state === 'READY') return 'LISTENING';
    return 'OFF';
  })();

  const isConnected = state !== 'DISCONNECTED';
  const isPowerOn = isConnected || isInitializing;

  // Animation cycle for INITIALIZING and PROCESSING states
  useEffect(() => {
    if (assistantState === 'INITIALIZING' || assistantState === 'PROCESSING') {
      const interval = setInterval(() => {
        setScanStep((prev) => (prev + 1) % 5);
      }, 160);
      return () => clearInterval(interval);
    }
  }, [assistantState]);

  // Compute status information
  const statusInfo = (() => {
    switch (assistantState) {
      case 'OFF':
        return {
          label: 'STANDBY',
          subLabel: 'TAP POWER TO START',
          textColor: 'text-zinc-500',
        };
      case 'INITIALIZING':
        return {
          label: 'INITIALIZING',
          subLabel: 'SYNCHRONIZING MICROPHONE...',
          textColor: 'text-cyan-400',
        };
      case 'LISTENING':
        return {
          label: 'LISTENING',
          subLabel: 'SPEAK IN HINDI OR ENGLISH',
          textColor: 'text-cyan-300',
        };
      case 'PROCESSING':
        return {
          label: 'PROCESSING',
          subLabel: 'ANALYZING NEURAL QUERY...',
          textColor: 'text-amber-400',
        };
      case 'SPEAKING':
        return {
          label: 'SPEAKING',
          subLabel: 'MYRAA 24kHz VOICE OUTPUT',
          textColor: 'text-cyan-200',
        };
      case 'PAUSED':
        return {
          label: 'PAUSED',
          subLabel: 'VOICE INPUT SUSPENDED',
          textColor: 'text-amber-400',
        };
      case 'ERROR':
        return {
          label: 'ERROR',
          subLabel: errorMessage || 'MICROPHONE ACCESS FAILED',
          textColor: 'text-red-400',
        };
    }
  })();

  // Render individual LED segment
  const renderLedBar = (index: number) => {
    let activeClass = 'bg-zinc-800/50 border-zinc-800/80';
    let style: React.CSSProperties = {};

    switch (assistantState) {
      case 'OFF':
        activeClass = 'bg-zinc-800/40 border border-zinc-800/60';
        break;

      case 'INITIALIZING': {
        const isCurrent = scanStep === index || Math.abs(scanStep - index) === 1;
        if (isCurrent) {
          activeClass = 'bg-cyan-300 shadow-[0_0_8px_#22d3ee] border-cyan-200';
        } else {
          activeClass = 'bg-cyan-950/40 border border-cyan-900/60';
        }
        break;
      }

      case 'LISTENING': {
        // Center segments react dynamically to speech volume
        const volScale = Math.min(1, Math.max(0.15, userVolume * 3.5));
        const heightMultiplier = index === 2 ? 1 : index === 1 || index === 3 ? 0.85 : 0.7;
        const currentHeight = Math.max(6, Math.min(22, 14 * volScale * heightMultiplier + 6));

        activeClass = 'bg-cyan-400 shadow-[0_0_10px_rgba(0,240,255,0.7)] border border-cyan-300';
        style = {
          height: `${currentHeight}px`,
          opacity: 0.5 + volScale * 0.5,
        };
        break;
      }

      case 'PROCESSING': {
        const isCurrent = scanStep === index;
        if (isCurrent) {
          activeClass = 'bg-amber-400 shadow-[0_0_10px_rgba(245,158,11,0.8)] border border-amber-300 scale-110';
        } else {
          activeClass = 'bg-amber-950/50 border border-amber-800/40';
        }
        break;
      }

      case 'SPEAKING': {
        const volScale = Math.min(1, Math.max(0.2, assistantVolume * 3.2));
        const heightMultiplier = index === 2 ? 1.1 : index === 1 || index === 3 ? 0.9 : 0.75;
        const currentHeight = Math.max(6, Math.min(24, 16 * volScale * heightMultiplier + 6));

        activeClass = 'bg-cyan-200 shadow-[0_0_12px_rgba(0,240,255,0.9)] border border-white';
        style = {
          height: `${currentHeight}px`,
          opacity: 0.6 + volScale * 0.4,
        };
        break;
      }

      case 'PAUSED':
        activeClass = 'bg-amber-400 shadow-[0_0_8px_rgba(245,158,11,0.6)] border border-amber-300';
        break;

      case 'ERROR':
        activeClass = 'bg-red-500 shadow-[0_0_10px_rgba(239,68,68,0.8)] border border-red-400 animate-pulse';
        break;
    }

    return (
      <div
        key={index}
        style={style}
        className={`w-2.5 sm:w-3 h-3.5 sm:h-4 rounded-[2px] mx-0.5 sm:mx-1 transition-all duration-150 ${activeClass}`}
      />
    );
  };

  // Render micro dot LED
  const renderDot = (key: string, isGlowing: boolean, colorClass: string) => {
    return (
      <div
        key={key}
        className={`w-1.5 h-1.5 rounded-full mx-0.5 transition-all duration-200 ${
          isGlowing
            ? `${colorClass} shadow-[0_0_6px_currentColor]`
            : 'bg-zinc-800/50 border border-zinc-800'
        }`}
      />
    );
  };

  const isDotGlowing =
    assistantState === 'LISTENING' ||
    assistantState === 'SPEAKING' ||
    assistantState === 'INITIALIZING';

  const dotColor =
    assistantState === 'ERROR'
      ? 'bg-red-500 text-red-500'
      : assistantState === 'PAUSED'
      ? 'bg-amber-400 text-amber-400'
      : 'bg-cyan-400 text-cyan-400';

  return (
    <div className="w-full max-w-[360px] mx-auto flex flex-col items-center select-none px-4 pb-6 pt-1">
      {/* 1. REAL-TIME LED STATUS INDICATOR (Style of reference image: · · · | █ | █ | █ | · · ·) */}
      <div className="flex flex-col items-center mb-3 space-y-1.5">
        {/* LED segments row */}
        <div className="flex items-center justify-center h-6 px-3 py-1 rounded-full bg-black/40 border border-zinc-800/50 backdrop-blur-sm shadow-inner">
          {/* Left micro dots */}
          <div className="flex items-center">
            {renderDot('l1', isDotGlowing, dotColor)}
            {renderDot('l2', isDotGlowing, dotColor)}
            {renderDot('l3', isDotGlowing, dotColor)}
          </div>

          {/* Left vertical divider line */}
          <div className="h-3 w-[1px] bg-zinc-800/80 mx-1.5" />

          {/* Center 5 vertical LED pill bars */}
          <div className="flex items-center justify-center">
            {[0, 1, 2, 3, 4].map((i) => renderLedBar(i))}
          </div>

          {/* Right vertical divider line */}
          <div className="h-3 w-[1px] bg-zinc-800/80 mx-1.5" />

          {/* Right micro dots */}
          <div className="flex items-center">
            {renderDot('r1', isDotGlowing, dotColor)}
            {renderDot('r2', isDotGlowing, dotColor)}
            {renderDot('r3', isDotGlowing, dotColor)}
          </div>
        </div>

        {/* Digital Status Sub-Label */}
        <div className="flex items-center space-x-1.5 text-[10px] font-mono tracking-wider">
          <span className={`font-semibold ${statusInfo.textColor}`}>
            [ {statusInfo.label} ]
          </span>
          <span className="text-zinc-500 font-mono hidden sm:inline">•</span>
          <span className="text-zinc-400 font-mono text-[9px] truncate max-w-[170px]">
            {statusInfo.subLabel}
          </span>
        </div>
      </div>

      {/* 2. ERROR BANNER (If microphone permission denied or network failure occurs) */}
      {errorMessage && (
        <div className="w-full mb-3 p-2 rounded-xl bg-red-950/80 border border-red-500/50 text-red-200 text-xs flex items-center justify-between animate-in fade-in">
          <div className="flex items-center space-x-2 truncate">
            <AlertCircle className="w-4 h-4 text-red-400 flex-shrink-0" />
            <span className="truncate text-[11px]">{errorMessage}</span>
          </div>
          {onClearError && (
            <button
              type="button"
              onClick={onClearError}
              className="p-1 rounded text-red-400 hover:text-white"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      )}

      {/* 3. SLEEK MATTE BLACK HARDWARE CONTROL PANEL (Exactly inspired by reference photo) */}
      <div
        className="relative w-full bg-[#0a0c10] border border-zinc-800/90 rounded-[32px] px-4 sm:px-5 py-3 shadow-[0_12px_36px_rgba(0,0,0,0.9),inset_0_1px_1px_rgba(255,255,255,0.08)] flex items-center justify-between transition-all duration-300"
        role="region"
        aria-label="MYRAA Voice Control Module"
      >
        {/* BUTTON A: SETTINGS / CONTROL (Far Left) */}
        <button
          type="button"
          onClick={onOpenSettings}
          className="w-10 h-10 sm:w-11 sm:h-11 rounded-full bg-zinc-900/90 hover:bg-zinc-800 border border-zinc-750 hover:border-cyan-400/70 text-zinc-300 hover:text-cyan-300 flex items-center justify-center transition-all duration-200 active:scale-90 shadow-md group focus:outline-none focus:ring-1 focus:ring-cyan-400/50"
          title="MYRAA Voice & Assistant Settings"
          aria-label="Open Voice Settings"
        >
          <Settings className="w-4 h-4 sm:w-5 sm:h-5 transition-transform duration-300 group-hover:rotate-45" />
        </button>

        {/* BUTTON B: PAUSE / RESUME (Second from Left) */}
        <button
          type="button"
          onClick={onTogglePause}
          disabled={!isConnected}
          className={`w-10 h-10 sm:w-11 sm:h-11 rounded-full flex items-center justify-center transition-all duration-200 active:scale-90 shadow-md focus:outline-none ${
            !isConnected
              ? 'bg-zinc-900/40 border border-zinc-850 text-zinc-650 opacity-40 cursor-not-allowed'
              : isMuted
              ? 'bg-amber-500/20 border-2 border-amber-400/80 text-amber-300 shadow-[0_0_14px_rgba(245,158,11,0.5)] scale-105'
              : 'bg-zinc-900/90 hover:bg-zinc-800 border border-zinc-750 hover:border-white/50 text-zinc-300 hover:text-white'
          }`}
          title={
            !isConnected
              ? 'Turn on MYRAA first'
              : isMuted
              ? 'Resume Voice Interaction (Unmute)'
              : 'Pause Voice Interaction (Mute)'
          }
          aria-label={isMuted ? 'Resume Voice Interaction' : 'Pause Voice Interaction'}
        >
          {isMuted ? (
            <Play className="w-4 h-4 sm:w-5 sm:h-5 fill-amber-300 text-amber-300 ml-0.5" />
          ) : (
            <Pause className="w-4 h-4 sm:w-5 sm:h-5 fill-current text-zinc-300" />
          )}
        </button>

        {/* BUTTON C: MAIN POWER BUTTON (Center-Right Prominent Circular Button) */}
        <div className="relative flex items-center justify-center">
          <button
            type="button"
            onClick={onToggleConnect}
            className={`w-14 h-14 sm:w-16 sm:h-16 rounded-full flex items-center justify-center transition-all duration-300 active:scale-95 focus:outline-none ${
              isPowerOn
                ? 'bg-white text-[#0a0c10] shadow-[0_0_24px_rgba(255,255,255,0.7),0_0_48px_rgba(255,255,255,0.25)] border-2 border-white scale-105'
                : 'bg-zinc-900 hover:bg-zinc-850 border-2 border-zinc-700/80 hover:border-zinc-500 text-zinc-400 hover:text-white shadow-inner'
            }`}
            title={isPowerOn ? 'Turn Off MYRAA (Standby)' : 'Turn On MYRAA (Activate Voice)'}
            aria-label={isPowerOn ? 'Turn Off Voice Assistant' : 'Turn On Voice Assistant'}
          >
            <Power
              className={`w-6 h-6 sm:w-7 sm:h-7 transition-transform duration-200 ${
                isPowerOn ? 'stroke-[2.5]' : 'stroke-[2]'
              }`}
            />
          </button>
        </div>

        {/* BUTTON D: CLOSE / STOP (Far Right) */}
        <button
          type="button"
          onClick={onStop}
          className="w-9 h-9 sm:w-10 sm:h-10 rounded-full bg-zinc-900/60 hover:bg-red-500/20 border border-zinc-800 hover:border-red-500/50 text-zinc-400 hover:text-red-300 flex items-center justify-center transition-all duration-200 active:scale-90 shadow-md focus:outline-none focus:ring-1 focus:ring-red-400/50"
          title="Stop / Dismiss Voice Session"
          aria-label="Stop Voice Interaction"
        >
          <X className="w-4 h-4 sm:w-4.5 sm:h-4.5" />
        </button>
      </div>

      {/* 4. SUBTLE HARDWARE BASE CAPTION */}
      <div className="flex items-center space-x-2 text-[10px] font-mono text-zinc-500 mt-2.5">
        <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
        <span>MYRAA NEURAL VOICE CORE</span>
        <span>•</span>
        <span>GOOGLE GEMINI 3.8</span>
      </div>
    </div>
  );
};
