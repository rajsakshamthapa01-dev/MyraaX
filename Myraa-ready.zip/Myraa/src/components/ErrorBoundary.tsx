import React, { Component, ErrorInfo, ReactNode } from 'react';
import { AlertCircle, RefreshCw, Sparkles } from 'lucide-react';

interface Props {
  children: ReactNode;
  fallbackName?: string;
}

interface State {
  hasError: boolean;
  error: Error | null;
  errorInfo: ErrorInfo | null;
}

export class ErrorBoundary extends Component<Props, State> {
  public state: State = {
    hasError: false,
    error: null,
    errorInfo: null,
  };

  public static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error, errorInfo: null };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('[MYRAA ErrorBoundary] Caught component error:', error, errorInfo);
    this.setState({ error, errorInfo });
  }

  private handleReset = () => {
    this.setState({ hasError: false, error: null, errorInfo: null });
  };

  private handleReload = () => {
    window.location.reload();
  };

  public render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen w-full bg-[#020612] text-white flex flex-col items-center justify-center p-6 select-none font-sans relative overflow-hidden">
          {/* Futuristic ambient background glow */}
          <div className="absolute inset-0 pointer-events-none bg-[radial-gradient(circle_at_50%_40%,rgba(0,240,255,0.1)_0%,transparent_60%)]" />
          
          <div className="relative z-10 max-w-md w-full bg-zinc-950/90 border border-cyan-500/30 rounded-3xl p-6 sm:p-8 shadow-[0_0_50px_rgba(0,240,255,0.15)] backdrop-blur-xl flex flex-col items-center text-center space-y-5 animate-in fade-in duration-300">
            {/* Hologram Core Icon */}
            <div className="w-16 h-16 rounded-2xl bg-cyan-500/20 border border-cyan-400/50 flex items-center justify-center shadow-[0_0_20px_rgba(0,240,255,0.4)]">
              <Sparkles className="w-8 h-8 text-cyan-400 animate-pulse" />
            </div>

            <div className="space-y-1">
              <div className="flex items-center justify-center space-x-2">
                <span className="text-xl font-bold font-mono tracking-widest text-white">MYRAA AI</span>
                <span className="px-2 py-0.5 text-[10px] font-mono font-semibold rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40">
                  RECOVERY MODE
                </span>
              </div>
              <p className="text-xs text-zinc-400 font-mono">
                {this.props.fallbackName || 'Core Interface'} encountered a temporary state anomaly.
              </p>
            </div>

            {/* Error Detail Capsule */}
            <div className="w-full bg-black/60 rounded-xl p-3 border border-zinc-800 text-left text-xs font-mono text-zinc-300 max-h-32 overflow-y-auto space-y-1">
              <div className="flex items-center space-x-1.5 text-amber-400 text-[11px] font-semibold">
                <AlertCircle className="w-3.5 h-3.5 flex-shrink-0" />
                <span>Diagnostics:</span>
              </div>
              <p className="text-zinc-400 text-[11px] break-words">
                {this.state.error?.message || 'Component failed to render.'}
              </p>
            </div>

            {/* Recovery Actions */}
            <div className="flex items-center space-x-3 w-full pt-1">
              <button
                type="button"
                onClick={this.handleReset}
                className="flex-1 py-2.5 px-4 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-black font-semibold text-xs tracking-wide transition-all shadow-[0_0_15px_rgba(0,240,255,0.3)] flex items-center justify-center space-x-2 active:scale-95 cursor-pointer"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>Recover Interface</span>
              </button>

              <button
                type="button"
                onClick={this.handleReload}
                className="py-2.5 px-4 rounded-xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 hover:border-cyan-500/40 text-zinc-300 hover:text-white text-xs font-mono transition-all flex items-center justify-center space-x-2 active:scale-95 cursor-pointer"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Reload</span>
              </button>
            </div>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
