import React, { useState } from 'react';
import { Send, MessageSquare } from 'lucide-react';

interface TextInputBarProps {
  onSendMessage: (text: string) => void;
  disabled?: boolean;
}

export const TextInputBar: React.FC<TextInputBarProps> = ({ onSendMessage, disabled }) => {
  const [text, setText] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = text.trim();
    if (!trimmed) return;
    onSendMessage(trimmed);
    setText('');
  };

  return (
    <form
      onSubmit={handleSubmit}
      className="w-full max-w-xl mx-auto px-4 flex items-center space-x-2 relative"
    >
      <div className="relative flex-1 flex items-center">
        <MessageSquare className="w-4 h-4 absolute left-3.5 text-cyan-400" />
        <input
          type="text"
          value={text}
          onChange={(e) => setText(e.target.value)}
          disabled={disabled}
          placeholder="Type a message or command (e.g. Chat, Open YouTube)..."
          className="w-full pl-10 pr-4 py-2.5 rounded-2xl bg-zinc-950/80 border border-cyan-500/40 text-xs font-mono text-white placeholder-zinc-500 focus:outline-none focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400/50 backdrop-blur-xl shadow-lg transition-all"
        />
      </div>

      <button
        type="submit"
        disabled={disabled || !text.trim()}
        className="p-2.5 rounded-2xl bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 disabled:opacity-40 text-white shadow-[0_0_15px_rgba(0,240,255,0.3)] transition-all flex items-center justify-center cursor-pointer"
        title="Send"
      >
        <Send className="w-4 h-4" />
      </button>
    </form>
  );
};
