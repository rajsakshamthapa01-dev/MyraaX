import React, { useState, useEffect, useRef } from 'react';
import {
  X,
  Play,
  Square,
  Pause,
  RotateCw,
  Eye,
  Sparkles,
  Volume2,
  VolumeX,
  ShieldCheck,
  AlertCircle,
  HelpCircle,
  Monitor,
  Maximize2,
  Minimize2,
  Send,
} from 'lucide-react';
import { screenShareService, ScreenShareStatus } from '../services/ScreenShareService';

interface ScreenShareModalProps {
  isOpen: boolean;
  onClose: () => void;
  onNotification?: (msg: string, icon?: string, status?: 'success' | 'warning' | 'error') => void;
}

export const ScreenShareModal: React.FC<ScreenShareModalProps> = ({
  isOpen,
  onClose,
  onNotification,
}) => {
  const [status, setStatus] = useState<ScreenShareStatus>(() => screenShareService.getStatus());
  const [customPrompt, setCustomPrompt] = useState('');
  const [isFullscreenPreview, setIsFullscreenPreview] = useState(false);
  const videoRef = useRef<HTMLVideoElement | null>(null);

  useEffect(() => {
    const unsub = screenShareService.subscribe((s) => {
      setStatus(s);
      if (s.errorMessage) {
        onNotification?.(s.errorMessage, 'AlertCircle', 'error');
      }
    });
    return unsub;
  }, [onNotification]);

  // Connect active MediaStream to the preview video element
  useEffect(() => {
    const stream = screenShareService.getMediaStream();
    if (videoRef.current && stream) {
      videoRef.current.srcObject = stream;
      videoRef.current.play().catch(() => {});
    }
  }, [status.hasStream, isOpen]);

  if (!isOpen) return null;

  const handleStartCapture = async () => {
    const ok = await screenShareService.startCapture();
    if (ok) {
      onNotification?.('Screen sharing active. ALYA can now view your screen.', 'Monitor', 'success');
    }
  };

  const handleStopCapture = () => {
    screenShareService.stopCapture();
    onNotification?.('Screen sharing stopped.', 'Square', 'warning');
  };

  const handleAnalyzeQuery = async (queryText: string) => {
    if (!queryText.trim()) return;
    onNotification?.('Analyzing visible screen with Gemini Vision...', 'Sparkles', 'success');
    const res = await screenShareService.analyzeScreen(queryText);
    if (res) {
      onNotification?.('Analysis completed', 'Sparkles', 'success');
    }
  };

  const quickQuestions = [
    { label: 'Screen par kya hai?', query: 'Meri screen par kya dikh raha hai? Vistaar se batao.' },
    { label: 'Fix this error', query: 'Is screen par jo error ya samasya dikh rahi hai, usko fix karne ka tarika batao.' },
    { label: 'Next step guidance', query: 'Is app ya page par mera agla step kya hona chahiye?' },
    { label: 'Summarize content', query: 'Summarize the text, data, and layout currently visible on this screen.' },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/85 backdrop-blur-md animate-in fade-in">
      <div
        className={`relative w-full flex flex-col bg-[#080d19] border border-cyan-500/35 rounded-2xl shadow-2xl overflow-hidden font-sans text-white transition-all duration-300 ${
          isFullscreenPreview ? 'max-w-6xl h-[95vh]' : 'max-w-4xl max-h-[90vh]'
        }`}
      >
        {/* 1. HEADER BAR */}
        <div className="flex items-center justify-between px-4 py-3 bg-zinc-950/90 border-b border-zinc-800">
          <div className="flex items-center space-x-2.5">
            <div className="w-8 h-8 rounded-xl bg-cyan-600/20 border border-cyan-500/40 flex items-center justify-center">
              <Monitor className="w-4 h-4 text-cyan-400" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h2 className="text-sm font-bold text-white tracking-wide">ALYA Visual Screen Understanding</h2>
                <span
                  className={`text-[10px] font-mono px-2 py-0.5 rounded-full border flex items-center space-x-1 ${
                    status.isSharing
                      ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                      : 'bg-zinc-800 text-zinc-400 border-zinc-700'
                  }`}
                >
                  <span
                    className={`w-1.5 h-1.5 rounded-full ${
                      status.isSharing ? 'bg-emerald-400 animate-pulse' : 'bg-zinc-500'
                    }`}
                  />
                  <span>{status.isSharing ? (status.isPaused ? 'PAUSED' : 'LIVE CAPTURE ACTIVE') : 'STANDBY'}</span>
                </span>
              </div>
              <p className="text-[11px] font-mono text-zinc-400">Gemini 2.5 Vision & Multimodal Intelligence</p>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <button
              type="button"
              onClick={() => setIsFullscreenPreview(!isFullscreenPreview)}
              className="p-1.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-zinc-400 hover:text-white border border-zinc-800"
              title={isFullscreenPreview ? 'Standard view' : 'Expand view'}
            >
              {isFullscreenPreview ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
            </button>
            <button
              type="button"
              onClick={onClose}
              className="p-1.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-zinc-400 hover:text-white border border-zinc-800"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* 2. MAIN PREVIEW & CANVAS VIEWPORT */}
        <div className="relative flex-1 bg-black flex flex-col items-center justify-center overflow-hidden min-h-[260px] max-h-[50vh]">
          {status.hasStream ? (
            <div className="relative w-full h-full flex items-center justify-center bg-black group">
              <video
                ref={videoRef}
                autoPlay
                playsInline
                muted
                className="w-full h-full object-contain max-h-[50vh]"
              />

              {/* Status Overlay HUD */}
              <div className="absolute top-3 left-3 flex items-center space-x-2 bg-black/70 backdrop-blur-md px-3 py-1.5 rounded-xl border border-zinc-800 text-xs font-mono">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                <span className="text-emerald-300 font-bold">STREAM ACTIVE</span>
                <span className="text-zinc-500">|</span>
                <span className="text-zinc-300">{status.isPaused ? 'Analysis Paused' : 'Ready for queries'}</span>
              </div>

              {status.isAnalyzing && (
                <div className="absolute inset-0 bg-black/60 backdrop-blur-sm flex flex-col items-center justify-center space-y-3 z-20">
                  <div className="w-12 h-12 rounded-2xl bg-cyan-600/30 border border-cyan-400 flex items-center justify-center animate-pulse">
                    <Sparkles className="w-6 h-6 text-cyan-400 animate-spin" />
                  </div>
                  <span className="text-sm font-mono text-cyan-300 font-semibold tracking-wider">
                    ALYA INSPECTING SCREEN FRAMES...
                  </span>
                </div>
              )}
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center p-8 text-center space-y-4 max-w-md">
              <div className="w-16 h-16 rounded-3xl bg-cyan-600/10 border border-cyan-500/30 flex items-center justify-center">
                <Monitor className="w-8 h-8 text-cyan-400" />
              </div>
              <div className="space-y-1.5">
                <h3 className="text-base font-bold text-white">Share Your Screen with ALYA</h3>
                <p className="text-xs text-zinc-400 leading-relaxed">
                  Allow ALYA to view your app, browser tab, or document. ALYA can explain errors, guide you step-by-step,
                  and answer questions about what is currently visible.
                </p>
              </div>

              <button
                type="button"
                onClick={handleStartCapture}
                className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-black font-bold text-xs tracking-wider uppercase shadow-lg shadow-cyan-500/20 transition-all flex items-center space-x-2"
              >
                <Play className="w-4 h-4 fill-black" />
                <span>Start Screen Sharing</span>
              </button>
            </div>
          )}
        </div>

        {/* 3. HARDWARE-STYLE CONTROLS STRIP */}
        <div className="px-4 py-2.5 bg-[#0b101e] border-t border-b border-zinc-800 flex flex-wrap items-center justify-between gap-2 text-xs">
          <div className="flex items-center space-x-2">
            {!status.isSharing ? (
              <button
                type="button"
                onClick={handleStartCapture}
                className="px-3 py-1.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-black font-bold flex items-center space-x-1.5 transition-all shadow-sm"
              >
                <Play className="w-3.5 h-3.5 fill-black" />
                <span>Start Sharing</span>
              </button>
            ) : (
              <button
                type="button"
                onClick={handleStopCapture}
                className="px-3 py-1.5 rounded-xl bg-rose-600/20 hover:bg-rose-600/30 text-rose-300 border border-rose-500/40 font-semibold flex items-center space-x-1.5 transition-all"
              >
                <Square className="w-3.5 h-3.5 fill-rose-400" />
                <span>Stop Sharing</span>
              </button>
            )}

            {status.isSharing && (
              <button
                type="button"
                onClick={() =>
                  status.isPaused ? screenShareService.resumeAnalysis() : screenShareService.pauseAnalysis()
                }
                className="px-3 py-1.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-zinc-300 border border-zinc-800 flex items-center space-x-1.5"
              >
                {status.isPaused ? <Play className="w-3.5 h-3.5" /> : <Pause className="w-3.5 h-3.5" />}
                <span>{status.isPaused ? 'Resume Analysis' : 'Pause Analysis'}</span>
              </button>
            )}

            <button
              type="button"
              onClick={() => screenShareService.toggleVoiceMute()}
              className={`p-1.5 rounded-xl border transition-all ${
                status.isVoiceMuted
                  ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                  : 'bg-zinc-900 text-zinc-400 border-zinc-800 hover:text-white'
              }`}
              title={status.isVoiceMuted ? 'Unmute ALYA Voice' : 'Mute ALYA Voice'}
            >
              {status.isVoiceMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
            </button>
          </div>

          <div className="flex items-center space-x-1.5 text-zinc-400 text-[11px] font-mono">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>Privacy Guard: Frames sent only upon user query</span>
          </div>
        </div>

        {/* 4. QUICK VOICE QUESTIONS CHIPS */}
        <div className="px-4 py-2 bg-[#0e1424] border-b border-zinc-800/60 flex items-center space-x-2 overflow-x-auto no-scrollbar text-xs">
          <span className="text-[10px] font-mono text-zinc-500 uppercase flex-shrink-0">Ask ALYA:</span>
          {quickQuestions.map((q) => (
            <button
              key={q.label}
              type="button"
              disabled={!status.isSharing || status.isAnalyzing}
              onClick={() => handleAnalyzeQuery(q.query)}
              className="px-2.5 py-1 rounded-lg bg-zinc-900/80 hover:bg-cyan-950/60 border border-zinc-800 hover:border-cyan-500/40 text-zinc-300 hover:text-cyan-300 text-[11px] font-mono transition-colors whitespace-nowrap disabled:opacity-40"
            >
              {q.label}
            </button>
          ))}
        </div>

        {/* 5. LATEST ANALYSIS RESULT & MANUAL PROMPT BAR */}
        <div className="p-4 bg-zinc-950/90 space-y-3 flex-1 overflow-y-auto">
          {status.latestAnalysis ? (
            <div className="p-3.5 rounded-2xl bg-cyan-950/20 border border-cyan-500/30 space-y-2 animate-in fade-in">
              <div className="flex items-center justify-between text-xs font-mono">
                <div className="flex items-center space-x-1.5 text-cyan-300 font-bold">
                  <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
                  <span>ALYA Screen Understanding</span>
                </div>
                <span className="text-[10px] text-zinc-500">
                  {new Date(status.latestAnalysis.timestamp).toLocaleTimeString()}
                </span>
              </div>

              <p className="text-xs text-zinc-200 leading-relaxed whitespace-pre-line font-sans">
                {status.latestAnalysis.text}
              </p>
            </div>
          ) : (
            <div className="p-3 rounded-xl bg-zinc-900/40 border border-zinc-800/60 text-xs text-zinc-400 flex items-center space-x-2">
              <HelpCircle className="w-4 h-4 text-zinc-500 flex-shrink-0" />
              <span>Tap any quick question above or type below to ask ALYA about anything on your screen.</span>
            </div>
          )}

          {/* Prompt Input Form */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              if (customPrompt.trim()) {
                handleAnalyzeQuery(customPrompt);
                setCustomPrompt('');
              }
            }}
            className="flex items-center space-x-2 pt-1"
          >
            <input
              type="text"
              value={customPrompt}
              onChange={(e) => setCustomPrompt(e.target.value)}
              placeholder="Ask a question about your screen..."
              disabled={!status.isSharing || status.isAnalyzing}
              className="flex-1 px-3.5 py-2 rounded-xl bg-black border border-zinc-800 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-cyan-400 disabled:opacity-40"
            />
            <button
              type="submit"
              disabled={!status.isSharing || status.isAnalyzing || !customPrompt.trim()}
              className="px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 disabled:opacity-40 text-black text-xs font-bold flex items-center space-x-1.5 transition-all"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Ask</span>
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
