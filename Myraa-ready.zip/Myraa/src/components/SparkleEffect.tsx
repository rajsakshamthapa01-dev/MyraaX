import React, { useEffect, useState } from 'react';

interface SparkleEffectProps {
  effect: string | null;
  onComplete: () => void;
}

interface Particle {
  id: number;
  x: number;
  y: number;
  size: number;
  color: string;
  delay: number;
}

export const SparkleEffect: React.FC<SparkleEffectProps> = ({ effect, onComplete }) => {
  const [particles, setParticles] = useState<Particle[]>([]);

  useEffect(() => {
    if (!effect) return;

    const colors = ['#f43f5e', '#ec4899', '#a855f7', '#06b6d4', '#fbbf24', '#ffffff'];
    const count = 30;
    const items: Particle[] = [];

    for (let i = 0; i < count; i++) {
      items.push({
        id: i,
        x: 50 + (Math.random() - 0.5) * 60, // percentage from center
        y: 50 + (Math.random() - 0.5) * 60,
        size: Math.random() * 8 + 4,
        color: colors[Math.floor(Math.random() * colors.length)],
        delay: Math.random() * 0.3,
      });
    }

    setParticles(items);

    const timer = setTimeout(() => {
      setParticles([]);
      onComplete();
    }, 1800);

    return () => clearTimeout(timer);
  }, [effect, onComplete]);

  if (!effect || particles.length === 0) return null;

  return (
    <div className="fixed inset-0 pointer-events-none z-50 overflow-hidden">
      {particles.map((p) => (
        <div
          key={p.id}
          className="absolute rounded-full animate-ping opacity-75"
          style={{
            left: `${p.x}%`,
            top: `${p.y}%`,
            width: `${p.size}px`,
            height: `${p.size}px`,
            backgroundColor: p.color,
            boxShadow: `0 0 12px ${p.color}`,
            animationDuration: '1.2s',
            animationDelay: `${p.delay}s`,
          }}
        />
      ))}
    </div>
  );
};
