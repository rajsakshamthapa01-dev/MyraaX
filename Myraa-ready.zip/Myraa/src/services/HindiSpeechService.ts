/**
 * HindiSpeechService
 * Dedicated Text-to-Speech (TTS) and Speech Recognition engine for MYRAA.
 *
 * Implements:
 * 1. Hindi TTS preferring lang="hi-IN".
 * 2. Device voice detection for native Hindi voices (hi-IN, Lekha, Swara, Neerja, Kalpana, Google हिन्दी).
 * 3. Graceful fallback with English UI notifications if no native Hindi voice exists.
 * 4. Speech Recognition supporting Hindi/English with clear English error reporting.
 */

export interface HindiVoiceInfo {
  voice: SpeechSynthesisVoice | null;
  hasNativeHindiVoice: boolean;
  voiceName: string;
  lang: string;
  advisoryMessage?: string;
}

export interface SpeechRecognitionCallbacks {
  onResult: (transcript: string, isFinal: boolean) => void;
  onStart?: () => void;
  onEnd?: () => void;
  onError?: (error: string) => void;
}

class HindiSpeechEngine {
  private voices: SpeechSynthesisVoice[] = [];
  private currentUtterance: SpeechSynthesisUtterance | null = null;
  private isSpeaking: boolean = false;
  private recognition: any = null;
  private isRecognizing: boolean = false;
  private voiceAdvisoryReported: boolean = false;

  constructor() {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      this.loadVoices();
      window.speechSynthesis.onvoiceschanged = () => {
        this.loadVoices();
      };
    }
  }

  private loadVoices(): void {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;
    this.voices = window.speechSynthesis.getVoices();
  }

  /**
   * Finds the best available Hindi voice on the user's device.
   * Checks for hi-IN, hi-*, and Hindi voice name identifiers.
   */
  public getBestHindiVoice(): HindiVoiceInfo {
    this.loadVoices();

    if (!this.voices || this.voices.length === 0) {
      return {
        voice: null,
        hasNativeHindiVoice: false,
        voiceName: 'Default System Voice',
        lang: 'hi-IN',
        advisoryMessage: 'No native Hindi voice found on device. Using system fallback voice (hi-IN).',
      };
    }

    // 1. Direct match: lang equals hi-IN or hi_IN
    const exactMatch = this.voices.find(
      (v) => v.lang.replace('_', '-').toLowerCase() === 'hi-in'
    );
    if (exactMatch) {
      return {
        voice: exactMatch,
        hasNativeHindiVoice: true,
        voiceName: exactMatch.name,
        lang: exactMatch.lang,
      };
    }

    // 2. Starts with hi-
    const hiPrefixMatch = this.voices.find((v) =>
      v.lang.toLowerCase().startsWith('hi')
    );
    if (hiPrefixMatch) {
      return {
        voice: hiPrefixMatch,
        hasNativeHindiVoice: true,
        voiceName: hiPrefixMatch.name,
        lang: hiPrefixMatch.lang,
      };
    }

    // 3. Name contains Hindi or known Hindi voice identifiers
    const nameMatch = this.voices.find((v) => {
      const lower = v.name.toLowerCase();
      return (
        lower.includes('hindi') ||
        lower.includes('हिन्दी') ||
        lower.includes('lekha') ||
        lower.includes('swara') ||
        lower.includes('neerja') ||
        lower.includes('kalpana') ||
        lower.includes('hemant')
      );
    });
    if (nameMatch) {
      return {
        voice: nameMatch,
        hasNativeHindiVoice: true,
        voiceName: nameMatch.name,
        lang: nameMatch.lang || 'hi-IN',
      };
    }

    // 4. Fallback: Find an Indian English voice or default voice, explicitly setting lang="hi-IN"
    const enInVoice = this.voices.find((v) =>
      v.lang.replace('_', '-').toLowerCase() === 'en-in'
    );
    const fallbackVoice = enInVoice || this.voices.find((v) => v.default) || this.voices[0] || null;

    return {
      voice: fallbackVoice,
      hasNativeHindiVoice: false,
      voiceName: fallbackVoice ? fallbackVoice.name : 'System Default',
      lang: 'hi-IN',
      advisoryMessage:
        'No native Hindi voice found on device. Using system fallback (hi-IN). For natural Hindi pronunciation, install a Hindi TTS voice in your device speech settings.',
    };
  }

  /**
   * Speak text in natural Hindi using SpeechSynthesis.
   * Text is expected to be Hindi in Devanagari script.
   */
  public speak(
    text: string,
    onStart?: () => void,
    onEnd?: () => void,
    onError?: (err: string) => void,
    onAdvisory?: (msg: string) => void
  ): void {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
      onError?.('Speech synthesis is not supported in this browser.');
      return;
    }

    // Cancel current speaking
    this.stop();

    // Clean text: strip markdown asterisks, brackets, or code blocks
    const cleanText = text
      .replace(/[*_#`~]/g, '')
      .replace(/\[.*?\]/g, '')
      .trim();

    if (!cleanText) return;

    const utterance = new SpeechSynthesisUtterance(cleanText);
    const voiceInfo = this.getBestHindiVoice();

    // Configure language and voice
    utterance.lang = 'hi-IN';
    if (voiceInfo.voice) {
      utterance.voice = voiceInfo.voice;
    }

    // Provide UI advisory once if device lacks native Hindi voice
    if (!voiceInfo.hasNativeHindiVoice && voiceInfo.advisoryMessage && !this.voiceAdvisoryReported) {
      this.voiceAdvisoryReported = true;
      onAdvisory?.(voiceInfo.advisoryMessage);
    }

    // Natural cadence settings
    utterance.rate = 0.95;
    utterance.pitch = 1.05;

    utterance.onstart = () => {
      this.isSpeaking = true;
      onStart?.();
    };

    utterance.onend = () => {
      this.isSpeaking = false;
      this.currentUtterance = null;
      onEnd?.();
    };

    utterance.onerror = (e) => {
      this.isSpeaking = false;
      this.currentUtterance = null;
      console.warn('[HindiSpeechService] Utterance error:', e);
      onError?.(e.error || 'Speech synthesis error occurred.');
    };

    this.currentUtterance = utterance;
    window.speechSynthesis.speak(utterance);
  }

  /**
   * Stop speech immediately
   */
  public stop(): void {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    this.isSpeaking = false;
    this.currentUtterance = null;
  }

  public getIsSpeaking(): boolean {
    return this.isSpeaking;
  }

  /**
   * Browser Speech Recognition (Web Speech API)
   * Recognizes spoken Hindi / English / Hinglish
   */
  public startRecognition(callbacks: SpeechRecognitionCallbacks): boolean {
    if (typeof window === 'undefined') return false;

    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      callbacks.onError?.('Web Speech Recognition is not supported in this browser.');
      return false;
    }

    try {
      if (this.recognition) {
        try {
          this.recognition.abort();
        } catch {}
      }

      const rec = new SpeechRecognition();
      rec.lang = 'hi-IN'; // Prefer Hindi recognition (also understands common Hinglish/English terms)
      rec.continuous = false;
      rec.interimResults = true;
      rec.maxAlternatives = 1;

      rec.onstart = () => {
        this.isRecognizing = true;
        callbacks.onStart?.();
      };

      rec.onresult = (event: any) => {
        let interimTranscript = '';
        let finalTranscript = '';

        for (let i = event.resultIndex; i < event.results.length; ++i) {
          if (event.results[i].isFinal) {
            finalTranscript += event.results[i][0].transcript;
          } else {
            interimTranscript += event.results[i][0].transcript;
          }
        }

        if (finalTranscript) {
          callbacks.onResult(finalTranscript.trim(), true);
        } else if (interimTranscript) {
          callbacks.onResult(interimTranscript.trim(), false);
        }
      };

      rec.onerror = (event: any) => {
        this.isRecognizing = false;
        if (event.error === 'not-allowed' || event.error === 'permission-denied') {
          callbacks.onError?.('Microphone Permission Required. Please allow microphone access in browser settings.');
        } else if (event.error === 'network') {
          callbacks.onError?.('Connection Error. Please check your internet connection.');
        } else if (event.error !== 'no-speech') {
          callbacks.onError?.(`Speech recognition error: ${event.error}`);
        }
      };

      rec.onend = () => {
        this.isRecognizing = false;
        callbacks.onEnd?.();
      };

      this.recognition = rec;
      rec.start();
      return true;
    } catch (err: any) {
      callbacks.onError?.(err?.message || 'Failed to start speech recognition.');
      return false;
    }
  }

  public stopRecognition(): void {
    if (this.recognition) {
      try {
        this.recognition.stop();
      } catch {}
      this.recognition = null;
    }
    this.isRecognizing = false;
  }

  public getIsRecognizing(): boolean {
    return this.isRecognizing;
  }
}

export const hindiSpeechService = new HindiSpeechEngine();
