/**
 * RealBrowserService - Integrated Browser Engine State & Tab Manager for MYRAA
 *
 * Implements:
 * 1. Multi-tab management (create, close, switch, reload).
 * 2. URL validation and search engine fallback (Google, DuckDuckGo, Bing, Wikipedia).
 * 3. History tracking with local storage persistence.
 * 4. Bookmarks management with local storage persistence.
 * 5. Page navigation (Back, Forward, Refresh, Stop).
 * 6. Reader and Summarizer state synchronization.
 */

export interface BrowserTab {
  id: string;
  title: string;
  url: string;
  displayUrl: string;
  favicon?: string;
  isLoading: boolean;
  canGoBack: boolean;
  canGoForward: boolean;
  historyStack: string[];
  historyIndex: number;
  reloadKey?: number;
}

export interface BookmarkItem {
  id: string;
  title: string;
  url: string;
  createdAt: number;
}

export interface HistoryItem {
  id: string;
  title: string;
  url: string;
  visitedAt: number;
}

export type SearchEngine = 'google' | 'duckduckgo' | 'bing' | 'wikipedia';

class RealBrowserService {
  private tabs: BrowserTab[] = [];
  private activeTabId: string = '';
  private searchEngine: SearchEngine = 'google';
  private bookmarks: BookmarkItem[] = [];
  private history: HistoryItem[] = [];
  private listeners: Set<() => void> = new Set();
  private isOpen: boolean = false;

  constructor() {
    this.loadStorage();
    if (this.tabs.length === 0) {
      this.createTab('https://www.google.com', 'Google');
    }
  }

  private loadStorage(): void {
    if (typeof window === 'undefined') return;
    try {
      const savedBm = localStorage.getItem('myraa_browser_bookmarks');
      if (savedBm) this.bookmarks = JSON.parse(savedBm);

      const savedHist = localStorage.getItem('myraa_browser_history');
      if (savedHist) this.history = JSON.parse(savedHist);

      const savedEngine = localStorage.getItem('myraa_browser_engine') as SearchEngine;
      if (savedEngine) this.searchEngine = savedEngine;
    } catch (e) {
      console.warn('[RealBrowserService] Storage read error:', e);
    }
  }

  private saveStorage(): void {
    if (typeof window === 'undefined') return;
    try {
      localStorage.setItem('myraa_browser_bookmarks', JSON.stringify(this.bookmarks));
      localStorage.setItem('myraa_browser_history', JSON.stringify(this.history.slice(0, 100)));
      localStorage.setItem('myraa_browser_engine', this.searchEngine);
    } catch {}
  }

  public subscribe(listener: () => void): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  private notify(): void {
    this.listeners.forEach((fn) => fn());
    this.saveStorage();
  }

  public getTabs(): BrowserTab[] {
    return this.tabs.map((tab) => ({
      ...tab,
      historyStack: Array.isArray(tab.historyStack) ? [...tab.historyStack] : [tab.url || 'https://www.google.com'],
    }));
  }

  public getActiveTab(): BrowserTab | undefined {
    const tab = this.getActiveTabInternal();
    if (!tab) return undefined;
    return {
      ...tab,
      historyStack: Array.isArray(tab.historyStack) ? [...tab.historyStack] : [tab.url || 'https://www.google.com'],
    };
  }

  private getActiveTabInternal(): BrowserTab | undefined {
    return this.tabs.find((t) => t.id === this.activeTabId) || this.tabs[0];
  }

  public getActiveTabId(): string {
    return this.activeTabId;
  }

  public isBrowserOpen(): boolean {
    return this.isOpen;
  }

  public openBrowser(targetUrl?: string): void {
    this.isOpen = true;
    if (targetUrl) {
      this.navigate(targetUrl);
    }
    this.notify();
  }

  public closeBrowser(): void {
    this.isOpen = false;
    this.notify();
  }

  public toggleBrowser(): void {
    this.isOpen = !this.isOpen;
    this.notify();
  }

  public setSearchEngine(engine: SearchEngine): void {
    this.searchEngine = engine;
    this.notify();
  }

  public getSearchEngine(): SearchEngine {
    return this.searchEngine;
  }

  /**
   * Extracts YouTube 11-character video ID from watch, share, shorts, or embed URLs.
   */
  public extractYouTubeVideoId(url: string): string | null {
    if (!url) return null;
    const raw = url.trim();

    // youtu.be/ID
    const shortMatch = raw.match(/youtu\.be\/([a-zA-Z0-9_-]{11})/);
    if (shortMatch) return shortMatch[1];

    // youtube.com/shorts/ID
    const shortsMatch = raw.match(/youtube\.com\/shorts\/([a-zA-Z0-9_-]{11})/);
    if (shortsMatch) return shortsMatch[1];

    // youtube.com/embed/ID
    const embedMatch = raw.match(/youtube\.com\/embed\/([a-zA-Z0-9_-]{11})/);
    if (embedMatch) return embedMatch[1];

    // youtube.com/watch?v=ID
    if (raw.includes('youtube.com') && raw.includes('v=')) {
      const match = raw.match(/[?&]v=([a-zA-Z0-9_-]{11})/);
      if (match) return match[1];
    }

    return null;
  }

  /**
   * Resolves raw text into a valid URL or search engine query URL.
   */
  public resolveUrl(input: string): string {
    const raw = input.trim();
    if (!raw) return 'https://www.google.com';

    // 1. YouTube video URL auto-conversion to supported embed player
    const ytId = this.extractYouTubeVideoId(raw);
    if (ytId) {
      return `https://www.youtube.com/embed/${ytId}?autoplay=1&enablejsapi=1`;
    }

    // 2. YouTube main website
    if (/^(https?:\/\/)?(www\.|m\.)?youtube\.com(\/)?$/i.test(raw)) {
      return 'https://www.youtube.com';
    }

    // 3. Check if input is a valid domain or starts with protocol
    const hasProtocol = raw.startsWith('http://') || raw.startsWith('https://');
    const hasDomain = /^([a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}(\/.*)?$/i.test(raw);

    if (hasProtocol) return raw;
    if (hasDomain) return `https://${raw}`;

    // 4. Otherwise, treat as search query
    switch (this.searchEngine) {
      case 'duckduckgo':
        return `https://duckduckgo.com/?q=${encodeURIComponent(raw)}`;
      case 'bing':
        return `https://www.bing.com/search?q=${encodeURIComponent(raw)}`;
      case 'wikipedia':
        return `https://en.wikipedia.org/wiki/Special:Search?search=${encodeURIComponent(raw)}`;
      case 'google':
      default:
        return `https://www.google.com/search?q=${encodeURIComponent(raw)}`;
    }
  }

  public createTab(url?: string, title?: string): BrowserTab {
    const finalUrl = url ? this.resolveUrl(url) : 'https://www.google.com';
    const displayUrl = url ? url.trim() : finalUrl;
    const tab: BrowserTab = {
      id: 'tab_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
      title: title || (finalUrl.includes('youtube.com') ? 'YouTube' : 'New Tab'),
      url: finalUrl,
      displayUrl: displayUrl,
      isLoading: true,
      canGoBack: false,
      canGoForward: false,
      historyStack: [finalUrl],
      historyIndex: 0,
      reloadKey: 1,
    };

    this.tabs.push(tab);
    this.activeTabId = tab.id;
    this.recordHistory(finalUrl, tab.title);
    this.notify();
    return { ...tab, historyStack: [...tab.historyStack] };
  }

  public closeTab(tabId: string): void {
    if (this.tabs.length <= 1) {
      this.createTab('https://www.google.com', 'Google');
    }

    const idx = this.tabs.findIndex((t) => t.id === tabId);
    if (idx !== -1) {
      this.tabs.splice(idx, 1);
      if (this.activeTabId === tabId) {
        const nextActive = this.tabs[Math.max(0, idx - 1)];
        this.activeTabId = nextActive ? nextActive.id : '';
      }
    }
    this.notify();
  }

  public setActiveTab(tabId: string): void {
    if (this.tabs.some((t) => t.id === tabId)) {
      this.activeTabId = tabId;
      this.notify();
    }
  }

  public setTabLoading(tabId: string, isLoading: boolean): void {
    const tab = this.tabs.find((t) => t.id === tabId);
    if (tab && tab.isLoading !== isLoading) {
      tab.isLoading = isLoading;
      this.notify();
    }
  }

  public navigate(input: string, tabId?: string): void {
    const targetTab = tabId ? this.tabs.find((t) => t.id === tabId) : this.getActiveTabInternal();
    if (!targetTab) {
      this.createTab(input);
      return;
    }

    const finalUrl = this.resolveUrl(input);
    const cleanDisplay = input.trim().startsWith('http') ? input.trim() : finalUrl;

    // If navigating to the exact current URL at the current index, just trigger reload
    if (targetTab.url === finalUrl && targetTab.historyStack[targetTab.historyIndex] === finalUrl) {
      targetTab.isLoading = true;
      targetTab.reloadKey = (targetTab.reloadKey || 0) + 1;
      this.notify();
      return;
    }

    // Truncate forward history when navigating from a back position
    if (targetTab.historyIndex < targetTab.historyStack.length - 1) {
      targetTab.historyStack = targetTab.historyStack.slice(0, targetTab.historyIndex + 1);
    }

    targetTab.historyStack.push(finalUrl);
    targetTab.historyIndex = targetTab.historyStack.length - 1;
    targetTab.url = finalUrl;
    targetTab.displayUrl = cleanDisplay;
    targetTab.isLoading = true;
    targetTab.canGoBack = targetTab.historyIndex > 0;
    targetTab.canGoForward = false;
    targetTab.reloadKey = (targetTab.reloadKey || 0) + 1;

    // Set title according to URL
    if (finalUrl.includes('youtube.com/embed/')) {
      targetTab.title = 'YouTube Player';
    } else if (finalUrl.includes('youtube.com')) {
      targetTab.title = 'YouTube';
    } else if (finalUrl.includes('wikipedia.org')) {
      targetTab.title = 'Wikipedia';
    } else if (finalUrl.includes('google.com')) {
      targetTab.title = 'Google';
    }

    this.recordHistory(finalUrl, targetTab.title);
    this.notify();
  }

  public goBack(tabId?: string): boolean {
    const tab = tabId ? this.tabs.find((t) => t.id === tabId) : this.getActiveTabInternal();
    if (!tab || typeof tab.historyIndex !== 'number' || tab.historyIndex <= 0 || !Array.isArray(tab.historyStack)) {
      return false;
    }

    tab.historyIndex -= 1;
    const prevUrl = tab.historyStack[tab.historyIndex] || 'https://www.google.com';
    tab.url = prevUrl;
    tab.displayUrl = prevUrl;
    tab.isLoading = true;
    tab.canGoBack = tab.historyIndex > 0;
    tab.canGoForward = tab.historyIndex < tab.historyStack.length - 1;
    tab.reloadKey = (tab.reloadKey || 0) + 1;
    this.notify();
    return true;
  }

  public goForward(tabId?: string): boolean {
    const tab = tabId ? this.tabs.find((t) => t.id === tabId) : this.getActiveTabInternal();
    if (!tab || typeof tab.historyIndex !== 'number' || !Array.isArray(tab.historyStack) || tab.historyIndex >= tab.historyStack.length - 1) {
      return false;
    }

    tab.historyIndex += 1;
    const nextUrl = tab.historyStack[tab.historyIndex] || 'https://www.google.com';
    tab.url = nextUrl;
    tab.displayUrl = nextUrl;
    tab.isLoading = true;
    tab.canGoBack = tab.historyIndex > 0;
    tab.canGoForward = tab.historyIndex < tab.historyStack.length - 1;
    tab.reloadKey = (tab.reloadKey || 0) + 1;
    this.notify();
    return true;
  }

  public reload(tabId?: string): void {
    const tab = tabId ? this.tabs.find((t) => t.id === tabId) : this.getActiveTab();
    if (!tab) return;

    tab.isLoading = true;
    tab.reloadKey = (tab.reloadKey || 0) + 1;
    this.notify();
  }

  public updateTabTitle(tabId: string, title: string): void {
    const tab = this.tabs.find((t) => t.id === tabId);
    if (tab && title) {
      tab.title = title;
      this.notify();
    }
  }

  public addBookmark(url: string, title: string): void {
    if (this.bookmarks.some((b) => b.url === url)) return;
    this.bookmarks.unshift({
      id: 'bm_' + Date.now(),
      title: title || url,
      url,
      createdAt: Date.now(),
    });
    this.notify();
  }

  public removeBookmark(id: string): void {
    this.bookmarks = this.bookmarks.filter((b) => b.id !== id);
    this.notify();
  }

  public isBookmarked(url: string): boolean {
    return this.bookmarks.some((b) => b.url === url);
  }

  public getBookmarks(): BookmarkItem[] {
    return [...this.bookmarks];
  }

  public getHistory(): HistoryItem[] {
    return [...this.history];
  }

  public clearHistory(): void {
    this.history = [];
    this.notify();
  }

  private recordHistory(url: string, title: string): void {
    if (!url || url.startsWith('about:')) return;
    this.history.unshift({
      id: 'hist_' + Date.now(),
      title: title || url,
      url,
      visitedAt: Date.now(),
    });
    if (this.history.length > 100) {
      this.history = this.history.slice(0, 100);
    }
  }
}

export const realBrowser = new RealBrowserService();
