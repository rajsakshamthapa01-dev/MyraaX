/**
 * GeminiTtsService - Real Google Gemini Text-to-Speech Engine for MYRAA
 *
 * Implements:
 * 1. Real API calls to the server-side `/api/tts` route utilizing Google GenAI SDK.
 * 2. Official Gemini TTS models:
 *    - Primary / Low-latency: 'gemini-3.8-flash-lite-tts'
 *    - Expressive / Voice Design: 'gemini-3.8-flash-tts'
 *    - Real-time live audio: 'gemini-3.8-live'
 *    (Explains transparently if 'gemini-3.1-preview' is requested, as 3.1 is not an audio model).
 * 3. 24kHz Unary WAV audio decoding and playback with cancellation on user interruption.
 * 4. Automatic, graceful fallback to Android / Web Speech TTS with clear provider status.
 * 5. Audio buffering, playback controls, and resource cleanup.
 */

import { VoiceName } from '../types/live';

export type TtsProvider = 'gemini' | 'system_fallback';

export interface TtsSynthesisResult {
  success: boolean;
  audio?: string; // base64 WAV
  mimeType?: string;
  sampleRate?: number;
  model?: string;
  voice?: string;
  notice?: string;
  error?: string;
  provider: TtsProvider;
}

export interface TtsStatus {
  isSpeaking: boolean;
  isPaused: boolean;
  provider: TtsProvider;
  currentModel: string;
  currentVoice: VoiceName;
  lastError: string | null;
  notice: string | null;
}

/**
 * Returns a natural speaking style guideline for Gemini 3.8 Flash TTS based on emotion or context.
 */
export function getEmotionStyle(emotion?: string, text?: string): string {
  const e = (emotion || '').toLowerCase();
  if (e === 'happy' || e === 'excited') {
    return 'Speak with genuine excitement, warmth, and a bright, uplifting tone.';
  }
  if (e === 'serious' || e === 'urgent' || e === 'alert') {
    return 'Speak calmly, clearly, authoritatively, and with precision.';
  }
  if (e === 'comforting' || e === 'gentle' || e === 'sad') {
    return 'Speak gently, patiently, and reassuringly with a warm, caring tone.';
  }
  if (e === 'playful' || e === 'amused') {
    return 'Use a light, expressive, slightly playful and witty delivery.';
  }
  return 'Speak naturally, warmly, and conversationally with clear pronunciation in Hindi and English.';
}

class GeminiTtsService {
  private audioCtx: AudioContext | null = null;
  private currentAudioSource: AudioBufferSourceNode | null = null;
  private currentHtmlAudio: HTMLAudioElement | null = null;
  private isSpeaking: boolean = false;
  private isPaused: boolean = false;
  private currentVoice: VoiceName = 'Aoede';
  private currentModel: string = 'gemini-3.8-flash-tts';
  private abortController: AbortController | null = null;
  private listeners: Set<(status: TtsStatus) => void> = new Set();
  private lastError: string | null = null;
  private currentNotice: string | null = null;
  private activeProvider: TtsProvider = 'gemini';

  constructor() {
    this.initAudioContext();
  }

  private initAudioContext(): void {
    if (typeof window !== 'undefined') {
      try {
        const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
        if (AudioContextClass && !this.audioCtx) {
          try {
            this.audioCtx = new AudioContextClass({ sampleRate: 24000 });
          } catch {
            this.audioCtx = new AudioContextClass();
          }
        }
      } catch (err) {
        console.warn('[GeminiTtsService] AudioContext initialization deferred:', err);
      }
    }
  }

  public getStatus(): TtsStatus {
    return {
      isSpeaking: this.isSpeaking,
      isPaused: this.isPaused,
      provider: this.activeProvider,
      currentModel: this.currentModel,
      currentVoice: this.currentVoice,
      lastError: this.lastError,
      notice: this.currentNotice,
    };
  }

  public subscribe(listener: (status: TtsStatus) => void): () => void {
    this.listeners.add(listener);
    listener(this.getStatus());
    return () => this.listeners.delete(listener);
  }

  private notify(): void {
    const s = this.getStatus();
    this.listeners.forEach((fn) => fn(s));
  }

  public setVoice(voice: VoiceName): void {
    this.currentVoice = voice;
    this.notify();
  }

  public setModel(model: string): void {
    this.currentModel = model;
    this.notify();
  }

  /**
   * Synthesizes text using the official Gemini TTS API endpoint.
   */
  public async synthesize(
    text: string,
    options?: { voice?: VoiceName; model?: string; style?: string }
  ): Promise<TtsSynthesisResult> {
    const cleanText = text.trim();
    if (!cleanText) {
      return { success: false, provider: 'gemini', error: 'Empty text prompt' };
    }

    this.stop(); // Stop any currently playing audio
    this.abortController = new AbortController();

    const voice = options?.voice || this.currentVoice;
    const model = options?.model || this.currentModel;

    try {
      const res = await fetch('/api/tts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: cleanText,
          voice,
          model,
          style: options?.style,
        }),
        signal: this.abortController.signal,
      });

      if (!res.ok) {
        const errorData = await res.json().catch(() => ({}));
        throw new Error(errorData.error || `HTTP ${res.status}: Failed to synthesize Gemini TTS`);
      }

      const data = await res.json();
      this.activeProvider = 'gemini';
      this.lastError = null;
      this.currentNotice = data.notice || null;
      this.notify();

      return {
        success: true,
        audio: data.audio,
        mimeType: data.mimeType || 'audio/wav',
        sampleRate: data.sampleRate || 24000,
        model: data.model || model,
        voice: data.voice || voice,
        notice: data.notice,
        provider: 'gemini',
      };
    } catch (err: any) {
      if (err.name === 'AbortError') {
        return { success: false, provider: 'gemini', error: 'Synthesis cancelled by user' };
      }

      console.warn('[GeminiTtsService] Gemini API synthesis failed, activating fallback:', err.message);
      this.activeProvider = 'system_fallback';
      this.lastError = err.message || 'TTS Error';
      this.notify();

      return {
        success: false,
        provider: 'system_fallback',
        error: err.message,
      };
    }
  }

  /**
   * Synthesizes and immediately plays the resulting audio with gapless buffering.
   * Cancels cleanly on user interruption.
   */
  public async speak(
    text: string,
    options?: { voice?: VoiceName; model?: string; style?: string; onEnd?: () => void }
  ): Promise<boolean> {
    const cleanText = text.trim();
    if (!cleanText) return false;

    this.stop();

    const result = await this.synthesize(cleanText, options);

    if (result.success && result.audio) {
      return await this.playBase64Wav(result.audio, options?.onEnd);
    }

    // Fallback: System TextToSpeech (Android / Web Speech Synthesis)
    return this.speakSystemFallback(cleanText, options?.onEnd);
  }

  /**
   * Decodes and plays a Base64-encoded WAV file returned by Gemini 3.8 TTS.
   */
  private async playBase64Wav(base64Audio: string, onEnd?: () => void): Promise<boolean> {
    try {
      this.initAudioContext();

      if (this.audioCtx) {
        if (this.audioCtx.state === 'suspended') {
          await this.audioCtx.resume();
        }

        // Convert base64 to ArrayBuffer
        const binaryString = window.atob(base64Audio);
        const len = binaryString.length;
        const bytes = new Uint8Array(len);
        for (let i = 0; i < len; i++) {
          bytes[i] = binaryString.charCodeAt(i);
        }

        // Decode full WAV buffer (44-byte RIFF header included)
        const audioBuffer = await this.audioCtx.decodeAudioData(bytes.buffer.slice(0));

        const source = this.audioCtx.createBufferSource();
        source.buffer = audioBuffer;
        source.connect(this.audioCtx.destination);

        this.currentAudioSource = source;
        this.isSpeaking = true;
        this.notify();

        source.onended = () => {
          this.isSpeaking = false;
          this.currentAudioSource = null;
          this.notify();
          onEnd?.();
        };

        source.start(0);
        return true;
      }
    } catch (webAudioErr) {
      console.warn('[GeminiTtsService] Web Audio decode failed, attempting HTMLAudio fallback:', webAudioErr);
    }

    // Secondary fallback: HTMLAudioElement with data URI
    try {
      const audioUrl = `data:audio/wav;base64,${base64Audio}`;
      const audio = new Audio(audioUrl);
      this.currentHtmlAudio = audio;
      this.isSpeaking = true;
      this.notify();

      audio.onended = () => {
        this.isSpeaking = false;
        this.currentHtmlAudio = null;
        this.notify();
        onEnd?.();
      };

      await audio.play();
      return true;
    } catch (htmlAudioErr) {
      console.error('[GeminiTtsService] HTMLAudio playback failed:', htmlAudioErr);
      this.isSpeaking = false;
      this.notify();
      return false;
    }
  }

  /**
   * Fallback to Browser SpeechSynthesis or Native Android TTS bridge when offline or unauthenticated.
   */
  private speakSystemFallback(text: string, onEnd?: () => void): boolean {
    if (typeof window === 'undefined') return false;

    // 1. Android Native TTS Bridge if present
    if ((window as any).Android && typeof (window as any).Android.executeCommand === 'function') {
      try {
        (window as any).Android.executeCommand(
          JSON.stringify({ action: 'speak_text', text })
        );
        this.activeProvider = 'system_fallback';
        this.isSpeaking = true;
        this.notify();
        setTimeout(() => {
          this.isSpeaking = false;
          this.notify();
          onEnd?.();
        }, Math.max(1500, text.length * 70));
        return true;
      } catch {}
    }

    // 2. Web Speech Synthesis API
    if ('speechSynthesis' in window) {
      try {
        window.speechSynthesis.cancel();
        const utterance = new SpeechSynthesisUtterance(text);
        utterance.rate = 0.95;
        utterance.pitch = 1.05;

        // Prefer Hindi or English female voice
        const voices = window.speechSynthesis.getVoices();
        const femaleVoice = voices.find(
          (v) =>
            v.lang.startsWith('hi') ||
            (v.lang.startsWith('en') && (v.name.includes('Female') || v.name.includes('Google') || v.name.includes('Zira') || v.name.includes('Samantha')))
        );
        if (femaleVoice) utterance.voice = femaleVoice;

        utterance.onstart = () => {
          this.activeProvider = 'system_fallback';
          this.isSpeaking = true;
          this.notify();
        };

        utterance.onend = () => {
          this.isSpeaking = false;
          this.notify();
          onEnd?.();
        };

        utterance.onerror = () => {
          this.isSpeaking = false;
          this.notify();
        };

        window.speechSynthesis.speak(utterance);
        return true;
      } catch (e) {
        console.warn('[GeminiTtsService] Web Speech fallback error:', e);
      }
    }

    return false;
  }

  /**
   * Pauses active speech playback across Web Audio, HTMLAudio, or System SpeechSynthesis.
   */
  public pause(): void {
    if (!this.isSpeaking || this.isPaused) return;

    if (this.audioCtx && this.audioCtx.state === 'running') {
      try {
        this.audioCtx.suspend();
      } catch {}
    }

    if (this.currentHtmlAudio && !this.currentHtmlAudio.paused) {
      try {
        this.currentHtmlAudio.pause();
      } catch {}
    }

    if (typeof window !== 'undefined' && 'speechSynthesis' in window && window.speechSynthesis.speaking) {
      try {
        window.speechSynthesis.pause();
      } catch {}
    }

    this.isPaused = true;
    this.notify();
  }

  /**
   * Resumes paused speech playback.
   */
  public resume(): void {
    if (!this.isPaused) return;

    if (this.audioCtx && this.audioCtx.state === 'suspended') {
      try {
        this.audioCtx.resume();
      } catch {}
    }

    if (this.currentHtmlAudio && this.currentHtmlAudio.paused) {
      try {
        this.currentHtmlAudio.play();
      } catch {}
    }

    if (typeof window !== 'undefined' && 'speechSynthesis' in window && window.speechSynthesis.paused) {
      try {
        window.speechSynthesis.resume();
      } catch {}
    }

    this.isPaused = false;
    this.notify();
  }

  /**
   * Stops playback immediately and clears all pending requests and buffers.
   * Triggered whenever the user interrupts MYRAA.
   */
  public stop(): void {
    this.isPaused = false;
    if (this.abortController) {
      this.abortController.abort();
      this.abortController = null;
    }

    if (this.currentAudioSource) {
      try {
        this.currentAudioSource.stop();
        this.currentAudioSource.disconnect();
      } catch {}
      this.currentAudioSource = null;
    }

    if (this.currentHtmlAudio) {
      try {
        this.currentHtmlAudio.pause();
        this.currentHtmlAudio.currentTime = 0;
      } catch {}
      this.currentHtmlAudio = null;
    }

    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      try {
        window.speechSynthesis.cancel();
      } catch {}
    }

    this.isSpeaking = false;
    this.notify();
  }
}

export const geminiTts = new GeminiTtsService();
