/**
 * LiveSession - Real-Time Audio Session Manager for MYRAA AI Assistant
 *
 * Implements:
 * 1. Google Gemini Live API integration using verified model ID 'gemini-3.8-live'.
 * 2. Automatic, graceful fallback to 'gemini-3.1-flash-live-preview' if gemini-3.8-live
 *    is not supported on the user's API key/account, explaining the actual error.
 * 3. Continuous microphone streaming and gapless audio chunk playback.
 * 4. Anti-Noise Interruption Shield:
 *    - Gating low-energy background chatter, TV noise, fan hum, and speaker echo.
 *    - Preserving genuine user interruptions when user deliberately speaks or taps stop.
 *    - Discarding stale audio chunks immediately upon intentional barge-in or stop.
 * 5. Robust WebSocket lifecycle management with clean resource disposal and safe reconnects.
 */

import { AudioPlayer } from '../audio/AudioPlayer';
import { AudioStreamer, InterruptionShieldMode } from '../audio/AudioStreamer';
import {
  AssistantMood,
  AssistantEmotion,
  ClientInitConfig,
  ConnectionState,
  LatencyMetrics,
  ToolExecutionNotification,
  VoiceName,
} from '../types/live';
import { ToolManager } from './ToolManager';
import { memoryCore } from './MemoryCore';

export interface LiveSessionCallbacks {
  onStateChange: (state: ConnectionState) => void;
  onUserVolume: (vol: number) => void;
  onAssistantVolume: (vol: number) => void;
  onNotification: (notif: ToolExecutionNotification) => void;
  onMoodChange: (mood: AssistantMood) => void;
  onEmotionChange?: (emotion: AssistantEmotion) => void;
  onEffectTrigger: (effect: string) => void;
  onOpenBrowser: (url: string) => void;
  onLatencyChange: (metrics: LatencyMetrics) => void;
  onError: (error: string) => void;
  onModelChange?: (model: string, isFallback: boolean, fallbackNotice?: string) => void;
}

export class LiveSession {
  private ws: WebSocket | null = null;
  private streamer: AudioStreamer | null = null;
  private player: AudioPlayer | null = null;
  private toolManager: ToolManager;
  private callbacks: LiveSessionCallbacks;
  private state: ConnectionState = 'DISCONNECTED';
  private pingInterval: number | null = null;
  private animFrameId: number | null = null;
  private isMuted: boolean = false;
  private intentionalInterruptionOccurred: boolean = false;
  private isDiscardingCurrentTurn: boolean = false;
  private intentionalDisconnect: boolean = false;
  private currentShieldMode: InterruptionShieldMode = 'high_protection';
  private activeModel: string = 'gemini-3.8-live';

  private currentConfig: ClientInitConfig = {
    voice: 'Aoede',
    mood: 'electric_cyan',
    language: 'hi',
  };

  constructor(callbacks: LiveSessionCallbacks) {
    this.callbacks = callbacks;

    this.toolManager = new ToolManager({
      onNotification: (notif) => this.callbacks.onNotification(notif),
      onMoodChange: (mood) => this.callbacks.onMoodChange(mood),
      onEmotionChange: (emotion) => this.callbacks.onEmotionChange?.(emotion),
      onEffectTrigger: (effect) => this.callbacks.onEffectTrigger(effect),
      onOpenBrowser: (url) => this.callbacks.onOpenBrowser(url),
    });
  }

  public getState(): ConnectionState {
    return this.state;
  }

  public getActiveModel(): string {
    return this.activeModel;
  }

  public getIsMuted(): boolean {
    return this.isMuted;
  }

  public setMuted(muted: boolean): void {
    this.isMuted = muted;
    if (this.streamer) {
      this.streamer.setMuted(muted);
    }
  }

  public setShieldMode(mode: InterruptionShieldMode): void {
    this.currentShieldMode = mode;
    if (this.streamer) {
      this.streamer.setShieldMode(mode);
    }
  }

  public getShieldMode(): InterruptionShieldMode {
    return this.currentShieldMode;
  }

  public setOutputVolume(vol: number): void {
    if (this.player) {
      this.player.setVolume(vol);
    }
  }

  /**
   * Explicit user interruption: triggered when user taps to stop, clicks "Stop Speaking",
   * or types a stop command. Cleanly stops current audio and notifies backend.
   */
  public interrupt(): void {
    this.intentionalInterruptionOccurred = true;
    this.isDiscardingCurrentTurn = true;

    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify({ type: 'interrupt' }));
    }

    if (this.player) {
      this.player.stopAndClear();
    }
    this.updateState('LISTENING');
  }

  public sendText(text: string): void {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.isDiscardingCurrentTurn = false;
      this.updateState('THINKING');
      this.ws.send(JSON.stringify({ type: 'text_input', text }));
    }
  }

  public async connect(config?: ClientInitConfig): Promise<void> {
    if (this.state === 'READY' || this.state === 'LISTENING' || this.state === 'SPEAKING') {
      return;
    }

    this.intentionalDisconnect = false;
    this.isDiscardingCurrentTurn = false;
    this.intentionalInterruptionOccurred = false;

    if (config) {
      this.currentConfig = { ...this.currentConfig, ...config };
    }

    this.updateState('READY');

    try {
      // 1. Initialize AudioPlayer with gapless queue and state tracking
      this.player = new AudioPlayer((isPlaying) => {
        if (this.state === 'DISCONNECTED') return;
        // Inform AudioStreamer so it can apply the Anti-Noise Shield while MYRAA is speaking
        if (this.streamer) {
          this.streamer.setAssistantSpeaking(isPlaying);
        }
        if (!isPlaying) {
          this.intentionalInterruptionOccurred = false;
        }
        this.updateState(isPlaying ? 'SPEAKING' : 'LISTENING');
      });
      await this.player.resume();

      // 2. Initialize AudioStreamer with Anti-Noise Shield and intentional barge-in detector
      this.streamer = new AudioStreamer(
        (base64Chunk, isIntentionalSpeech) => {
          if (this.ws && this.ws.readyState === WebSocket.OPEN && !this.isMuted) {
            if (isIntentionalSpeech) {
              this.isDiscardingCurrentTurn = false;
            }
            this.ws.send(JSON.stringify({ type: 'audio', audio: base64Chunk }));
          }
        },
        (userVol) => {
          this.callbacks.onUserVolume(userVol);
        },
        () => {
          // Genuine intentional user interruption: user spoke deliberately over MYRAA
          console.log('[LiveSession] Genuine intentional user barge-in detected.');
          this.intentionalInterruptionOccurred = true;
          this.isDiscardingCurrentTurn = true;

          if (this.ws && this.ws.readyState === WebSocket.OPEN) {
            this.ws.send(JSON.stringify({ type: 'interrupt' }));
          }

          if (this.player && this.player.isPlaying()) {
            this.player.stopAndClear();
            this.updateState('LISTENING');
          }
        }
      );
      this.streamer.setShieldMode(this.currentShieldMode);
      await this.streamer.start();

      // 3. Connect to Backend WebSocket
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const wsUrl = `${protocol}//${window.location.host}/live`;
      this.ws = new WebSocket(wsUrl);

      this.ws.onopen = () => {
        if (this.ws && this.ws.readyState === WebSocket.OPEN) {
          this.ws.send(
            JSON.stringify({
              type: 'init',
              config: {
                ...this.currentConfig,
                language: 'hi',
                memoryContext: memoryCore.getFormattedContext(),
              },
            })
          );
        }
        this.startPingLoop();
        this.startVisualizerLoop();
        this.updateState('LISTENING');
      };

      this.ws.onmessage = async (event) => {
        try {
          const msg = JSON.parse(event.data);
          this.handleServerMessage(msg);
        } catch (err) {
          console.error('[LiveSession] Message parse error:', err);
        }
      };

      this.ws.onerror = (err) => {
        console.error('[LiveSession] WebSocket error:', err);
        this.callbacks.onError('Connection Error: Unable to connect to MYRAA voice server.');
      };

      this.ws.onclose = (event) => {
        console.log('[LiveSession] WebSocket closed:', event.code, event.reason);
        if (this.intentionalDisconnect) {
          this.disconnect();
        } else {
          this.handleUnexpectedClose(event.reason);
        }
      };
    } catch (err: any) {
      console.error('[LiveSession] Connection startup error:', err);
      this.disconnect();
      this.callbacks.onError(err.message || 'Microphone Permission Required: Please enable microphone access.');
    }
  }

  private handleUnexpectedClose(reason?: string): void {
    this.cleanUpResources();
    this.updateState('DISCONNECTED');
    this.callbacks.onError(
      reason ? `Voice session closed (${reason}). Tap mic to reconnect.` : 'Connection closed. Tap mic to reconnect.'
    );
  }

  private async handleServerMessage(msg: any): Promise<void> {
    switch (msg.type) {
      case 'ready':
        this.activeModel = msg.model || 'gemini-3.8-live';
        this.isDiscardingCurrentTurn = false;
        if (this.callbacks.onModelChange) {
          this.callbacks.onModelChange(this.activeModel, Boolean(msg.isFallback), msg.fallbackNotice);
        }
        if (msg.fallbackNotice) {
          this.callbacks.onNotification({
            id: 'fallback-' + Date.now(),
            toolName: 'Model Fallback',
            summary: msg.fallbackNotice,
            iconName: 'AlertTriangle',
            timestamp: Date.now(),
            status: 'warning',
          });
        }
        this.updateState('LISTENING');
        break;

      case 'model_fallback_notice':
        console.warn('[LiveSession] Fallback Notice:', msg.message);
        if (msg.activeModel) {
          this.activeModel = msg.activeModel;
        }
        if (this.callbacks.onModelChange) {
          this.callbacks.onModelChange(this.activeModel, true, msg.message);
        }
        this.callbacks.onNotification({
          id: 'model-notice-' + Date.now(),
          toolName: 'Live Model Alternative',
          summary: msg.message || `Switched to ${msg.activeModel} (${msg.error})`,
          iconName: 'Info',
          timestamp: Date.now(),
          status: 'warning',
        });
        break;

      case 'audio':
        // If user recently interrupted this turn, discard residual trailing audio chunks
        if (this.isDiscardingCurrentTurn) {
          break;
        }
        if (msg.audio && this.player) {
          this.player.playChunk(msg.audio);
        }
        break;

      case 'turn_complete':
        this.isDiscardingCurrentTurn = false;
        if (this.player) {
          this.player.markTurnComplete();
        }
        break;

      case 'interrupted':
        /**
         * TASK 2 — PREVENT UNWANTED INTERRUPTIONS:
         * Distinguish between:
         * 1. Actual genuine user interruptions (user deliberately spoke to interrupt or tapped stop).
         * 2. Stray background noise, TV chatter, door slam, or acoustic speaker bleed.
         *
         * If the user intentionally barged in or tapped stop: immediately stop playback and clear.
         * If it was a spurious server interruption while user did NOT intentionally speak:
         * DO NOT discard or reset the playback queue! Allow already-received audio to complete!
         */
        if (this.intentionalInterruptionOccurred) {
          console.log('[LiveSession] Confirmed intentional interruption: stopping playback queue.');
          this.isDiscardingCurrentTurn = true;
          if (this.player) {
            this.player.stopAndClear();
          }
          this.updateState('LISTENING');
          this.intentionalInterruptionOccurred = false;
        } else {
          console.log(
            '[LiveSession] Spurious server interruption ignored (background sound shielded, preserving audio playback).'
          );
        }
        break;

      case 'tool_call':
        if (msg.callId && msg.name) {
          const result = await this.toolManager.execute(msg.name, msg.args || {});
          if (this.ws && this.ws.readyState === WebSocket.OPEN) {
            this.ws.send(
              JSON.stringify({
                type: 'tool_response',
                callId: msg.callId,
                name: msg.name,
                response: { output: result },
              })
            );
          }
        }
        break;

      case 'pong':
        if (msg.timestamp) {
          const rtt = Date.now() - msg.timestamp;
          this.callbacks.onLatencyChange({
            roundTripMs: Math.max(1, rtt),
            lastPingTime: Date.now(),
          });
        }
        break;

      case 'session_closed':
        console.log('[LiveSession] Server signaled session_closed:', msg.reason);
        this.disconnect();
        break;

      case 'error':
        this.callbacks.onError(msg.message || 'Error received from MYRAA voice server.');
        break;

      default:
        break;
    }
  }

  private startPingLoop(): void {
    this.stopPingLoop();
    this.pingInterval = window.setInterval(() => {
      if (this.ws && this.ws.readyState === WebSocket.OPEN) {
        this.ws.send(
          JSON.stringify({
            type: 'ping',
            timestamp: Date.now(),
          })
        );
      }
    }, 4000);
  }

  private stopPingLoop(): void {
    if (this.pingInterval !== null) {
      clearInterval(this.pingInterval);
      this.pingInterval = null;
    }
  }

  private startVisualizerLoop(): void {
    const loop = () => {
      if (this.player && this.state === 'SPEAKING') {
        const energy = this.player.getPlaybackEnergy();
        this.callbacks.onAssistantVolume(energy);
      } else {
        this.callbacks.onAssistantVolume(0);
      }
      this.animFrameId = requestAnimationFrame(loop);
    };
    this.animFrameId = requestAnimationFrame(loop);
  }

  private stopVisualizerLoop(): void {
    if (this.animFrameId !== null) {
      cancelAnimationFrame(this.animFrameId);
      this.animFrameId = null;
    }
  }

  public updateVoice(voice: VoiceName): void {
    this.currentConfig.voice = voice;
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(
        JSON.stringify({
          type: 'reconnect',
          config: {
            ...this.currentConfig,
            voice,
            memoryContext: memoryCore.getFormattedContext(),
          },
        })
      );
    }
  }

  public updateMood(mood: AssistantMood): void {
    this.currentConfig.mood = mood;
    this.callbacks.onMoodChange(mood);
  }

  private cleanUpResources(): void {
    this.stopPingLoop();
    this.stopVisualizerLoop();
    this.intentionalInterruptionOccurred = false;
    this.isDiscardingCurrentTurn = false;

    if (this.streamer) {
      this.streamer.stop();
      this.streamer = null;
    }

    if (this.player) {
      this.player.close();
      this.player = null;
    }

    if (this.ws) {
      try {
        this.ws.onopen = null;
        this.ws.onmessage = null;
        this.ws.onerror = null;
        this.ws.onclose = null;
        if (this.ws.readyState === WebSocket.OPEN || this.ws.readyState === WebSocket.CONNECTING) {
          this.ws.close();
        }
      } catch {
        // Ignored
      }
      this.ws = null;
    }

    this.callbacks.onUserVolume(0);
    this.callbacks.onAssistantVolume(0);
  }

  public disconnect(): void {
    this.intentionalDisconnect = true;
    this.cleanUpResources();
    this.updateState('DISCONNECTED');
  }

  private updateState(newState: ConnectionState): void {
    if (this.state !== newState) {
      this.state = newState;
      this.callbacks.onStateChange(newState);
    }
  }
}
