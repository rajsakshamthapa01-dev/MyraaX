/**
 * AndroidBridge - Secure Native Android Bridge & Validated Agent for MYRAA
 *
 * Implements:
 * 1. Native Android WebView Bridge detection (window.Android).
 * 2. Validated action protocol with strict whitelisting (never executes arbitrary code).
 * 3. Verified execution results (APP_OPENED, PERMISSION_REQUIRED, APP_NOT_FOUND, ACTION_NOT_SUPPORTED, ACTION_FAILED, SUCCESS).
 * 4. Android Intent launching for installed apps (YouTube, Instagram, WhatsApp, Maps, Chrome, Camera, Dialer, etc.).
 * 5. Android AccessibilityService action dispatching:
 *    - Back, Home, Recent Apps, Notifications drawer, Quick Settings, Lock Screen, Screenshot
 *    - Scrolling (up/down)
 *    - Coordinate tapping & gestures (dispatchGesture)
 *    - Clicking accessible elements by text, ID, or description
 *    - Typing text and click-and-type
 *    - Spatial screen reading (read_accessible_ui)
 * 6. Native hardware controls (Torch, Settings, Dialer, Timer).
 * 7. Transparent browser fallback with accurate capability reporting.
 */

export type AndroidActionType =
  | 'open_app'
  | 'press_back'
  | 'press_home'
  | 'press_recents'
  | 'open_notifications'
  | 'open_quick_settings'
  | 'lock_screen'
  | 'take_screenshot'
  | 'scroll'
  | 'scroll_up'
  | 'scroll_down'
  | 'click_node'
  | 'tap_accessible_element'
  | 'tap_coordinates'
  | 'swipe'
  | 'type_text'
  | 'click_and_type'
  | 'read_accessible_ui'
  | 'resolve_contact'
  | 'send_message'
  | 'prepare_sms'
  | 'toggle_torch'
  | 'open_dialer'
  | 'open_settings'
  | 'open_accessibility_settings'
  | 'open_assistant_settings'
  | 'open_play_store'
  | 'set_timer'
  | 'browser_go_back'
  | 'long_press_element'
  | 'long_press_coordinates'
  | 'get_current_app'
  | 'stop_listening'
  | 'get_status';

export type AndroidExecutionStatus =
  | 'APP_OPENED'
  | 'PERMISSION_REQUIRED'
  | 'APP_NOT_FOUND'
  | 'AMBIGUOUS_MATCH'
  | 'ACTION_NOT_SUPPORTED'
  | 'ACTION_FAILED'
  | 'SUCCESS';

export interface AndroidActionRequest {
  action: AndroidActionType;
  target?: string;
  direction?: 'up' | 'down';
  text?: string;
  number?: string;
  recipient?: string;
  message?: string;
  app?: string;
  minutes?: number;
  label?: string;
  x?: number;
  y?: number;
  startX?: number;
  startY?: number;
  endX?: number;
  endY?: number;
  duration?: number;
  params?: Record<string, any>;
}

export interface AndroidExecutionResult {
  status: AndroidExecutionStatus;
  action: string;
  target?: string;
  message: string;
  timestamp: number;
  native: boolean;
  intentUrl?: string;
  data?: any;
}

export interface SupportedAppInfo {
  id: string;
  name: string;
  packageName: string;
  intentUrl: string;
  fallbackUrl: string;
  category: 'social' | 'media' | 'utility' | 'system';
}

export const SUPPORTED_ANDROID_APPS: Record<string, SupportedAppInfo> = {
  youtube: {
    id: 'youtube',
    name: 'YouTube',
    packageName: 'com.google.android.youtube',
    intentUrl: 'intent://#Intent;package=com.google.android.youtube;end',
    fallbackUrl: 'https://www.youtube.com',
    category: 'media',
  },
  instagram: {
    id: 'instagram',
    name: 'Instagram',
    packageName: 'com.instagram.android',
    intentUrl: 'intent://#Intent;package=com.instagram.android;end',
    fallbackUrl: 'https://www.instagram.com',
    category: 'social',
  },
  whatsapp: {
    id: 'whatsapp',
    name: 'WhatsApp',
    packageName: 'com.whatsapp',
    intentUrl: 'intent://#Intent;package=com.whatsapp;end',
    fallbackUrl: 'https://api.whatsapp.com/send',
    category: 'social',
  },
  chrome: {
    id: 'chrome',
    name: 'Google Chrome',
    packageName: 'com.android.chrome',
    intentUrl: 'intent://#Intent;package=com.android.chrome;end',
    fallbackUrl: 'https://www.google.com',
    category: 'utility',
  },
  maps: {
    id: 'maps',
    name: 'Google Maps',
    packageName: 'com.google.android.apps.maps',
    intentUrl: 'intent://#Intent;package=com.google.android.apps.maps;end',
    fallbackUrl: 'https://maps.google.com',
    category: 'utility',
  },
  camera: {
    id: 'camera',
    name: 'Camera',
    packageName: 'com.android.camera',
    intentUrl: 'intent:#Intent;action=android.media.action.IMAGE_CAPTURE;end',
    fallbackUrl: '',
    category: 'system',
  },
  phone: {
    id: 'phone',
    name: 'Phone Dialer',
    packageName: 'com.android.dialer',
    intentUrl: 'tel:',
    fallbackUrl: '',
    category: 'system',
  },
  settings: {
    id: 'settings',
    name: 'Android Settings',
    packageName: 'com.android.settings',
    intentUrl: 'intent:#Intent;action=android.settings.SETTINGS;end',
    fallbackUrl: '',
    category: 'system',
  },
  spotify: {
    id: 'spotify',
    name: 'Spotify',
    packageName: 'com.spotify.music',
    intentUrl: 'intent://#Intent;package=com.spotify.music;end',
    fallbackUrl: 'https://open.spotify.com',
    category: 'media',
  },
  telegram: {
    id: 'telegram',
    name: 'Telegram',
    packageName: 'org.telegram.messenger',
    intentUrl: 'intent://#Intent;package=org.telegram.messenger;end',
    fallbackUrl: 'https://web.telegram.org',
    category: 'social',
  },
};

class AndroidBridgeService {
  private isNativeAvailable: boolean = false;
  private isAccessibilityActiveFlag: boolean = false;
  private torchMediaTrack: MediaStreamTrack | null = null;
  private isTorchOn: boolean = false;

  constructor() {
    this.checkNativeAvailability();
    if (typeof window !== 'undefined') {
      (window as any).__onAndroidNativeReady = (data: { native: boolean; accessibility: boolean }) => {
        this.isNativeAvailable = Boolean(data?.native);
        this.isAccessibilityActiveFlag = Boolean(data?.accessibility);
        console.log('[AndroidBridge] Native ready signal received:', data);
      };
    }
  }

  /**
   * Checks whether the current runtime environment is an Android WebView
   * with the official `window.Android` JavaScriptInterface attached.
   */
  public checkNativeAvailability(): boolean {
    if (typeof window !== 'undefined' && (window as any).Android) {
      this.isNativeAvailable = true;
    } else {
      this.isNativeAvailable = false;
    }
    return this.isNativeAvailable;
  }

  public isNative(): boolean {
    return this.checkNativeAvailability();
  }

  public isAccessibilityActive(): boolean {
    if (!this.isNative()) return false;
    try {
      const statusRes = (window as any).Android.executeCommand(JSON.stringify({ action: 'get_status' }));
      const parsed = JSON.parse(statusRes);
      return Boolean(parsed.accessibilityActive);
    } catch {
      return this.isAccessibilityActiveFlag;
    }
  }

  /**
   * Executes a validated Android Action Request with strict parameter checking.
   * Returns a genuine execution status result.
   */
  public async executeCommand(request: AndroidActionRequest): Promise<AndroidExecutionResult> {
    const timestamp = Date.now();

    // 1. Validate action type against approved whitelist
    const approvedActions: AndroidActionType[] = [
      'open_app',
      'press_back',
      'press_home',
      'press_recents',
      'open_notifications',
      'open_quick_settings',
      'lock_screen',
      'take_screenshot',
      'scroll',
      'scroll_up',
      'scroll_down',
      'click_node',
      'tap_accessible_element',
      'long_press_element',
      'long_press_coordinates',
      'tap_coordinates',
      'swipe',
      'type_text',
      'click_and_type',
      'read_accessible_ui',
      'get_current_app',
      'resolve_contact',
      'send_message',
      'prepare_sms',
      'toggle_torch',
      'open_dialer',
      'open_settings',
      'open_accessibility_settings',
      'open_assistant_settings',
      'open_play_store',
      'set_timer',
      'browser_go_back',
      'stop_listening',
      'get_status',
    ];

    if (!approvedActions.includes(request.action)) {
      return {
        status: 'ACTION_NOT_SUPPORTED',
        action: request.action,
        message: `Action "${request.action}" is not permitted by ALYA Android Security Policy.`,
        timestamp,
        native: false,
      };
    }

    // 2. Delegate to Native Android Java Bridge if available in Android WebView
    if (this.isNative()) {
      try {
        const nativeResponseStr = (window as any).Android.executeCommand(JSON.stringify(request));
        const nativeResult = JSON.parse(nativeResponseStr);
        return {
          status: nativeResult.status || 'SUCCESS',
          action: request.action,
          target: request.target,
          message: nativeResult.message || `Native Android action ${request.action} completed.`,
          timestamp,
          native: true,
          data: nativeResult.data || nativeResult.matches,
        };
      } catch (err: any) {
        console.error('[AndroidBridge] Native call error:', err);
        return {
          status: 'ACTION_FAILED',
          action: request.action,
          target: request.target,
          message: err?.message || 'Native Android bridge invocation failed.',
          timestamp,
          native: true,
        };
      }
    }

    // 3. Browser-mode implementation (Android Chrome / WebApp fallback)
    switch (request.action) {
      case 'open_app':
        return this.handleOpenAppInBrowser(request.target || '', timestamp);

      case 'toggle_torch':
        return await this.handleToggleTorchInBrowser(timestamp);

      case 'open_dialer':
        return this.handleOpenDialerInBrowser(request.number, timestamp);

      case 'open_settings':
        return this.handleOpenSettingsInBrowser(timestamp);

      case 'prepare_sms':
      case 'send_message':
        return this.handlePrepareSmsInBrowser(request.recipient || request.number, request.message || request.text, timestamp);

      case 'open_accessibility_settings':
        return {
          status: 'ACTION_NOT_SUPPORTED',
          action: request.action,
          message: 'Accessibility Settings can be configured when running MYRAA inside the Android APK wrapper.',
          timestamp,
          native: false,
        };

      case 'press_back':
      case 'press_home':
      case 'press_recents':
      case 'open_notifications':
      case 'open_quick_settings':
      case 'lock_screen':
      case 'take_screenshot':
      case 'scroll':
      case 'scroll_up':
      case 'scroll_down':
      case 'click_node':
      case 'tap_accessible_element':
      case 'tap_coordinates':
      case 'swipe':
      case 'type_text':
      case 'click_and_type':
      case 'read_accessible_ui':
        // Accurately report that full Android OS Accessibility requires the Native Android APK wrapper
        return {
          status: 'ACTION_NOT_SUPPORTED',
          action: request.action,
          message: `Accessibility action "${request.action}" requires the MYRAA Native Android APK wrapper with AccessibilityService enabled.`,
          timestamp,
          native: false,
        };

      case 'get_status':
      default:
        return {
          status: 'SUCCESS',
          action: request.action,
          message: 'MYRAA running in Android Chrome browser environment (Intent mode active).',
          timestamp,
          native: false,
        };
    }
  }

  /**
   * Resolves target application and launches via Android Intent URL in Chrome.
   */
  private handleOpenAppInBrowser(targetApp: string, timestamp: number): AndroidExecutionResult {
    const key = targetApp.toLowerCase().trim();
    const appInfo =
      SUPPORTED_ANDROID_APPS[key] ||
      Object.values(SUPPORTED_ANDROID_APPS).find(
        (a) => a.name.toLowerCase() === key || a.packageName.includes(key)
      );

    if (!appInfo) {
      // Fallback search
      const searchUrl = `https://www.google.com/search?q=${encodeURIComponent(targetApp)}`;
      window.open(searchUrl, '_blank', 'noopener,noreferrer');
      return {
        status: 'APP_NOT_FOUND',
        action: 'open_app',
        target: targetApp,
        message: `App "${targetApp}" is not in the recognized Android apps registry. Opened web search.`,
        timestamp,
        native: false,
        intentUrl: searchUrl,
      };
    }

    try {
      // Attempt Android Intent URL navigation
      window.location.href = appInfo.intentUrl;
      return {
        status: 'APP_OPENED',
        action: 'open_app',
        target: appInfo.name,
        message: `Launching ${appInfo.name} via Android intent...`,
        timestamp,
        native: false,
        intentUrl: appInfo.intentUrl,
      };
    } catch {
      if (appInfo.fallbackUrl) {
        window.open(appInfo.fallbackUrl, '_blank', 'noopener,noreferrer');
      }
      return {
        status: 'ACTION_FAILED',
        action: 'open_app',
        target: appInfo.name,
        message: `Could not launch ${appInfo.name} package. Opened browser fallback.`,
        timestamp,
        native: false,
        intentUrl: appInfo.fallbackUrl,
      };
    }
  }

  private async handleToggleTorchInBrowser(timestamp: number): Promise<AndroidExecutionResult> {
    try {
      if (this.isTorchOn && this.torchMediaTrack) {
        this.torchMediaTrack.stop();
        this.torchMediaTrack = null;
        this.isTorchOn = false;
        return {
          status: 'SUCCESS',
          action: 'toggle_torch',
          message: 'Torch turned off.',
          timestamp,
          native: false,
        };
      }

      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        return {
          status: 'ACTION_NOT_SUPPORTED',
          action: 'toggle_torch',
          message: 'Camera MediaDevices not supported on this device.',
          timestamp,
          native: false,
        };
      }

      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment' },
      });
      const track = stream.getVideoTracks()[0];
      const capabilities: any = track.getCapabilities ? track.getCapabilities() : {};

      if (!capabilities.torch) {
        track.stop();
        return {
          status: 'PERMISSION_REQUIRED',
          action: 'toggle_torch',
          message: 'Flashlight hardware capability not exposed to browser. Use Native APK bridge.',
          timestamp,
          native: false,
        };
      }

      await (track as any).applyConstraints({ advanced: [{ torch: true }] });
      this.torchMediaTrack = track;
      this.isTorchOn = true;
      return {
        status: 'SUCCESS',
        action: 'toggle_torch',
        message: 'Torch turned on.',
        timestamp,
        native: false,
      };
    } catch (err: any) {
      return {
        status: 'ACTION_FAILED',
        action: 'toggle_torch',
        message: err?.message || 'Failed to toggle torch.',
        timestamp,
        native: false,
      };
    }
  }

  private handleOpenDialerInBrowser(number: string | undefined, timestamp: number): AndroidExecutionResult {
    const url = number ? `tel:${encodeURIComponent(number)}` : 'tel:';
    window.location.href = url;
    return {
      status: 'SUCCESS',
      action: 'open_dialer',
      target: number || 'Dialer',
      message: number ? `Preparing call to ${number}...` : 'Opening phone dialer...',
      timestamp,
      native: false,
      intentUrl: url,
    };
  }

  private handleOpenSettingsInBrowser(timestamp: number): AndroidExecutionResult {
    const url = 'intent:#Intent;action=android.settings.SETTINGS;end';
    window.location.href = url;
    return {
      status: 'SUCCESS',
      action: 'open_settings',
      message: 'Opening Android System Settings...',
      timestamp,
      native: false,
      intentUrl: url,
    };
  }

  private handlePrepareSmsInBrowser(
    number: string | undefined,
    text: string | undefined,
    timestamp: number
  ): AndroidExecutionResult {
    const num = number ? encodeURIComponent(number) : '';
    const body = text ? `?body=${encodeURIComponent(text)}` : '';
    const url = `sms:${num}${body}`;
    window.location.href = url;
    return {
      status: 'SUCCESS',
      action: 'prepare_sms',
      message: `Preparing SMS draft ${number ? 'to ' + number : ''}...`,
      timestamp,
      native: false,
      intentUrl: url,
    };
  }

  public getSupportedApps(): SupportedAppInfo[] {
    return Object.values(SUPPORTED_ANDROID_APPS);
  }

  public async getNativePlatformInfo(): Promise<{
    platform: string;
    apiLevel?: number;
    release?: string;
    model?: string;
    accessibilityActive: boolean;
    torchAvailable: boolean;
    isNative: boolean;
  }> {
    if (this.isNative()) {
      try {
        const raw = (window as any).Android.getNativePlatformInfo();
        const parsed = JSON.parse(raw);
        return { ...parsed, isNative: true };
      } catch {}
    }
    return {
      platform: 'Web Preview',
      accessibilityActive: false,
      torchAvailable: false,
      isNative: false,
    };
  }

  public async getAccessibilityStatus(): Promise<{ active: boolean; message: string; currentPackage?: string }> {
    const res = await this.executeCommand({ action: 'get_status' });
    return {
      active: res.data?.accessibilityActive ?? this.isAccessibilityActive(),
      message: res.message,
      currentPackage: res.data?.currentPackage,
    };
  }

  public async openAndroidApp(appName: string): Promise<AndroidExecutionResult> {
    return this.executeCommand({ action: 'open_app', target: appName });
  }

  public async performAccessibilityAction(action: AndroidActionType, params?: any): Promise<AndroidExecutionResult> {
    return this.executeCommand({ action, ...(params || {}) });
  }

  public async getCurrentAppInfo(): Promise<{ packageName: string; activityName?: string }> {
    const res = await this.executeCommand({ action: 'get_current_app' });
    return {
      packageName: res.data?.packageName || '',
      activityName: res.data?.activityName,
    };
  }

  public async getAccessibleScreenInfo(): Promise<any> {
    const res = await this.executeCommand({ action: 'read_accessible_ui' });
    return res.data;
  }

  public requestAccessibilitySetup(): void {
    if (this.isNative() && (window as any).Android.openAccessibilitySettings) {
      (window as any).Android.openAccessibilitySettings();
    } else {
      this.executeCommand({ action: 'open_accessibility_settings' });
    }
  }

  public async stopMyraaListening(): Promise<AndroidExecutionResult> {
    return this.executeCommand({ action: 'stop_listening' });
  }

  public async executeMultiStepTask(
    taskId: string,
    steps: AndroidActionRequest[]
  ): Promise<AndroidExecutionResult> {
    const timestamp = Date.now();
    for (let i = 0; i < steps.length; i++) {
      const stepRes = await this.executeCommand(steps[i]);
      if (stepRes.status === 'ACTION_FAILED' || stepRes.status === 'PERMISSION_REQUIRED') {
        return {
          status: 'ACTION_FAILED',
          action: 'multi_step_task',
          message: `Task step ${i + 1} (${steps[i].action}) failed: ${stepRes.message}`,
          timestamp,
          native: this.isNative(),
        };
      }
      await new Promise((r) => setTimeout(r, 600));
    }
    return {
      status: 'SUCCESS',
      action: 'multi_step_task',
      message: `Completed all ${steps.length} steps in workflow "${taskId}".`,
      timestamp,
      native: this.isNative(),
    };
  }
}

export const androidBridge = new AndroidBridgeService();
