/**
 * ScreenShareService - Real-time Screen Capture & Gemini Vision Understanding for ALYA
 *
 * Implements:
 * 1. Real browser getDisplayMedia() screen capture with OS permission handling.
 * 2. Automatic stream cleanup on track termination (MediaStreamTrack.onended).
 * 3. Frame snapshot extraction via Offscreen/HTML5 Canvas with automatic downscaling for bandwidth optimization.
 * 4. Integration with backend `/api/screen/analyze` powered by Google Gemini Vision.
 * 5. On-demand and continuous analysis modes with pause/resume support.
 * 6. Native Android bridge awareness (MediaProjection intent dispatching when supported).
 * 7. Audio feedback through Gemini TTS (`geminiTts.speak()`).
 */

import { geminiTts } from './GeminiTtsService';
import { androidBridge } from './AndroidBridge';

export type ScreenShareState = 'idle' | 'requesting' | 'sharing' | 'analyzing' | 'paused' | 'error';

export interface ScreenAnalysisResult {
  text: string;
  timestamp: number;
  prompt: string;
}

export interface ScreenShareStatus {
  state: ScreenShareState;
  isSharing: boolean;
  isAnalyzing: boolean;
  isPaused: boolean;
  isVoiceMuted: boolean;
  latestAnalysis: ScreenAnalysisResult | null;
  errorMessage: string | null;
  hasStream: boolean;
}

class ScreenShareService {
  private mediaStream: MediaStream | null = null;
  private videoElement: HTMLVideoElement | null = null;
  private canvasElement: HTMLCanvasElement | null = null;
  private state: ScreenShareState = 'idle';
  private isPaused: boolean = false;
  private isVoiceMuted: boolean = false;
  private isAnalyzing: boolean = false;
  private latestAnalysis: ScreenAnalysisResult | null = null;
  private errorMessage: string | null = null;
  private continuousTimer: any = null;
  private listeners: Set<(status: ScreenShareStatus) => void> = new Set();

  constructor() {
    if (typeof window !== 'undefined') {
      this.videoElement = document.createElement('video');
      this.videoElement.autoplay = true;
      this.videoElement.muted = true;
      this.videoElement.playsInline = true;
      this.canvasElement = document.createElement('canvas');
    }
  }

  public getStatus(): ScreenShareStatus {
    return {
      state: this.state,
      isSharing: Boolean(this.mediaStream && this.mediaStream.active),
      isAnalyzing: this.isAnalyzing,
      isPaused: this.isPaused,
      isVoiceMuted: this.isVoiceMuted,
      latestAnalysis: this.latestAnalysis,
      errorMessage: this.errorMessage,
      hasStream: Boolean(this.mediaStream),
    };
  }

  public getMediaStream(): MediaStream | null {
    return this.mediaStream;
  }

  public subscribe(listener: (status: ScreenShareStatus) => void): () => void {
    this.listeners.add(listener);
    listener(this.getStatus());
    return () => this.listeners.delete(listener);
  }

  private notify(): void {
    const s = this.getStatus();
    this.listeners.forEach((fn) => fn(s));
  }

  /**
   * Starts a genuine screen capture session.
   * Prompts the user with the system/browser display picker.
   */
  public async startCapture(): Promise<boolean> {
    if (this.mediaStream && this.mediaStream.active) {
      return true;
    }

    this.errorMessage = null;
    this.state = 'requesting';
    this.notify();

    // Check if running in Native Android WebView
    if (androidBridge.isNative()) {
      try {
        const res = await androidBridge.executeCommand({ action: 'start_screen_capture' as any });
        if (res.status === 'SUCCESS') {
          this.state = 'sharing';
          this.notify();
          return true;
        }
      } catch (nativeErr) {
        console.warn('[ScreenShare] Native Android capture invocation:', nativeErr);
      }
    }

    // Standard Browser Display Media API
    if (typeof navigator === 'undefined' || !navigator.mediaDevices || !navigator.mediaDevices.getDisplayMedia) {
      this.state = 'error';
      this.errorMessage = 'Screen capture (getDisplayMedia) is not supported in this browser environment.';
      this.notify();
      return false;
    }

    try {
      const stream = await navigator.mediaDevices.getDisplayMedia({
        video: {
          cursor: 'always',
          frameRate: { ideal: 15, max: 30 },
        } as any,
        audio: false,
      });

      this.mediaStream = stream;
      if (this.videoElement) {
        this.videoElement.srcObject = stream;
        await this.videoElement.play().catch(() => {});
      }

      // Handle user stopping screen capture from browser/OS native controls
      const videoTrack = stream.getVideoTracks()[0];
      if (videoTrack) {
        videoTrack.onended = () => {
          console.log('[ScreenShare] Video track ended by user/system.');
          this.stopCapture();
        };
      }

      this.state = 'sharing';
      this.isPaused = false;
      this.errorMessage = null;
      this.notify();

      return true;
    } catch (err: any) {
      console.warn('[ScreenShare] User denied permission or error occurred:', err);
      this.state = 'error';
      if (err.name === 'NotAllowedError') {
        this.errorMessage = 'Screen capture permission was denied. Tap "Start Sharing" and choose a screen or window to allow ALYA to view it.';
      } else if (err.name === 'NotFoundError') {
        this.errorMessage = 'No screen video sources found on this device.';
      } else {
        this.errorMessage = err.message || 'Failed to start screen capture.';
      }
      this.notify();
      return false;
    }
  }

  /**
   * Completely stops screen capture and releases all hardware media tracks.
   */
  public stopCapture(): void {
    this.stopContinuousAnalysis();

    if (this.mediaStream) {
      try {
        this.mediaStream.getTracks().forEach((track) => track.stop());
      } catch {}
      this.mediaStream = null;
    }

    if (this.videoElement) {
      this.videoElement.srcObject = null;
    }

    this.state = 'idle';
    this.isAnalyzing = false;
    this.isPaused = false;
    this.notify();
  }

  /**
   * Pauses visual analysis without dropping the active stream.
   */
  public pauseAnalysis(): void {
    this.isPaused = true;
    this.state = 'paused';
    this.notify();
  }

  /**
   * Resumes visual analysis on the active stream.
   */
  public resumeAnalysis(): void {
    this.isPaused = false;
    this.state = 'sharing';
    this.notify();
  }

  /**
   * Toggles speech output for screen analysis answers.
   */
  public toggleVoiceMute(): boolean {
    this.isVoiceMuted = !this.isVoiceMuted;
    if (this.isVoiceMuted) {
      geminiTts.stop();
    }
    this.notify();
    return this.isVoiceMuted;
  }

  /**
   * Extracts a single base64 JPEG frame from the active screen stream.
   */
  public captureFrameBase64(): string | null {
    if (!this.mediaStream || !this.videoElement || !this.canvasElement) {
      return null;
    }

    const video = this.videoElement;
    if (video.videoWidth === 0 || video.videoHeight === 0) {
      return null;
    }

    // Scale down to max 1280x720 to reduce network payload while keeping UI text legible
    const maxWidth = 1280;
    const maxHeight = 720;
    let width = video.videoWidth;
    let height = video.videoHeight;

    if (width > maxWidth || height > maxHeight) {
      const ratio = Math.min(maxWidth / width, maxHeight / height);
      width = Math.round(width * ratio);
      height = Math.round(height * ratio);
    }

    this.canvasElement.width = width;
    this.canvasElement.height = height;

    const ctx = this.canvasElement.getContext('2d');
    if (!ctx) return null;

    ctx.drawImage(video, 0, 0, width, height);

    // Get pure base64 (remove 'data:image/jpeg;base64,' prefix)
    const dataUrl = this.canvasElement.toDataURL('image/jpeg', 0.85);
    return dataUrl.split(',')[1] || null;
  }

  /**
   * Analyzes the currently visible screen content using Gemini Multimodal Vision.
   */
  public async analyzeScreen(question?: string): Promise<ScreenAnalysisResult | null> {
    if (!this.mediaStream || !this.mediaStream.active) {
      const started = await this.startCapture();
      if (!started) return null;
    }

    if (this.isPaused) {
      this.errorMessage = 'Analysis is paused. Resume analysis to query the screen.';
      this.notify();
      return null;
    }

    const frameBase64 = this.captureFrameBase64();
    if (!frameBase64) {
      this.errorMessage = 'Could not capture a valid video frame from the screen stream.';
      this.notify();
      return null;
    }

    this.isAnalyzing = true;
    this.state = 'analyzing';
    this.notify();

    const userPrompt =
      question && question.trim()
        ? question.trim()
        : 'Analyze my current screen. Explain what is visible, any key information, actions or errors, in concise natural conversational style.';

    try {
      const response = await fetch('/api/screen/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          image: frameBase64,
          prompt: userPrompt,
        }),
      });

      if (!response.ok) {
        const errData = await response.json().catch(() => ({}));
        throw new Error(errData.error || `HTTP ${response.status}: Failed to analyze screen frame`);
      }

      const data = await response.json();
      const analysisText = data.text || 'Screen analyzed successfully.';

      const result: ScreenAnalysisResult = {
        text: analysisText,
        timestamp: Date.now(),
        prompt: userPrompt,
      };

      this.latestAnalysis = result;
      this.errorMessage = null;

      // Speak result via Gemini TTS if voice is not muted
      if (!this.isVoiceMuted) {
        geminiTts.speak(analysisText);
      }

      return result;
    } catch (err: any) {
      console.error('[ScreenShare] Screen analysis failed:', err);
      this.errorMessage = err.message || 'Vision analysis failed.';
      return null;
    } finally {
      this.isAnalyzing = false;
      this.state = this.isPaused ? 'paused' : 'sharing';
      this.notify();
    }
  }

  /**
   * Starts periodic background screen understanding.
   */
  public startContinuousAnalysis(intervalMs: number = 10000): void {
    this.stopContinuousAnalysis();
    this.continuousTimer = setInterval(() => {
      if (this.mediaStream && !this.isPaused && !this.isAnalyzing) {
        this.analyzeScreen('Provide a quick 1-sentence observational update on visible screen changes.');
      }
    }, intervalMs);
  }

  public stopContinuousAnalysis(): void {
    if (this.continuousTimer) {
      clearInterval(this.continuousTimer);
      this.continuousTimer = null;
    }
  }
}

export const screenShareService = new ScreenShareService();
