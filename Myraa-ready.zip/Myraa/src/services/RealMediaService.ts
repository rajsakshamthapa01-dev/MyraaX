/**
 * RealMediaService - Real YouTube and Music Playback & Search Client for MYRAA
 *
 * Implements:
 * 1. Live YouTube search via `/api/youtube/search`.
 * 2. Live Music search via `/api/music/search`.
 * 3. Webpage AI summarization via `/api/web/summarize`.
 * 4. Embedded YouTube iframe playback controller (play, pause, resume).
 * 5. Native iTunes 30s preview audio player with full controls.
 */

export interface YouTubeVideo {
  id: string;
  title: string;
  channel: string;
  duration?: string;
  thumbnail: string;
  url: string;
}

export interface MusicTrack {
  id: string;
  title: string;
  artist: string;
  album?: string;
  artwork?: string;
  previewUrl?: string;
  streamUrl: string;
  service: 'itunes' | 'youtube' | 'spotify';
}

export interface WebSummary {
  title: string;
  url: string;
  summary: string;
  keyPoints?: string[];
  wordCount?: number;
}

class RealMediaService {
  private activeVideo: YouTubeVideo | null = null;
  private activeTrack: MusicTrack | null = null;
  private isVideoPlaying: boolean = false;
  private isMusicPlaying: boolean = false;
  private audioPlayer: HTMLAudioElement | null = null;
  private listeners: Set<() => void> = new Set();

  constructor() {
    if (typeof window !== 'undefined') {
      this.audioPlayer = new Audio();
      this.audioPlayer.addEventListener('ended', () => {
        this.isMusicPlaying = false;
        this.notify();
      });
      this.audioPlayer.addEventListener('pause', () => {
        this.isMusicPlaying = false;
        this.notify();
      });
      this.audioPlayer.addEventListener('play', () => {
        this.isMusicPlaying = true;
        this.notify();
      });
    }
  }

  public subscribe(listener: () => void): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  private notify(): void {
    this.listeners.forEach((fn) => fn());
  }

  // --- Real Search Calls ---

  public async searchYouTube(query: string): Promise<YouTubeVideo[]> {
    try {
      const res = await fetch(`/api/youtube/search?q=${encodeURIComponent(query)}`);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = await res.json();
      return data.videos || [];
    } catch (err) {
      console.warn('[RealMediaService] YouTube search error:', err);
      return [];
    }
  }

  public async searchMusic(query: string): Promise<MusicTrack[]> {
    try {
      const res = await fetch(`/api/music/search?q=${encodeURIComponent(query)}`);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = await res.json();
      return data.tracks || [];
    } catch (err) {
      console.warn('[RealMediaService] Music search error:', err);
      return [];
    }
  }

  public async summarizeWebpage(url: string): Promise<WebSummary> {
    const res = await fetch('/api/web/summarize', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ url }),
    });

    if (!res.ok) {
      const errData = await res.json().catch(() => ({}));
      throw new Error(errData.error || `Failed to summarize page (HTTP ${res.status})`);
    }

    return await res.json();
  }

  // --- YouTube Playback Management ---

  public playVideo(video: YouTubeVideo): void {
    this.stopMusic();
    this.activeVideo = video;
    this.isVideoPlaying = true;
    this.notify();
  }

  public pauseVideo(): void {
    this.isVideoPlaying = false;
    this.notify();
  }

  public resumeVideo(): void {
    if (this.activeVideo) {
      this.isVideoPlaying = true;
      this.notify();
    }
  }

  public closeVideo(): void {
    this.activeVideo = null;
    this.isVideoPlaying = false;
    this.notify();
  }

  public getActiveVideo(): YouTubeVideo | null {
    return this.activeVideo;
  }

  public isVideoActive(): boolean {
    return this.isVideoPlaying && Boolean(this.activeVideo);
  }

  // --- Music Playback Management ---

  public playMusic(track: MusicTrack): void {
    this.pauseVideo();
    this.activeTrack = track;

    if (this.audioPlayer && track.previewUrl) {
      this.audioPlayer.src = track.previewUrl;
      this.audioPlayer.play().catch((e) => console.warn('[RealMediaService] Audio play error:', e));
      this.isMusicPlaying = true;
    } else {
      // If no preview URL (e.g. YouTube Music / Spotify link), open the official stream link
      try {
        window.open(track.streamUrl, '_blank', 'noopener,noreferrer');
      } catch {}
    }
    this.notify();
  }

  public pauseMusic(): void {
    if (this.audioPlayer) {
      this.audioPlayer.pause();
    }
    this.isMusicPlaying = false;
    this.notify();
  }

  public resumeMusic(): void {
    if (this.audioPlayer && this.activeTrack?.previewUrl) {
      this.audioPlayer.play().catch(() => {});
      this.isMusicPlaying = true;
      this.notify();
    }
  }

  public stopMusic(): void {
    if (this.audioPlayer) {
      this.audioPlayer.pause();
      this.audioPlayer.currentTime = 0;
    }
    this.isMusicPlaying = false;
    this.activeTrack = null;
    this.notify();
  }

  public getActiveTrack(): MusicTrack | null {
    return this.activeTrack;
  }

  public isTrackPlaying(): boolean {
    return this.isMusicPlaying;
  }
}

export const realMedia = new RealMediaService();
