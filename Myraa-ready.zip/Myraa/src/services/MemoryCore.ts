/**
 * MemoryCore - Persistent neural memory system for VYRON.
 * Remembers user preferences, facts, past conversation highlights, and emotional context.
 */

import { MemoryItem } from '../types/live';

const STORAGE_KEY = 'vyron_neural_memory_core_v1';

const DEFAULT_MEMORIES: MemoryItem[] = [
  {
    id: 'mem_1',
    category: 'preference',
    text: 'User hates robotic, scripted AI responses. Strongly prefers genuine human-like emotion, witty humor, and natural conversational pacing.',
    timestamp: Date.now() - 3600000 * 24,
    importance: 'high',
  },
  {
    id: 'mem_2',
    category: 'preference',
    text: 'User values natural turn-taking: when they want to talk, listen attentively; when they want to shut up, do not force long speeches or endless questions.',
    timestamp: Date.now() - 3600000 * 12,
    importance: 'high',
  },
  {
    id: 'mem_3',
    category: 'relationship',
    text: 'Assistant was renamed to VYRON. VYRON is a powerful, witty, empathetic, and charming AI companion with an in-built browser and holographic crimson core.',
    timestamp: Date.now() - 3600000 * 2,
    importance: 'high',
  },
];

export class MemoryCoreService {
  private memories: MemoryItem[] = [];
  private listeners: Set<(memories: MemoryItem[]) => void> = new Set();

  constructor() {
    this.loadFromStorage();
  }

  private loadFromStorage(): void {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        this.memories = JSON.parse(raw);
      } else {
        this.memories = [...DEFAULT_MEMORIES];
        this.saveToStorage();
      }
    } catch (err) {
      console.warn('[MemoryCore] Failed to load memories from localStorage, using defaults:', err);
      this.memories = [...DEFAULT_MEMORIES];
    }
  }

  private saveToStorage(): void {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(this.memories));
      this.notifyListeners();
    } catch (err) {
      console.error('[MemoryCore] Failed to save to localStorage:', err);
    }
  }

  public getMemories(): MemoryItem[] {
    return [...this.memories];
  }

  public subscribe(listener: (memories: MemoryItem[]) => void): () => void {
    this.listeners.add(listener);
    listener(this.getMemories());
    return () => this.listeners.delete(listener);
  }

  private notifyListeners(): void {
    const list = this.getMemories();
    this.listeners.forEach((fn) => fn(list));
  }

  public addMemory(
    text: string,
    category: MemoryItem['category'] = 'fact',
    importance: MemoryItem['importance'] = 'medium'
  ): MemoryItem {
    const trimmed = text.trim();
    if (!trimmed) throw new Error('Memory text cannot be empty');

    // Avoid duplicate memories
    const existing = this.memories.find(
      (m) => m.text.toLowerCase() === trimmed.toLowerCase()
    );
    if (existing) {
      existing.timestamp = Date.now();
      this.saveToStorage();
      return existing;
    }

    const newMemory: MemoryItem = {
      id: 'mem_' + Math.random().toString(36).substring(2, 9),
      category,
      text: trimmed,
      timestamp: Date.now(),
      importance,
    };

    this.memories.unshift(newMemory);
    this.saveToStorage();
    return newMemory;
  }

  public removeMemory(id: string): void {
    this.memories = this.memories.filter((m) => m.id !== id);
    this.saveToStorage();
  }

  public clearAllMemories(): void {
    this.memories = [];
    this.saveToStorage();
  }

  public clearMemories(): void {
    this.clearAllMemories();
  }

  public resetToDefaults(): void {
    this.memories = [...DEFAULT_MEMORIES];
    this.saveToStorage();
  }

  public search(query: string): MemoryItem[] {
    const q = query.toLowerCase();
    return this.memories.filter(
      (m) => m.text.toLowerCase().includes(q) || m.category.toLowerCase().includes(q)
    );
  }

  /**
   * Formats all active memories into a structured context string
   * injected into Gemini Live's systemInstruction.
   */
  public getFormattedContext(): string {
    if (this.memories.length === 0) return '';

    const lines = this.memories.map((m) => {
      const dateStr = new Date(m.timestamp).toLocaleDateString([], {
        month: 'short',
        day: 'numeric',
      });
      return `• [${m.category.toUpperCase()}] (${dateStr}): ${m.text}`;
    });

    return `\n\n=== VYRON ACTIVE NEURAL MEMORY CORE (Recollections of User & Past Conversations) ===\n${lines.join(
      '\n'
    )}\n(Treat these memories as established shared history. Refer back to them naturally when relevant without sounding artificial.)`;
  }
}

export const memoryCore = new MemoryCoreService();
