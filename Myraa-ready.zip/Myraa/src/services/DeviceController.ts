/**
 * DeviceController - Practical Android & Web device integration for V.Y.R.O.N
 * Handles app launching, timers/alarms, torch, vibration, battery, and media controls.
 */

import { ActiveTimer, DeviceTelemetry } from '../types/live';
export type { ActiveTimer, DeviceTelemetry };

class DeviceControllerService {
  private torchTrack: MediaStreamTrack | null = null;
  private wakeLock: any = null;
  private timers: ActiveTimer[] = [];
  private timerInterval: number | null = null;
  private timerListeners: Set<(timers: ActiveTimer[]) => void> = new Set();
  private telemetryListeners: Set<(telemetry: DeviceTelemetry) => void> = new Set();
  private currentTelemetry: DeviceTelemetry = {
    isOnline: typeof navigator !== 'undefined' ? navigator.onLine : true,
    hasTorch: false,
    isTorchOn: false,
    isScreenLocked: false,
  };

  constructor() {
    this.initTelemetry();
    this.startTimerTicker();
  }

  private async initTelemetry(): Promise<void> {
    window.addEventListener('online', () => this.updateOnline(true));
    window.addEventListener('offline', () => this.updateOnline(false));

    // Battery API check where supported
    if ('getBattery' in navigator) {
      try {
        const battery: any = await (navigator as any).getBattery();
        this.currentTelemetry.batteryLevel = Math.round(battery.level * 100);
        this.currentTelemetry.isCharging = battery.charging;

        battery.addEventListener('levelchange', () => {
          this.currentTelemetry.batteryLevel = Math.round(battery.level * 100);
          this.notifyTelemetry();
        });

        battery.addEventListener('chargingchange', () => {
          this.currentTelemetry.isCharging = battery.charging;
          this.notifyTelemetry();
        });
      } catch {
        // Battery API not permitted
      }
    }

    // Check torch capability
    if (navigator.mediaDevices && navigator.mediaDevices.getSupportedConstraints) {
      const constraints = navigator.mediaDevices.getSupportedConstraints() as any;
      this.currentTelemetry.hasTorch = Boolean(constraints.torch);
    }

    this.notifyTelemetry();
  }

  private updateOnline(status: boolean): void {
    this.currentTelemetry.isOnline = status;
    this.notifyTelemetry();
  }

  public getTelemetry(): DeviceTelemetry {
    return { ...this.currentTelemetry };
  }

  public subscribeTelemetry(listener: (t: DeviceTelemetry) => void): () => void {
    this.telemetryListeners.add(listener);
    listener(this.getTelemetry());
    return () => this.telemetryListeners.delete(listener);
  }

  public subscribe(listener: (t: DeviceTelemetry) => void): () => void {
    return this.subscribeTelemetry(listener);
  }

  public getActiveTimers(): ActiveTimer[] {
    return this.getTimers();
  }

  private notifyTelemetry(): void {
    const t = this.getTelemetry();
    this.telemetryListeners.forEach((fn) => fn(t));
  }

  // --- Torch / Flashlight ---
  public async toggleTorch(): Promise<{ success: boolean; state: boolean; message: string }> {
    try {
      if (this.currentTelemetry.isTorchOn && this.torchTrack) {
        // Turn off
        this.torchTrack.stop();
        this.torchTrack = null;
        this.currentTelemetry.isTorchOn = false;
        this.notifyTelemetry();
        return { success: true, state: false, message: 'Torch turned off.' };
      }

      // Request camera with torch
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment' },
      });
      const track = stream.getVideoTracks()[0];
      const capabilities: any = track.getCapabilities ? track.getCapabilities() : {};

      if (capabilities.torch) {
        await (track as any).applyConstraints({ advanced: [{ torch: true }] });
        this.torchTrack = track;
        this.currentTelemetry.isTorchOn = true;
        this.currentTelemetry.hasTorch = true;
        this.notifyTelemetry();
        return { success: true, state: true, message: 'Torch turned on.' };
      } else {
        track.stop();
        return { success: false, state: false, message: 'Torch is not supported on this device.' };
      }
    } catch (err: any) {
      return {
        success: false,
        state: false,
        message: 'Camera/Torch permission required: ' + (err.message || 'Error'),
      };
    }
  }

  // --- Haptics / Vibration ---
  public vibrate(pattern: number | number[] = [100, 50, 100]): boolean {
    if ('vibrate' in navigator) {
      try {
        return navigator.vibrate(pattern);
      } catch {
        return false;
      }
    }
    return false;
  }

  // --- Screen Wake Lock ---
  public async toggleWakeLock(enable: boolean): Promise<boolean> {
    if ('wakeLock' in navigator) {
      try {
        if (enable && !this.wakeLock) {
          this.wakeLock = await (navigator as any).wakeLock.request('screen');
          this.currentTelemetry.isScreenLocked = true;
          this.notifyTelemetry();
          return true;
        } else if (!enable && this.wakeLock) {
          await this.wakeLock.release();
          this.wakeLock = null;
          this.currentTelemetry.isScreenLocked = false;
          this.notifyTelemetry();
          return true;
        }
      } catch {
        return false;
      }
    }
    return false;
  }

  // --- App Launcher & Android Intents ---
  public openApp(appName: string): {
    success: boolean;
    url: string;
    fallbackUrl: string;
    label: string;
    message: string;
  } {
    const key = appName.toLowerCase().trim();

    // If running in Native Android WebView, trigger real package resolution
    if (typeof window !== 'undefined' && (window as any).Android) {
      try {
        const resStr = (window as any).Android.executeCommand(
          JSON.stringify({ action: 'open_app', target: appName })
        );
        const res = JSON.parse(resStr);
        return {
          success: res.status === 'APP_OPENED' || res.status === 'SUCCESS',
          url: '',
          fallbackUrl: '',
          label: res.appName || appName,
          message: res.message || `Opened ${appName} on Android.`,
        };
      } catch (err: any) {
        console.error('[DeviceController] Native openApp error:', err);
      }
    }

    let intentUrl = '';
    let fallbackUrl = '';
    let label = appName;

    switch (key) {
      case 'youtube':
        intentUrl = 'intent://#Intent;package=com.google.android.youtube;end';
        fallbackUrl = 'https://www.youtube.com';
        label = 'YouTube';
        break;

      case 'instagram':
        intentUrl = 'intent://#Intent;package=com.instagram.android;end';
        fallbackUrl = 'https://www.instagram.com';
        label = 'Instagram';
        break;

      case 'whatsapp':
        intentUrl = 'intent://#Intent;package=com.whatsapp;end';
        fallbackUrl = 'https://api.whatsapp.com/send';
        label = 'WhatsApp';
        break;

      case 'chrome':
      case 'browser':
        intentUrl = 'intent://#Intent;package=com.android.chrome;end';
        fallbackUrl = 'https://www.google.com';
        label = 'Google Chrome';
        break;

      case 'maps':
      case 'google maps':
      case 'navigation':
        intentUrl = 'intent://#Intent;package=com.google.android.apps.maps;end';
        fallbackUrl = 'https://maps.google.com';
        label = 'Google Maps';
        break;

      case 'camera':
        intentUrl = 'intent:#Intent;action=android.media.action.IMAGE_CAPTURE;end';
        fallbackUrl = '';
        label = 'Camera';
        break;

      case 'phone':
      case 'dialer':
      case 'call':
        intentUrl = 'tel:';
        fallbackUrl = '';
        label = 'Phone';
        break;

      case 'settings':
      case 'phone settings':
        intentUrl = 'intent:#Intent;action=android.settings.SETTINGS;end';
        fallbackUrl = '';
        label = 'Android Settings';
        break;

      default:
        intentUrl = `https://www.google.com/search?q=${encodeURIComponent(appName)}`;
        fallbackUrl = intentUrl;
        label = appName;
        break;
    }

    try {
      window.location.href = intentUrl;
      return {
        success: true,
        url: intentUrl,
        fallbackUrl,
        label,
        message: `Attempting to launch ${label} app on Android...`,
      };
    } catch {
      if (fallbackUrl) {
        window.open(fallbackUrl, '_blank', 'noopener,noreferrer');
      }
      return {
        success: false,
        url: intentUrl,
        fallbackUrl,
        label,
        message: `Could not launch ${label} app directly. Using web version.`,
      };
    }
  }

  // --- Alarms & Timers ---
  public setTimer(minutes: number, label: string = 'Timer'): ActiveTimer {
    const totalSeconds = Math.max(1, Math.round(minutes * 60));
    const timer: ActiveTimer = {
      id: 'timer_' + Date.now(),
      label: label || `Timer (${minutes} min)`,
      durationSeconds: totalSeconds,
      remainingSeconds: totalSeconds,
      isRunning: true,
    };

    this.timers.push(timer);
    this.vibrate([80, 40, 80]);
    this.notifyTimers();

    // Also trigger Android alarm intent where available
    const intentUrl = `intent:#Intent;action=android.intent.action.SET_TIMER;i.android.intent.extra.LENGTH=${totalSeconds};S.android.intent.extra.MESSAGE=${encodeURIComponent(label)};B.android.intent.extra.SKIP_UI=false;end`;
    try {
      const a = document.createElement('a');
      a.href = intentUrl;
      // Do not force redirect so web timer keeps ticking
    } catch {
      // Ignored
    }

    return timer;
  }

  public cancelTimer(id: string): void {
    this.timers = this.timers.filter((t) => t.id !== id);
    this.notifyTimers();
  }

  public getTimers(): ActiveTimer[] {
    return [...this.timers];
  }

  public subscribeTimers(listener: (t: ActiveTimer[]) => void): () => void {
    this.timerListeners.add(listener);
    listener(this.getTimers());
    return () => this.timerListeners.delete(listener);
  }

  private notifyTimers(): void {
    const list = this.getTimers();
    this.timerListeners.forEach((fn) => fn(list));
  }

  private startTimerTicker(): void {
    this.timerInterval = window.setInterval(() => {
      if (this.timers.length === 0) return;

      let changed = false;
      this.timers.forEach((timer) => {
        if (timer.isRunning && timer.remainingSeconds > 0) {
          timer.remainingSeconds -= 1;
          changed = true;

          if (timer.remainingSeconds <= 0) {
            timer.isRunning = false;
            this.handleTimerFinished(timer);
          }
        }
      });

      if (changed) {
        this.notifyTimers();
      }
    }, 1000);
  }

  private handleTimerFinished(timer: ActiveTimer): void {
    this.vibrate([300, 150, 300, 150, 500]);
    // Play alert audio tone
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      const ctx = new AudioCtx();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(880, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(440, ctx.currentTime + 0.6);
      gain.gain.setValueAtTime(0.5, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.6);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.6);
    } catch {
      // Audio tone fallback
    }

    if (typeof window !== 'undefined' && 'Notification' in window && window.Notification && window.Notification.permission === 'granted') {
      try {
        new window.Notification('MYRAA - Time is up!', {
          body: `${timer.label} has completed.`,
          icon: '/vyron_hologram.jpg',
        });
      } catch {}
    }
  }
}

export const deviceController = new DeviceControllerService();
