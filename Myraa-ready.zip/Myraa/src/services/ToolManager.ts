/**
 * ToolManager - Executes client-side function calls requested by V.Y.R.O.N / Gemini Live
 * and returns the output immediately with Hindi confirmations.
 */

import { AssistantMood, AssistantEmotion, ToolExecutionNotification } from '../types/live';
import { EMOTIONS } from '../constants/emotions';
import { memoryCore } from './MemoryCore';
import { deviceController } from './DeviceController';
import { desktopCompanion } from './DesktopCompanion';
import { androidBridge } from './AndroidBridge';

import { realBrowser } from './RealBrowserService';
import { realMedia } from './RealMediaService';
import { geminiTts } from './GeminiTtsService';

export type ToolHandler = (args: Record<string, any>) => Promise<Record<string, any>> | Record<string, any>;

export class ToolManager {
  private handlers: Map<string, ToolHandler> = new Map();
  private onNotification?: (notification: ToolExecutionNotification) => void;
  private onMoodChange?: (mood: AssistantMood) => void;
  private onEmotionChange?: (emotion: AssistantEmotion) => void;
  private onEffectTrigger?: (effect: string) => void;
  private onOpenBrowser?: (url: string) => void;

  constructor(options?: {
    onNotification?: (notification: ToolExecutionNotification) => void;
    onMoodChange?: (mood: AssistantMood) => void;
    onEmotionChange?: (emotion: AssistantEmotion) => void;
    onEffectTrigger?: (effect: string) => void;
    onOpenBrowser?: (url: string) => void;
  }) {
    this.onNotification = options?.onNotification;
    this.onMoodChange = options?.onMoodChange;
    this.onEmotionChange = options?.onEmotionChange;
    this.onEffectTrigger = options?.onEffectTrigger;
    this.onOpenBrowser = options?.onOpenBrowser;

    this.registerDefaultTools();
  }

  private registerDefaultTools(): void {
    // 1. openWebsite (triggers Real Integrated Browser)
    this.registerTool('openWebsite', async (args) => {
      let rawUrl = (args.url || '').trim();
      const title = args.title || rawUrl || 'Webpage';

      if (!rawUrl.startsWith('http://') && !rawUrl.startsWith('https://')) {
        rawUrl = `https://${rawUrl}`;
      }

      realBrowser.openBrowser(rawUrl);

      if (this.onOpenBrowser) {
        this.onOpenBrowser(rawUrl);
      }

      this.notify({
        id: Math.random().toString(36).substring(2, 9),
        toolName: 'openWebsite',
        summary: `Loaded in Integrated Browser: ${title}`,
        url: rawUrl,
        iconName: 'Globe',
        timestamp: Date.now(),
        status: 'success',
      });

      return {
        success: true,
        openedInIntegratedBrowser: true,
        url: rawUrl,
        title,
        message: `${title} loaded inside MYRAA's integrated browser.`,
      };
    });

    // 2. searchWeb (Real Web Search Execution)
    this.registerTool('searchWeb', async (args) => {
      const query = (args.query || '').trim();
      const searchUrl = realBrowser.resolveUrl(query);

      realBrowser.openBrowser(searchUrl);

      let realResults: any[] = [];
      try {
        const res = await fetch(`/api/search?q=${encodeURIComponent(query)}`);
        if (res.ok) {
          const data = await res.json();
          realResults = data.results || [];
        }
      } catch (e) {
        console.warn('[ToolManager] Real search fetch warning:', e);
      }

      this.notify({
        id: Math.random().toString(36).substring(2, 9),
        toolName: 'searchWeb',
        summary: `Web Search: "${query}"`,
        url: searchUrl,
        iconName: 'Search',
        timestamp: Date.now(),
        status: 'success',
      });

      return {
        success: true,
        query,
        searchUrl,
        resultsCount: realResults.length,
        topResults: realResults.slice(0, 3).map((r) => ({
          title: r.title,
          url: r.url,
          snippet: r.snippet,
        })),
        message: `Found ${realResults.length} real web results for "${query}" and loaded search in browser.`,
      };
    });

    // 2a. playYouTube (Real YouTube Video Search & Playback)
    this.registerTool('playYouTube', async (args) => {
      const query = (args.query || '').trim();
      const action = (args.action || 'search').toLowerCase();

      if (action === 'pause') {
        realMedia.pauseVideo();
        return { success: true, message: 'Paused YouTube playback.' };
      }

      if (action === 'resume') {
        realMedia.resumeVideo();
        return { success: true, message: 'Resumed YouTube playback.' };
      }

      const videos = await realMedia.searchYouTube(query);
      if (videos.length > 0) {
        const targetVideo = videos[0];
        realMedia.playVideo(targetVideo);
        realBrowser.openBrowser(targetVideo.url);

        this.notify({
          id: Math.random().toString(36).substring(2, 9),
          toolName: 'playYouTube',
          summary: `Playing: ${targetVideo.title}`,
          url: targetVideo.url,
          iconName: 'Youtube',
          timestamp: Date.now(),
          status: 'success',
        });

        return {
          success: true,
          action: 'play',
          video: targetVideo,
          message: `Now playing "${targetVideo.title}" by ${targetVideo.channel} on YouTube.`,
        };
      }

      return {
        success: false,
        message: `No matching YouTube videos found for "${query}".`,
      };
    });

    // 2b. playMusic (Real Music Search & Preview)
    this.registerTool('playMusic', async (args) => {
      const query = (args.query || args.song || '').trim();
      const tracks = await realMedia.searchMusic(query);

      if (tracks.length > 0) {
        const topTrack = tracks[0];
        realMedia.playMusic(topTrack);

        this.notify({
          id: Math.random().toString(36).substring(2, 9),
          toolName: 'playMusic',
          summary: `Music: ${topTrack.title} - ${topTrack.artist}`,
          iconName: 'Music',
          timestamp: Date.now(),
          status: 'success',
        });

        return {
          success: true,
          track: topTrack,
          message: `Playing "${topTrack.title}" by ${topTrack.artist}.`,
        };
      }

      return {
        success: false,
        message: `Could not locate track "${query}".`,
      };
    });

    // 2c. summarizeWebpage (Real Webpage AI Summarization)
    this.registerTool('summarizeWebpage', async (args) => {
      const targetUrl = args.url || realBrowser.getActiveTab()?.url || 'https://www.wikipedia.org';

      try {
        const summary = await realMedia.summarizeWebpage(targetUrl);
        // Speak summary using Gemini TTS
        geminiTts.speak(`Here is a summary of ${summary.title}. ${summary.summary}`);

        this.notify({
          id: Math.random().toString(36).substring(2, 9),
          toolName: 'summarizeWebpage',
          summary: `Summarized: ${summary.title}`,
          iconName: 'FileText',
          timestamp: Date.now(),
          status: 'success',
        });

        return {
          success: true,
          title: summary.title,
          summary: summary.summary,
          wordCount: summary.wordCount,
          url: summary.url,
        };
      } catch (err: any) {
        return {
          success: false,
          error: err.message || 'Webpage could not be fetched or summarized.',
        };
      }
    });

    // 2d. browserControl
    this.registerTool('browserControl', (args) => {
      const action = (args.action || '').toLowerCase();

      switch (action) {
        case 'back':
          realBrowser.goBack();
          return { success: true, message: 'Navigated back in browser.' };
        case 'forward':
          realBrowser.goForward();
          return { success: true, message: 'Navigated forward in browser.' };
        case 'reload':
        case 'refresh':
          realBrowser.reload();
          return { success: true, message: 'Reloaded current page.' };
        case 'new_tab':
          realBrowser.createTab(args.url || 'https://www.google.com');
          return { success: true, message: 'Opened new browser tab.' };
        case 'close_tab':
          realBrowser.closeTab(realBrowser.getActiveTabId());
          return { success: true, message: 'Closed active browser tab.' };
        default:
          return { success: false, message: 'Unknown browser control action.' };
      }
    });

    // 3. deviceAction (Full Android Device & Accessibility Interaction)
    this.registerTool('deviceAction', async (args) => {
      const rawAction = (args.action || '').toLowerCase().trim();

      // Timers remain managed by deviceController
      if (rawAction === 'set_timer') {
        const mins = Number(args.timerMinutes) || 5;
        const timer = deviceController.setTimer(mins, args.label);
        const msg = `Timer set for ${mins} minutes.`;
        this.notify({
          id: Math.random().toString(36).substring(2, 9),
          toolName: 'deviceAction',
          summary: msg,
          iconName: 'Timer',
          timestamp: Date.now(),
          status: 'success',
        });
        return { success: true, timerId: timer.id, message: msg };
      }

      if (rawAction === 'vibrate') {
        deviceController.vibrate([100, 50, 100]);
        return { success: true, message: 'Vibration triggered.' };
      }

      // Map action to AndroidBridge request
      let bridgeAction: any = rawAction;
      if (rawAction === 'open') bridgeAction = 'open_app';
      if (rawAction === 'back') bridgeAction = 'press_back';
      if (rawAction === 'home') bridgeAction = 'press_home';
      if (rawAction === 'recents') bridgeAction = 'press_recents';
      if (rawAction === 'click' || rawAction === 'tap') bridgeAction = 'click_node';
      if (rawAction === 'type' || rawAction === 'input') bridgeAction = 'type_text';

      const req: any = {
        action: bridgeAction,
        target: args.targetApp || args.target || args.targetElement || args.query,
        direction: args.direction,
        text: args.text,
        number: args.number || args.recipient,
        recipient: args.recipient || args.number,
        message: args.message || args.text,
        x: args.x !== undefined ? Number(args.x) : undefined,
        y: args.y !== undefined ? Number(args.y) : undefined,
        startX: args.startX !== undefined ? Number(args.startX) : undefined,
        startY: args.startY !== undefined ? Number(args.startY) : undefined,
        endX: args.endX !== undefined ? Number(args.endX) : undefined,
        endY: args.endY !== undefined ? Number(args.endY) : undefined,
        duration: args.duration !== undefined ? Number(args.duration) : undefined,
      };

      const res = await androidBridge.executeCommand(req);

      let icon = 'Smartphone';
      if (bridgeAction.includes('torch')) icon = 'Flashlight';
      else if (bridgeAction.includes('dialer')) icon = 'Phone';
      else if (bridgeAction.includes('back')) icon = 'ArrowLeft';
      else if (bridgeAction.includes('settings')) icon = 'Settings';
      else if (bridgeAction.includes('read')) icon = 'Eye';

      this.notify({
        id: Math.random().toString(36).substring(2, 9),
        toolName: 'deviceAction',
        summary: res.message,
        iconName: icon,
        timestamp: Date.now(),
        status: res.status === 'SUCCESS' || res.status === 'APP_OPENED' ? 'success' : 'warning',
      });

      return {
        success: res.status === 'SUCCESS' || res.status === 'APP_OPENED',
        status: res.status,
        action: res.action,
        message: res.message,
        native: res.native,
        data: res.data,
      };
    });

    // 4. pcAction (Windows PC Remote Control)
    this.registerTool('pcAction', async (args) => {
      const action = (args.action || '').toLowerCase();
      const appName = args.appName || 'chrome';

      const res = await desktopCompanion.executeCommand(action, { app: appName, simulate: true });
      this.notify({
        id: Math.random().toString(36).substring(2, 9),
        toolName: 'pcAction',
        summary: res.message,
        iconName: 'Monitor',
        timestamp: Date.now(),
        status: res.success ? 'success' : 'warning',
      });
      return res;
    });

    // 5. saveMemory
    this.registerTool('saveMemory', (args) => {
      const memoryText = (args.memoryText || args.text || '').trim();
      const category = (args.category || 'fact').toLowerCase();

      if (!memoryText) {
        return { error: 'Memory text was empty' };
      }

      const item = memoryCore.addMemory(memoryText, category as any, 'high');

      this.notify({
        id: Math.random().toString(36).substring(2, 9),
        toolName: 'saveMemory',
        summary: `Memory saved: "${memoryText.substring(0, 28)}..."`,
        iconName: 'Brain',
        timestamp: Date.now(),
        status: 'success',
      });

      return {
        success: true,
        memoryId: item.id,
        savedText: item.text,
        message: 'Saved to MYRAA Memory Core successfully.',
      };
    });

    // 6. recallMemory
    this.registerTool('recallMemory', (args) => {
      const query = (args.query || args.topic || '').trim();
      const matches = memoryCore.search(query);

      return {
        query,
        count: matches.length,
        memories: matches.slice(0, 4).map((m) => ({ category: m.category, text: m.text })),
        message: `Found ${matches.length} relevant memories.`,
      };
    });

    // 7. setAssistantMood
    this.registerTool('setAssistantMood', (args) => {
      const mood = (args.mood || 'electric_cyan').toLowerCase() as AssistantMood;
      const validMoods: AssistantMood[] = ['electric_cyan', 'neon_blue', 'crimson_core', 'matrix_green', 'amethyst_void'];
      const targetMood = validMoods.includes(mood) ? mood : 'electric_cyan';

      if (this.onMoodChange) {
        this.onMoodChange(targetMood);
      }

      this.notify({
        id: Math.random().toString(36).substring(2, 9),
        toolName: 'setAssistantMood',
        summary: `Hologram Theme: ${targetMood.toUpperCase()}`,
        iconName: 'Palette',
        timestamp: Date.now(),
        status: 'success',
      });

      return {
        success: true,
        currentMood: targetMood,
        message: `Hologram aura changed to ${targetMood}.`,
      };
    });

    // 8. getDeviceTime
    this.registerTool('getDeviceTime', () => {
      const now = new Date();
      const timeString = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
      const dateString = now.toLocaleDateString([], { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' });
      const timeZone = Intl.DateTimeFormat().resolvedOptions().timeZone;

      this.notify({
        id: Math.random().toString(36).substring(2, 9),
        toolName: 'getDeviceTime',
        summary: `${timeString} (${timeZone})`,
        iconName: 'Clock',
        timestamp: Date.now(),
        status: 'success',
      });

      return {
        time: timeString,
        date: dateString,
        timeZone,
        message: `Current time is ${timeString}.`,
      };
    });

    // 9. expressEmotion (Human-like visual emotion & aura sync)
    this.registerTool('expressEmotion', (args) => {
      const raw = (args.emotion || 'joyful').toLowerCase();
      const valid: AssistantEmotion[] = ['joyful', 'caring', 'playful', 'excited', 'thoughtful', 'calm', 'surprised'];
      const emotion: AssistantEmotion = valid.includes(raw as any) ? (raw as AssistantEmotion) : 'joyful';

      const def = EMOTIONS[emotion] || EMOTIONS.joyful;

      if (this.onEmotionChange) {
        this.onEmotionChange(emotion);
      }
      if (this.onMoodChange && def.recommendedMood) {
        this.onMoodChange(def.recommendedMood);
      }
      if (this.onEffectTrigger && def.effect) {
        this.onEffectTrigger(def.effect);
      }

      this.notify({
        id: Math.random().toString(36).substring(2, 9),
        toolName: 'Emotion',
        summary: `${def.emoji} MYRAA feels ${def.label}`,
        iconName: 'Heart',
        timestamp: Date.now(),
        status: 'success',
      });

      return {
        success: true,
        emotion,
        label: def.label,
        message: `MYRAA is now expressing ${def.label} emotion.`,
      };
    });
  }

  public registerTool(name: string, handler: ToolHandler): void {
    this.handlers.set(name, handler);
  }

  public async execute(name: string, args: Record<string, any>): Promise<Record<string, any>> {
    const handler = this.handlers.get(name);
    if (!handler) {
      console.warn(`[ToolManager] No handler registered for tool: ${name}`);
      return { error: `Tool "${name}" is not implemented on the client.` };
    }

    try {
      return await handler(args);
    } catch (err: any) {
      console.error(`[ToolManager] Execution error for tool "${name}":`, err);
      return { error: err.message || 'Execution failed' };
    }
  }

  private notify(notification: ToolExecutionNotification): void {
    this.onNotification?.(notification);
  }
}
