/**
 * CommandRouter - Dispatches voice/text commands to Browser, Mobile, PC, Memory, or AI Conversation.
 * Supports natural Hindi and English phrasing.
 */

import { CommandRouteResult } from '../types/live';

export class CommandRouter {
  public static route(rawText: string): CommandRouteResult {
    const text = rawText.trim().toLowerCase();

    // 1. Stop / Cancel speaking commands
    if (
      text.includes('चुप') ||
      text.includes('शांत') ||
      text.includes('रुक जाओ') ||
      text.includes('स्टॉप') ||
      text.includes('stop speaking') ||
      text.includes('shut up') ||
      text.includes('be quiet') ||
      text.includes('cancel task')
    ) {
      return {
        type: 'SYSTEM',
        action: 'STOP_SPEAKING',
        params: {},
        description: 'Stop voice output',
      };
    }

    // 2. Real Screen Sharing & Live Screen Understanding Actions
    if (
      text.includes('start screen share') ||
      text.includes('share screen') ||
      text.includes('screen share') ||
      text.includes('screen dikhao') ||
      text.includes('screen dekho') ||
      text.includes('स्क्रीन शेयर') ||
      text.includes('स्क्रीन देखो')
    ) {
      if (text.includes('stop') || text.includes('band') || text.includes('बंद')) {
        return {
          type: 'SCREEN',
          action: 'STOP_SCREEN_SHARE',
          params: {},
          description: 'Stop screen sharing',
        };
      }
      return {
        type: 'SCREEN',
        action: 'START_SCREEN_SHARE',
        params: {},
        description: 'Start screen sharing',
      };
    }

    if (
      text.includes('screen par kya') ||
      text.includes('screen par kya hai') ||
      text.includes('meri screen par kya') ||
      text.includes('what is on my screen') ||
      text.includes('what do you see on my screen') ||
      text.includes('error ko fix') ||
      text.includes('is error ko') ||
      text.includes('ye button kya karta') ||
      text.includes('ye button kya') ||
      text.includes('what does this button do') ||
      text.includes('screen analyze') ||
      text.includes('स्क्रीन पर क्या') ||
      text.includes('स्क्रीन समझो')
    ) {
      return {
        type: 'SCREEN',
        action: 'ANALYZE_SCREEN',
        params: { query: rawText },
        description: 'Analyze visible screen with Gemini Vision',
      };
    }

    // 3. Memory Actions
    if (
      text.includes('याद रखो') ||
      text.includes('याद रखना') ||
      text.includes('स्मरण') ||
      text.includes('remember') ||
      text.includes('save note') ||
      text.includes('note down')
    ) {
      const clean = rawText
        .replace(/(आल्या|alya|मायरा|myraa|vyron|कृपया|please|यह|that|याद रखो|याद रखना|remember to|remember that|remember)/gi, '')
        .trim();
      return {
        type: 'MEMORY',
        action: 'SAVE_MEMORY',
        params: { text: clean || rawText },
        description: 'Save to Memory Core',
      };
    }

    if (
      text.includes('मेरी यादें') ||
      text.includes('क्या याद है') ||
      text.includes('मेमोरी दिखाओ') ||
      text.includes('show memory') ||
      text.includes('memories') ||
      text.includes('what do you remember')
    ) {
      return {
        type: 'MEMORY',
        action: 'SHOW_MEMORIES',
        params: {},
        description: 'Review Memory Core',
      };
    }

    // 3. Media & YouTube Playback (Real Search & In-App Streaming)
    if (
      text.includes('play ') ||
      text.includes('चलाओ') ||
      text.includes('बजाओ') ||
      text.includes('सुनाओ') ||
      text.includes('song') ||
      text.includes('गाना') ||
      text.includes('music') ||
      (text.includes('youtube') && (text.includes('search') || text.includes('search youtube') || text.includes('on youtube') || text.includes('par ') || text.includes('pe ')))
    ) {
      const isMusicOnly = text.includes('music') || text.includes('संगीत') || text.includes('audio preview');
      const cleanQuery = rawText
        .replace(/(play on youtube|play on yt|play in youtube|play youtube|play song|play track|play music|play|youtube par|youtube pe|youtube par chalao|chalao|bajao|sunao|गाना बजाओ|गाना चलाओ|यूट्यूब पर चलाओ|यूट्यूब पर|चलाओ|बजाओ|सुनाओ|गाना|music)/gi, '')
        .trim();

      return {
        type: 'MEDIA',
        action: isMusicOnly ? 'PLAY_MUSIC' : 'PLAY_YOUTUBE',
        params: { query: cleanQuery || 'trending songs' },
        description: `Play ${cleanQuery || 'media'} on ${isMusicOnly ? 'Music' : 'YouTube'}`,
      };
    }

    // 4. Installed Android Applications (YouTube, Instagram, WhatsApp, Chrome, Maps, Camera)
    if (text.includes('youtube') || text.includes('यूट्यूब')) {
      return {
        type: 'MOBILE_DEVICE',
        action: 'OPEN_APP',
        params: { app: 'youtube' },
        description: 'Open YouTube App',
      };
    }

    if (text.includes('instagram') || text.includes('इंस्टाग्राम')) {
      return {
        type: 'MOBILE_DEVICE',
        action: 'OPEN_APP',
        params: { app: 'instagram' },
        description: 'Open Instagram App',
      };
    }

    if (text.includes('whatsapp') || text.includes('व्हाट्सएप')) {
      return {
        type: 'MOBILE_DEVICE',
        action: 'OPEN_APP',
        params: { app: 'whatsapp' },
        description: 'Open WhatsApp App',
      };
    }

    if (text.includes('camera') || text.includes('कैमरा') || text.includes('photo')) {
      return {
        type: 'MOBILE_DEVICE',
        action: 'OPEN_APP',
        params: { app: 'camera' },
        description: 'Open Camera App',
      };
    }

    if (text.includes('maps') || text.includes('मैप्स') || text.includes('नक्शा')) {
      return {
        type: 'MOBILE_DEVICE',
        action: 'OPEN_APP',
        params: { app: 'maps' },
        description: 'Open Google Maps App',
      };
    }

    if ((text.includes('chrome') || text.includes('क्रोम')) && !text.includes('pc') && !text.includes('कंप्यूटर')) {
      return {
        type: 'MOBILE_DEVICE',
        action: 'OPEN_APP',
        params: { app: 'chrome' },
        description: 'Open Google Chrome App',
      };
    }

    if (text.includes('spotify') || text.includes('स्पॉटिफ़ाई')) {
      return {
        type: 'MOBILE_DEVICE',
        action: 'OPEN_APP',
        params: { app: 'spotify' },
        description: 'Open Spotify App',
      };
    }

    if (text.includes('telegram') || text.includes('टेलीग्राम')) {
      return {
        type: 'MOBILE_DEVICE',
        action: 'OPEN_APP',
        params: { app: 'telegram' },
        description: 'Open Telegram App',
      };
    }

    // 4. Android Accessibility Operations (Back, Home, Recents, Notifications, Gestures)
    if (
      text.includes('shutdown mode') ||
      text.includes('go to shutdown mode') ||
      text.includes('sleep mode') ||
      text.includes('सो जाओ') ||
      text.includes('शटडाउन मोड') ||
      text.includes('ab ruk jao') ||
      text.includes('अब रुक जाओ')
    ) {
      return {
        type: 'MOBILE_DEVICE',
        action: 'SHUTDOWN_MODE',
        params: {},
        description: 'Enter Shutdown / Sleep Mode',
      };
    }

    if (
      text.includes('calculator') ||
      text.includes('कैलकुलेटर') ||
      text === 'calc' ||
      text.includes('open calculator')
    ) {
      return {
        type: 'MOBILE_DEVICE',
        action: 'OPEN_APP',
        params: { app: 'calculator' },
        description: 'Open Calculator App',
      };
    }

    if (
      text.includes('read screen') ||
      text.includes('read the screen') ||
      text.includes('read current screen') ||
      text.includes('स्क्रीन पढ़ो') ||
      text.includes('स्क्रीन पढ़कर बताओ')
    ) {
      return {
        type: 'MOBILE_DEVICE',
        action: 'READ_SCREEN',
        params: {},
        description: 'Read Current Screen Elements',
      };
    }

    if (text.includes('swipe left') || text.includes('left swipe') || text.includes('बाएं स्वाइप')) {
      return {
        type: 'MOBILE_DEVICE',
        action: 'SWIPE',
        params: { direction: 'left' },
        description: 'Swipe Left',
      };
    }

    if (text.includes('swipe right') || text.includes('right swipe') || text.includes('दाएं स्वाइप')) {
      return {
        type: 'MOBILE_DEVICE',
        action: 'SWIPE',
        params: { direction: 'right' },
        description: 'Swipe Right',
      };
    }

    if (text.includes('long press') || text.includes('लंबा दबाओ') || text.includes('long touch')) {
      const target = rawText.replace(/(long press on|long press this|long press|लंबा दबाओ|दबाकर रखो)/gi, '').trim();
      return {
        type: 'MOBILE_DEVICE',
        action: 'LONG_PRESS',
        params: { target: target || 'item' },
        description: `Long Press ${target || 'element'}`,
      };
    }

    if (text.startsWith('type ') || text.includes('टाइप करो') || text.startsWith('enter text ')) {
      const typed = rawText.replace(/(type in|type that|type text|type|टाइप करो)/gi, '').trim();
      return {
        type: 'MOBILE_DEVICE',
        action: 'TYPE_TEXT',
        params: { text: typed },
        description: `Type: "${typed}"`,
      };
    }

    if (
      (text.includes('whatsapp') || text.includes('व्हाट्सएप') || text.includes('message') || text.includes('संदेश')) &&
      (text.includes('send ') || text.includes('bhejo') || text.includes('भेजो'))
    ) {
      const match = rawText.match(/(?:send|भेजो)\s+(?:message\s+)?["']?([^"']+)["']?\s+(?:to|को)\s+([a-zA-Z0-9\s]+)/i) ||
                    rawText.match(/(?:send|भेजो)\s+([a-zA-Z0-9\s]+)\s+(?:the message|message|को)\s+["']?([^"']+)["']?/i);
      let recipient = 'contact';
      let message = 'Hello';
      if (match) {
        if (match[2] && match[1]) {
          recipient = match[2].trim();
          message = match[1].trim();
        }
      }
      return {
        type: 'MOBILE_DEVICE',
        action: 'SEND_MESSAGE',
        params: { recipient, message, app: text.includes('whatsapp') ? 'whatsapp' : 'sms', confirmed: false },
        confirmationRequired: true,
        description: `Send ${message} to ${recipient}`,
      };
    }

    if (
      (text.includes('tap ') || text.includes('click on') || text.includes('tap on') || text.includes('क्लिक करो') || text.includes('दबाओ')) &&
      !text.includes('picture') && !text.includes('photo') && !text.includes('chalao')
    ) {
      const target = rawText.replace(/(tap on the|tap on|click on the|click on|tap the|click the|tap|click|पर क्लिक करो|क्लिक करो|दबाओ)/gi, '').trim();
      return {
        type: 'MOBILE_DEVICE',
        action: 'TAP_ELEMENT',
        params: { target: target || 'search' },
        description: `Tap on "${target || 'element'}"`,
      };
    }

    if (
      text.includes('press back') ||
      text.includes('go back') ||
      text.includes('back jao') ||
      text.includes('pichhle page') ||
      text.includes('पिछला पेज') ||
      text.includes('पीछे जाओ') ||
      text.includes('बैक जाओ')
    ) {
      return {
        type: 'MOBILE_DEVICE',
        action: 'PRESS_BACK',
        params: {},
        description: 'Press Back Button',
      };
    }

    if (
      text.includes('go home') ||
      text.includes('press home') ||
      text.includes('home screen') ||
      text.includes('home jao') ||
      text.includes('होम स्क्रीन') ||
      text.includes('होम जाओ')
    ) {
      return {
        type: 'MOBILE_DEVICE',
        action: 'PRESS_HOME',
        params: {},
        description: 'Navigate to Home Screen',
      };
    }

    if (
      text.includes('recent apps') ||
      text.includes('open recents') ||
      text.includes('show recents') ||
      text.includes('recents dikhao') ||
      text.includes('रिसेंट')
    ) {
      return {
        type: 'MOBILE_DEVICE',
        action: 'PRESS_RECENTS',
        params: {},
        description: 'Open Recent Apps',
      };
    }

    if (
      text.includes('open notifications') ||
      text.includes('show notifications') ||
      text.includes('notification panel') ||
      text.includes('नोटिफिकेशन')
    ) {
      return {
        type: 'MOBILE_DEVICE',
        action: 'OPEN_NOTIFICATIONS',
        params: {},
        description: 'Open Notification Drawer',
      };
    }

    if (
      text.includes('quick settings') ||
      text.includes('क्विक सेटिंग्स')
    ) {
      return {
        type: 'MOBILE_DEVICE',
        action: 'OPEN_QUICK_SETTINGS',
        params: {},
        description: 'Open Quick Settings',
      };
    }

    if (
      text.includes('lock screen') ||
      text.includes('phone lock') ||
      text.includes('स्क्रीन लॉक') ||
      text.includes('फोन लॉक')
    ) {
      return {
        type: 'MOBILE_DEVICE',
        action: 'LOCK_SCREEN',
        params: {},
        description: 'Lock Phone Screen',
      };
    }

    if (
      text.includes('take screenshot') ||
      text.includes('screenshot lo') ||
      text.includes('स्क्रीनशॉट')
    ) {
      return {
        type: 'MOBILE_DEVICE',
        action: 'TAKE_SCREENSHOT',
        params: {},
        description: 'Take Screen Capture',
      };
    }

    if (
      text.includes('scroll down') ||
      text.includes('नीचे स्क्रॉल') ||
      text.includes('neeche scroll')
    ) {
      return {
        type: 'MOBILE_DEVICE',
        action: 'SCROLL',
        params: { direction: 'down' },
        description: 'Scroll Down',
      };
    }

    if (
      text.includes('scroll up') ||
      text.includes('ऊपर स्क्रॉल') ||
      text.includes('upar scroll')
    ) {
      return {
        type: 'MOBILE_DEVICE',
        action: 'SCROLL',
        params: { direction: 'up' },
        description: 'Scroll Up',
      };
    }

    // 5. Device Utilities: Torch, Timer, Dialer, SMS, Settings
    if (text.includes('टॉर्च') || text.includes('फ्लैश') || text.includes('torch') || text.includes('flashlight')) {
      return {
        type: 'MOBILE_DEVICE',
        action: 'TOGGLE_TORCH',
        params: {},
        description: 'Toggle Torch',
      };
    }

    if (text.includes('dialer') || text.includes('phone') || text.includes('कॉल') || text.includes('फोन मिलाओ')) {
      return {
        type: 'MOBILE_DEVICE',
        action: 'OPEN_DIALER',
        params: {},
        description: 'Open Phone Dialer',
      };
    }

    if (text.includes('टाइमर') || text.includes('अलार्म') || text.includes('timer') || text.includes('alarm')) {
      const match = text.match(/(\d+)\s*(मिनट|minute|min|सेकंड|second|sec)/);
      const minutes = match ? parseFloat(match[1]) : 5;
      return {
        type: 'MOBILE_DEVICE',
        action: 'SET_TIMER',
        params: { minutes, label: rawText },
        description: `Set timer for ${minutes} min`,
      };
    }

    if (text.includes('सेटिंग्स') || text.includes('फोन सेटिंग्स') || text.includes('device settings')) {
      return {
        type: 'MOBILE_DEVICE',
        action: 'OPEN_SETTINGS',
        params: {},
        description: 'Open Device Settings',
      };
    }

    // 4. PC Remote Control Actions
    if (
      text.includes('कंप्यूटर') ||
      text.includes('पीसी') ||
      text.includes('लैपटॉप') ||
      text.includes('pc') ||
      text.includes('computer')
    ) {
      if (text.includes('वॉल्यूम') || text.includes('volume')) {
        const isUp = text.includes('बढ़ा') || text.includes('up') || text.includes('तेज़');
        return {
          type: 'PC_CONTROL',
          action: isUp ? 'volume_up' : 'volume_down',
          params: {},
          description: isUp ? 'Increase PC Volume' : 'Decrease PC Volume',
        };
      }

      if (text.includes('लॉक') || text.includes('lock')) {
        return {
          type: 'PC_CONTROL',
          action: 'lock_pc',
          params: {},
          confirmationRequired: true,
          description: 'Lock PC Workstation',
        };
      }

      if (text.includes('क्रोम') || text.includes('chrome')) {
        return {
          type: 'PC_CONTROL',
          action: 'open_app',
          params: { app: 'chrome' },
          description: 'Open Chrome on PC',
        };
      }

      if (text.includes('नोटपैड') || text.includes('notepad')) {
        return {
          type: 'PC_CONTROL',
          action: 'open_app',
          params: { app: 'notepad' },
          description: 'Open Notepad on PC',
        };
      }

      return {
        type: 'PC_CONTROL',
        action: 'status',
        params: {},
        description: 'Check PC Status',
      };
    }

    // 5. YouTube Video Playback & Controls
    if (
      text.includes('youtube') ||
      text.includes('यूट्यूब') ||
      text.includes('video') ||
      text.includes('वीडियो')
    ) {
      if (text.includes('pause') || text.includes('रोक') || text.includes('पाउज़')) {
        return {
          type: 'MEDIA',
          action: 'PAUSE_YOUTUBE',
          params: {},
          description: 'Pause YouTube Video',
        };
      }

      if (text.includes('resume') || text.includes('play again') || text.includes('चलाओ')) {
        if (!text.includes('search') && !text.includes('find') && (text.includes('resume') || text === 'video chalao' || text === 'play video')) {
          return {
            type: 'MEDIA',
            action: 'RESUME_YOUTUBE',
            params: {},
            description: 'Resume YouTube Playback',
          };
        }
      }

      const cleanQuery = rawText
        .replace(/(मायरा|myraa|vyron|कृपया|please|यूट्यूब पर|यूट्यूब|youtube par|youtube|चलाओ|play video|play on youtube|play|search youtube for|search for)/gi, '')
        .trim();

      if (cleanQuery) {
        return {
          type: 'MEDIA',
          action: 'PLAY_YOUTUBE',
          params: { query: cleanQuery },
          description: `Play "${cleanQuery}" on YouTube`,
        };
      }
    }

    // 6. Music Playback & Track Search
    if (
      text.includes('play song') ||
      text.includes('play music') ||
      text.includes('गाना बजाओ') ||
      text.includes('गाना सुनाओ') ||
      text.includes('music sunao') ||
      text.includes('gana bajao') ||
      text.includes('song bajao')
    ) {
      const cleanSong = rawText
        .replace(/(मायरा|myraa|vyron|कृपया|please|गाना बजाओ|गाना सुनाओ|play song|play music|gana bajao|song bajao|play)/gi, '')
        .trim();

      return {
        type: 'MEDIA',
        action: 'PLAY_MUSIC',
        params: { query: cleanSong || 'Top Indian Songs' },
        description: `Play "${cleanSong || 'music'}"`,
      };
    }

    // 7. Webpage Summarization
    if (
      text.includes('summarize this page') ||
      text.includes('summarize article') ||
      text.includes('explain this webpage') ||
      text.includes('page ka summary') ||
      text.includes('पेज का सारांश') ||
      text.includes('summarize page') ||
      text.includes('summarize website')
    ) {
      return {
        type: 'BROWSER',
        action: 'SUMMARIZE',
        params: {},
        description: 'Summarize Active Webpage',
      };
    }

    // 8. Real Integrated Browser Controls & Search
    if (
      text === 'open browser' ||
      text === 'browser kholo' ||
      text === 'ब्राउज़र खोलो' ||
      text === 'start browser'
    ) {
      return {
        type: 'BROWSER',
        action: 'OPEN_BROWSER',
        params: {},
        description: 'Open Integrated Browser',
      };
    }

    if (
      text === 'close browser' ||
      text === 'browser band karo' ||
      text === 'ब्राउज़र बंद करो'
    ) {
      return {
        type: 'BROWSER',
        action: 'CLOSE_BROWSER',
        params: {},
        description: 'Close Integrated Browser',
      };
    }

    if (
      text.includes('ब्राउज़र') ||
      text.includes('वेबसाइट') ||
      text.includes('सर्च करो') ||
      text.includes('browser') ||
      text.includes('search for') ||
      text.includes('open website') ||
      text.includes('गूगल') ||
      text.includes('google') ||
      text.includes('विकिपीडिया') ||
      text.includes('wikipedia') ||
      text.startsWith('http://') ||
      text.startsWith('https://') ||
      text.includes('.com') ||
      text.includes('.org')
    ) {
      let targetUrl = 'https://www.google.com';
      let isSearch = false;

      if (text.includes('विकिपीडिया') || text.includes('wikipedia')) {
        const q = rawText.replace(/(विकिपीडिया पर|विकिपीडिया|wikipedia on|wikipedia)/gi, '').trim();
        targetUrl = q ? `https://en.wikipedia.org/wiki/Special:Search?search=${encodeURIComponent(q)}` : 'https://en.wikipedia.org';
      } else if (text.includes('सर्च') || text.includes('search') || text.includes('गूगल')) {
        const q = rawText.replace(/(सर्च करो|खोजो|search for|search|गूगल पर|google for|google)/gi, '').trim();
        targetUrl = `https://www.google.com/search?q=${encodeURIComponent(q || 'MYRAA AI')}`;
        isSearch = true;
      } else if (text.startsWith('http://') || text.startsWith('https://')) {
        targetUrl = rawText.trim();
      } else {
        const q = rawText.replace(/(open website|open|वेबसाइट खोलो)/gi, '').trim();
        if (q.includes('.')) targetUrl = `https://${q}`;
        else targetUrl = `https://www.google.com/search?q=${encodeURIComponent(q)}`;
      }

      return {
        type: 'BROWSER',
        action: isSearch ? 'SEARCH' : 'NAVIGATE',
        params: { url: targetUrl, query: rawText },
        description: `Browser: ${targetUrl}`,
      };
    }

    // 9. Conversational intelligence via Gemini
    return {
      type: 'CONVERSATION',
      action: 'CHAT',
      params: { text: rawText },
      description: 'Voice Conversation',
    };
  }
}
