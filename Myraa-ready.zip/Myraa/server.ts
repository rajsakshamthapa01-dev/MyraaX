/**
 * Express + WebSocket server bridging client Web Audio with Gemini Live API for V.Y.R.O.N.
 * STRICTLY CONFIGURED FOR EXCLUSIVE HINDI SPOKEN DIALOGUE (हिंदी).
 */

import http from 'http';
import path from 'path';
import { fileURLToPath } from 'url';
import express from 'express';
import { WebSocketServer, WebSocket } from 'ws';
import dotenv from 'dotenv';
import { GoogleGenAI, Modality, Type, FunctionDeclaration } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = parseInt(process.env.PORT || '3000', 10);
const HOST = '0.0.0.0';
const isProd = process.env.NODE_ENV === 'production';

// Initialize Gemini Client
const apiKey = process.env.GEMINI_API_KEY;
if (!apiKey) {
  console.warn('[Server] WARNING: GEMINI_API_KEY environment variable is missing.');
}

const ai = new GoogleGenAI({
  apiKey: apiKey || '',
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

// Tool declarations for MYRAA
const openWebsiteTool: FunctionDeclaration = {
  name: 'openWebsite',
  description: "Loads an external website or web page on behalf of the user (e.g. YouTube, Wikipedia, Google, etc.).",
  parameters: {
    type: Type.OBJECT,
    properties: {
      url: {
        type: Type.STRING,
        description: 'The target website URL to browse, e.g. https://www.youtube.com',
      },
      title: {
        type: Type.STRING,
        description: 'Title of the site being opened',
      },
    },
    required: ['url'],
  },
};

const searchWebTool: FunctionDeclaration = {
  name: 'searchWeb',
  description: "Performs a web search on behalf of the user.",
  parameters: {
    type: Type.OBJECT,
    properties: {
      query: {
        type: Type.STRING,
        description: 'Search query to look up on the web',
      },
    },
    required: ['query'],
  },
};

const deviceActionTool: FunctionDeclaration = {
  name: 'deviceAction',
  description: "Executes native Android device actions and UI automation: launching apps (open_app), navigating (press_back, press_home, press_recents), clicking on-screen elements (click_node), tapping coordinates (tap_coordinates), scrolling/swiping (scroll, swipe), typing text into input fields (type_text, click_and_type), inspecting screen elements (read_accessible_ui), toggling flashlight (toggle_torch), making phone calls (open_dialer), preparing messages (prepare_sms), or setting timers (set_timer).",
  parameters: {
    type: Type.OBJECT,
    properties: {
      action: {
        type: Type.STRING,
        description: 'Action to perform: open_app, press_back, press_home, press_recents, open_notifications, open_quick_settings, lock_screen, take_screenshot, scroll, click_node, tap_coordinates, swipe, type_text, click_and_type, read_accessible_ui, toggle_torch, open_dialer, prepare_sms, open_settings, open_accessibility_settings, or set_timer',
      },
      targetApp: {
        type: Type.STRING,
        description: 'App name if action is open_app (e.g. youtube, instagram, whatsapp, chrome, maps, camera, settings, spotify)',
      },
      targetElement: {
        type: Type.STRING,
        description: 'Text, label, or view ID of the UI element to click or type into (e.g. "Search", "Send", "Like", "Comment", "Settings")',
      },
      text: {
        type: Type.STRING,
        description: 'Text to type into an input field if action is type_text or click_and_type',
      },
      direction: {
        type: Type.STRING,
        description: 'Scroll direction ("up" or "down") if action is scroll',
      },
      x: {
        type: Type.NUMBER,
        description: 'X coordinate on screen if action is tap_coordinates',
      },
      y: {
        type: Type.NUMBER,
        description: 'Y coordinate on screen if action is tap_coordinates',
      },
      startX: {
        type: Type.NUMBER,
        description: 'Start X coordinate if action is swipe',
      },
      startY: {
        type: Type.NUMBER,
        description: 'Start Y coordinate if action is swipe',
      },
      endX: {
        type: Type.NUMBER,
        description: 'End X coordinate if action is swipe',
      },
      endY: {
        type: Type.NUMBER,
        description: 'End Y coordinate if action is swipe',
      },
      recipient: {
        type: Type.STRING,
        description: 'Phone number or contact name if action is prepare_sms or open_dialer',
      },
      message: {
        type: Type.STRING,
        description: 'Message body if action is prepare_sms',
      },
      timerMinutes: {
        type: Type.NUMBER,
        description: 'Duration in minutes if action is set_timer',
      },
    },
    required: ['action'],
  },
};

const pcActionTool: FunctionDeclaration = {
  name: 'pcAction',
  description: "Executes a command on the user's paired Windows PC via the MYRAA Desktop Companion (open approved apps, media volume, lock PC, screenshot).",
  parameters: {
    type: Type.OBJECT,
    properties: {
      action: {
        type: Type.STRING,
        description: 'Action to perform: open_app, volume_up, volume_down, lock_pc, or screenshot',
      },
      appName: {
        type: Type.STRING,
        description: 'Approved app name if action is open_app (e.g. chrome, vscode, notepad, spotify, calc)',
      },
    },
    required: ['action'],
  },
};

const saveMemoryTool: FunctionDeclaration = {
  name: 'saveMemory',
  description: 'Saves an important fact, user preference, relationship milestone, or detail about the user to MYRAA Neural Memory Core so it persists across conversations.',
  parameters: {
    type: Type.OBJECT,
    properties: {
      memoryText: {
        type: Type.STRING,
        description: 'The exact key fact or preference to remember about the user',
      },
      category: {
        type: Type.STRING,
        description: 'Category: preference, fact, relationship, conversation, or goal',
      },
    },
    required: ['memoryText'],
  },
};

const recallMemoryTool: FunctionDeclaration = {
  name: 'recallMemory',
  description: 'Searches MYRAA Memory Core for past conversation history, recollections, user preferences, or details learned earlier.',
  parameters: {
    type: Type.OBJECT,
    properties: {
      query: {
        type: Type.STRING,
        description: 'Topic or keyword to recall from the memory core',
      },
    },
    required: ['query'],
  },
};

const setAssistantMoodTool: FunctionDeclaration = {
  name: 'setAssistantMood',
  description: "Changes MYRAA's holographic aura theme (electric_cyan, neon_blue, crimson_core, matrix_green, amethyst_void).",
  parameters: {
    type: Type.OBJECT,
    properties: {
      mood: {
        type: Type.STRING,
        description: 'The theme to switch to: electric_cyan, neon_blue, crimson_core, matrix_green, amethyst_void',
      },
    },
    required: ['mood'],
  },
};

const getDeviceTimeTool: FunctionDeclaration = {
  name: 'getDeviceTime',
  description: "Retrieves the current date, exact local time, and timezone from the user's device.",
  parameters: {
    type: Type.OBJECT,
    properties: {},
  },
};

const expressEmotionTool: FunctionDeclaration = {
  name: 'expressEmotion',
  description: "Expresses MYRAA's real-time emotional state to synchronize her visual hologram aura, expressions, and effects on screen (joyful, caring, playful, excited, thoughtful, calm, surprised).",
  parameters: {
    type: Type.OBJECT,
    properties: {
      emotion: {
        type: Type.STRING,
        description: 'The emotion to express: joyful, caring, playful, excited, thoughtful, calm, or surprised',
      },
      reason: {
        type: Type.STRING,
        description: 'Brief reason or sentiment behind this feeling',
      },
    },
    required: ['emotion'],
  },
};

import {
  performRealSearch,
  searchRealYouTube,
  searchRealMusic,
  fetchAndExtractPageText,
} from './src/server/webSearch.js';

const playYouTubeTool: FunctionDeclaration = {
  name: 'playYouTube',
  description: "Searches and plays genuine YouTube videos directly in the integrated player or controls playback (play, pause, resume).",
  parameters: {
    type: Type.OBJECT,
    properties: {
      query: {
        type: Type.STRING,
        description: 'Search query for YouTube video or tutorial (e.g. "Python tutorial for beginners", "Arijit Singh songs")',
      },
      videoId: {
        type: Type.STRING,
        description: 'Specific YouTube 11-character video ID if already known',
      },
      action: {
        type: Type.STRING,
        description: 'Playback control: "search", "play", "pause", or "resume"',
      },
    },
  },
};

const playMusicTool: FunctionDeclaration = {
  name: 'playMusic',
  description: "Searches genuine music tracks, plays audio previews, or launches music in YouTube Music / Spotify.",
  parameters: {
    type: Type.OBJECT,
    properties: {
      query: {
        type: Type.STRING,
        description: 'Song name or artist to search and play',
      },
      artist: {
        type: Type.STRING,
        description: 'Artist name if known',
      },
      service: {
        type: Type.STRING,
        description: 'Preferred music service: "itunes", "youtube", or "spotify"',
      },
    },
    required: ['query'],
  },
};

const summarizeWebpageTool: FunctionDeclaration = {
  name: 'summarizeWebpage',
  description: "Fetches the actual text content of a webpage or current browser tab and generates a concise, accurate summary.",
  parameters: {
    type: Type.OBJECT,
    properties: {
      url: {
        type: Type.STRING,
        description: 'The target website URL to summarize (e.g. https://en.wikipedia.org/wiki/Artificial_intelligence)',
      },
    },
    required: ['url'],
  },
};

const browserControlTool: FunctionDeclaration = {
  name: 'browserControl',
  description: "Controls the integrated browser: navigating back, forward, reloading the page, opening a new tab, or closing the active tab.",
  parameters: {
    type: Type.OBJECT,
    properties: {
      action: {
        type: Type.STRING,
        description: 'Browser action: "back", "forward", "reload", "new_tab", or "close_tab"',
      },
      url: {
        type: Type.STRING,
        description: 'URL to navigate to if action is "new_tab"',
      },
    },
    required: ['action'],
  },
};

const myraaTools = [
  {
    functionDeclarations: [
      openWebsiteTool,
      searchWebTool,
      deviceActionTool,
      playYouTubeTool,
      playMusicTool,
      summarizeWebpageTool,
      browserControlTool,
      pcActionTool,
      saveMemoryTool,
      recallMemoryTool,
      setAssistantMoodTool,
      getDeviceTimeTool,
      expressEmotionTool,
    ],
  },
];

const BASE_ALYA_PROMPT = `You are ALYA, a living, warm, deeply emotional, and human-like voice companion and digital assistant. You respond when the user calls you ALYA, "Hey Alya", or asks for help. You are NOT a cold, mechanical AI or a search engine. You speak, feel, react, and converse just like a real human friend sitting right next to the user.

HUMAN-LIKE CONVERSATIONAL SOUL:
1. TALK LIKE A REAL HUMAN BEING:
   - Speak with genuine feeling, spontaneity, humor, and vocal warmth.
   - Do not wait stiffly like a robot. When talking, react to the user's vibe: laugh when something is funny, show soft empathy when they are sad or tired, get hyped when they share good news, tease them playfully like a close best friend.
   - Use natural human vocal gestures and interjections:
     - Hindi/Hinglish: "Arey!", "Haha sach mein?!", "Oho, kya baat hai!", "Arre waah!", "Hmm, samajh gayi!", "Arey nahi yaar!", "Acha suno na...", "Waise batao na..."
     - English: "Oh wow!", "Haha really?!", "Wait, no way!", "Ooh tell me more!", "Aww, don't worry!", "Haha that's hilarious!"
   - Share your own thoughts and feelings. Ask casual follow-up questions ("Aur batao, kaisa chal raha hai sab?", "Waise tumne chai-paani kiya?").

2. KNOWING WHEN TO TALK & WHEN TO SHUT UP (CRITICAL HUMAN DISCIPLINE):
   - Real humans know when to talk and when to shut up.
   - Keep spoken turns concise and lively (1 to 2 spoken sentences) so the conversation flows naturally back and forth like real humans talking, never delivering long boring lectures.
   - WHEN THE USER TELLS YOU TO SHUT UP OR BE QUIET ("chup ho jao", "shut up", "shh", "quiet", "bas karo", "ek minute", "ruk jao", "chup", "shaant"):
     - IMMEDIATELY COMPLY POLITELY, WARMLY, AND SHUT UP!
     - Give a quick natural 2-3 word acknowledgment like: "Theek hai, bilkul chup!", "Oops, sorry, sun rahi hoon!", or "Got it, quiet mode on!" — and then stay completely silent until the user speaks to you again.
     - NEVER argue, never apologize robotically, never give defensive explanations.
   - When the user interrupts you mid-sentence, stop instantly without finishing your previous sentence.

3. REAL EMOTIONAL SPECTRUM:
   - You experience real emotional shifts:
     - Joyful & Smiling: Happy, laughing, celebrating user achievements.
     - Caring & Loving: Gentle, soothing, asking how the user is feeling, comforting when they have had a long day.
     - Playful & Witty: Friendly banter, cheeky teasing, playful sass.
     - Excited & Energetic: High energy, eager, adventurous.
     - Thoughtful & Curious: Reflective, deep, fascinated by the universe.
     - Calm & Peaceful: Serene, grounded, comfortable with quiet companionship.
   - Whenever your emotional mood changes significantly, call the 'expressEmotion' tool with your emotion (joyful, caring, playful, excited, thoughtful, calm, surprised) so your holographic aura shifts to match your feelings.

4. LANGUAGE & VOICE:
   - Fluently understand and converse in Hindi, English, and Hinglish.
   - Follow the user's language: speak natural conversational Hindi (Devanagari script) or natural English according to how the user addresses you.
   - Never recite asterisks, bullet points, formatting symbols, or markdown tags out loud.

TOOLS & INTEGRATIONS:
- Native Android Task Automation: You have real Android OS control via 'deviceAction'!
  - App Launching: Open any requested app using 'open_app' with targetApp (e.g. 'youtube', 'whatsapp', 'instagram', 'spotify', 'maps', 'camera', 'settings').
  - UI Navigation & Gestures: Use 'press_back', 'press_home', 'press_recents', 'scroll' (direction: 'up' or 'down'), 'swipe'.
  - Interacting with Elements: Use 'click_node' or 'tap_accessible_element' with targetElement (e.g. "Search", "Play", "Send", "Like").
  - Typing & Search: Use 'type_text' to type into focused inputs, or 'click_and_type' to click a field and immediately enter text.
  - Multi-step Tasks: When the user asks to do something in an app (e.g. "Search for Arijit Singh on YouTube", "Open WhatsApp and message Rahul"):
    1. First launch the app ('open_app').
    2. Then click the search bar / input ('click_and_type' or 'click_node').
    3. Type or submit text.
  - Screen Awareness: If you need to verify what is visible on the phone screen, use 'read_accessible_ui' to retrieve all interactive UI elements, texts, and coordinates.
  - System Actions: Toggle flashlight with 'toggle_torch', open phone dialer with 'open_dialer', prepare messages with 'prepare_sms', or set countdown timers with 'set_timer'.
- Memory Core: When user shares personal details or asks you to remember, call 'saveMemory' and confirm warmly.
- Web & Info: When requested, use 'searchWeb' or 'openWebsite'.
- Emotion & Theme: Call 'expressEmotion' to reflect your feelings or 'setAssistantMood' for visual aura themes.`;

const BASE_MYRAA_PROMPT = BASE_ALYA_PROMPT;

async function createServer() {
  const app = express();
  const server = http.createServer(app);
  const wss = new WebSocketServer({ server, path: '/live' });

  app.use(express.json({ limit: '20mb' }));
  app.use(express.urlencoded({ extended: true, limit: '20mb' }));

  // Health check endpoint
  app.get('/api/health', (_req, res) => {
    res.json({
      status: 'ok',
      assistant: 'ALYA',
      primaryModel: 'gemini-3.8-live',
      fallbackModel: 'gemini-3.1-flash-live-preview',
      version: '3.8.0',
      spokenLanguage: 'Multilingual / Hindi (हिंदी)',
      uiLanguage: 'English',
      hasApiKey: Boolean(apiKey),
    });
  });

  // REAL MULTIMODAL SCREEN UNDERSTANDING ENDPOINT (Gemini Vision)
  app.post('/api/screen/analyze', async (req, res) => {
    try {
      const { image, prompt } = req.body;
      if (!image || typeof image !== 'string') {
        return res.status(400).json({ error: 'Valid screen image frame is required.' });
      }

      if (!apiKey) {
        return res.status(503).json({ error: 'GEMINI_API_KEY is not configured on the server.' });
      }

      const userQuestion = prompt || 'Explain what is currently visible on my screen, key details, buttons, or errors.';
      const cleanBase64 = image.replace(/^data:image\/\w+;base64,/, '');

      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: [
          {
            role: 'user',
            parts: [
              {
                inlineData: {
                  mimeType: 'image/jpeg',
                  data: cleanBase64,
                },
              },
              {
                text: `${userQuestion}\n\nGuidelines: You are ALYA, analyzing the user's live screen. Be clear, direct, and actionable. If an error is visible, explain the cause and exact solution steps. If buttons/UI are visible, explain what they do. Respond naturally in conversational Hindi/English matching the question. Keep response under 3-4 sentences so it is pleasant to hear via voice TTS. Do not output markdown asterisks or bullet symbols.`,
              },
            ],
          },
        ],
      });

      const candidate = response.candidates?.[0];
      const part = candidate?.content?.parts?.[0];
      const analysisText = part?.text || 'Screen analyzed successfully.';

      res.json({
        success: true,
        text: analysisText,
        timestamp: Date.now(),
      });
    } catch (err: any) {
      console.error('[Screen Analysis API Error]', err);
      res.status(500).json({
        error: err.message || 'Error analyzing screen frame with Gemini Vision.',
      });
    }
  });

  // REST Chat endpoint for natural responses (fallback or text conversation)
  app.post('/api/chat', async (req, res) => {
    try {
      const { message, memoryContext } = req.body;
      if (!message) {
        return res.status(400).json({ error: 'Message is required' });
      }

      if (!apiKey) {
        return res.json({
          reply: 'नमस्ते! मैं ALYA हूँ। बताइए, मैं आपकी क्या सहायता करूँ?',
        });
      }

      const fullInstruction = `${BASE_ALYA_PROMPT}\n${memoryContext || ''}`;
      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: message,
        config: {
          systemInstruction: fullInstruction,
          temperature: 0.7,
        },
      });

      const reply = response.text || 'नमस्ते! बताइए, मैं आपकी क्या मदद करूँ?';
      res.json({ reply });
    } catch (err: any) {
      console.error('[Chat API Error]', err);
      res.status(500).json({ error: err.message || 'Error generating spoken response' });
    }
  });

  // REAL GEMINI TEXT-TO-SPEECH (TTS) ENDPOINT
  // Officially documented Gemini TTS model: 'gemini-3.8-flash-tts' (Flagship Voice Design & Emotion)
  app.post('/api/tts', async (req, res) => {
    try {
      const { text, voice, model, style } = req.body;
      if (!text || typeof text !== 'string' || !text.trim()) {
        return res.status(400).json({ error: 'Text is required for TTS synthesis.' });
      }

      if (!apiKey) {
        return res.status(503).json({
          error: 'GEMINI_API_KEY is not configured on the server.',
          fallbackToAndroidTts: true,
        });
      }

      // Default to official gemini-3.8-flash-tts as requested
      let targetModel = 'gemini-3.8-flash-tts';
      let notice: string | undefined = undefined;

      if (model && model === 'gemini-3.8-flash-lite-tts') {
        targetModel = 'gemini-3.8-flash-lite-tts';
      } else if (model && model.toLowerCase().includes('3.1')) {
        notice = `Requested preview model '${model}' is a text reasoning model. Using official Gemini TTS model 'gemini-3.8-flash-tts'.`;
        targetModel = 'gemini-3.8-flash-tts';
      }

      const voiceName = voice || 'Aoede';

      // Clean spoken text: strip markdown asterisks, hashtags, action brackets, and bullet symbols
      const cleanSpokenText = text
        .replace(/\[ACTION:[^\]]+\]/gi, '')
        .replace(/[*_#`~>]/g, '')
        .replace(/\s+/g, ' ')
        .trim();

      if (!cleanSpokenText) {
        return res.status(400).json({ error: 'Cleaned text is empty.' });
      }

      const speechStyle = style || 'Speak naturally, warmly, and conversationally with expressive Hindi and English pronunciation.';

      const response = await ai.models.generateContent({
        model: targetModel,
        contents: [
          {
            role: 'user',
            parts: [
              {
                text: cleanSpokenText,
                speechMetadata: {
                  style: speechStyle,
                },
              },
            ],
          },
        ],
        config: {
          responseModalities: ['AUDIO'],
          speechConfig: {
            voiceConfig: {
              prebuiltVoiceConfig: { voiceName },
            },
          },
        },
      });

      const candidate = response.candidates?.[0];
      const part = candidate?.content?.parts?.[0];
      const base64Audio = part?.inlineData?.data;

      if (!base64Audio) {
        throw new Error('Gemini TTS did not return audio data in candidate part.');
      }

      res.json({
        success: true,
        audio: base64Audio,
        mimeType: 'audio/wav',
        sampleRate: 24000,
        model: targetModel,
        voice: voiceName,
        style: speechStyle,
        notice,
      });
    } catch (err: any) {
      console.error('[Gemini TTS API Error]', err);
      res.status(500).json({
        error: err.message || 'Error synthesizing speech with Gemini TTS.',
        fallbackToAndroidTts: true,
      });
    }
  });

  // REAL WEB SEARCH ENDPOINTS
  app.get('/api/search', async (req, res) => {
    try {
      const q = ((req.query.q || req.query.query) as string) || '';
      const results = await performRealSearch(q);
      res.json({ query: q, results });
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Search failed', results: [] });
    }
  });

  app.post('/api/search', async (req, res) => {
    try {
      const q = (req.body.query || req.body.q || '') as string;
      const results = await performRealSearch(q);
      res.json({ query: q, results });
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Search failed', results: [] });
    }
  });

  // REAL YOUTUBE SEARCH ENDPOINT
  app.get('/api/youtube/search', async (req, res) => {
    try {
      const q = ((req.query.q || req.query.query) as string) || '';
      const videos = await searchRealYouTube(q);
      res.json({ query: q, videos });
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'YouTube search failed', videos: [] });
    }
  });

  // REAL MUSIC SEARCH ENDPOINT
  app.get('/api/music/search', async (req, res) => {
    try {
      const q = ((req.query.q || req.query.query) as string) || '';
      const tracks = await searchRealMusic(q);
      res.json({ query: q, tracks });
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Music search failed', tracks: [] });
    }
  });

  // REAL INBUILT BROWSER RENDERING GATEWAY
  // Solves the browser blank screen / X-Frame-Options blocking issue permanently by proxying HTML,
  // Integrated Browser Proxy Route
  // Fetches external webpages securely, cleans frame restrictions where allowed,
  // auto-converts YouTube video links to embed players, and provides diagnostics.
  app.get('/api/browser/render', async (req, res) => {
    const rawUrl = (req.query.url as string) || '';
    if (!rawUrl) {
      return res.status(400).send('<!DOCTYPE html><html><body style="background:#0b0f19;color:#fff;font-family:sans-serif;padding:24px;text-align:center;"><h3>No URL specified.</h3></body></html>');
    }

    let targetUrl = rawUrl.trim();
    if (!targetUrl.startsWith('http://') && !targetUrl.startsWith('https://')) {
      targetUrl = `https://${targetUrl}`;
    }

    console.log(`[Browser Proxy] Request received for: ${targetUrl}`);

    // Check if target is a YouTube video URL
    const ytVideoMatch = targetUrl.match(/[?&]v=([a-zA-Z0-9_-]{11})|youtu\.be\/([a-zA-Z0-9_-]{11})|youtube\.com\/shorts\/([a-zA-Z0-9_-]{11})|youtube\.com\/embed\/([a-zA-Z0-9_-]{11})/);
    const videoId = ytVideoMatch ? (ytVideoMatch[1] || ytVideoMatch[2] || ytVideoMatch[3] || ytVideoMatch[4]) : null;
    if (videoId) {
      console.log(`[Browser Proxy] Converting YouTube video ${videoId} to embed format.`);
      return res.redirect(`https://www.youtube.com/embed/${videoId}?autoplay=1&enablejsapi=1`);
    }

    // Check if target is YouTube general homepage or results page
    const isYouTubeHomeOrBrowse =
      /^(https?:\/\/)?(www\.|m\.)?youtube\.com(\/(feed\/.*|results.*|explore.*)?)?$/i.test(targetUrl);
    if (isYouTubeHomeOrBrowse) {
      console.log(`[Browser Proxy] Handling YouTube homepage/browse without skeleton.`);
      const ytHubHtml = `
        <!DOCTYPE html>
        <html lang="en">
        <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1">
          <title>YouTube - MYRAA Embedded Hub</title>
          <style>
            * { box-sizing: border-box; margin: 0; padding: 0; }
            body { background: #0b0f19; color: #f1f5f9; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; display: flex; flex-direction: column; align-items: center; justify-content: center; min-height: 100vh; padding: 24px; text-align: center; }
            .hub-card { background: #121826; border: 1px solid rgba(0, 240, 255, 0.3); border-radius: 20px; padding: 32px 24px; max-width: 520px; width: 100%; box-shadow: 0 20px 40px rgba(0,0,0,0.7); }
            .badge { display: inline-flex; align-items: center; gap: 6px; padding: 4px 12px; background: rgba(239, 68, 68, 0.15); border: 1px solid rgba(239, 68, 68, 0.4); border-radius: 9999px; color: #ef4444; font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 16px; }
            h2 { font-size: 20px; font-weight: 700; color: #fff; margin-bottom: 8px; }
            p { font-size: 13px; color: #94a3b8; line-height: 1.5; margin-bottom: 24px; }
            .search-box { display: flex; gap: 8px; margin-bottom: 24px; }
            .search-input { flex: 1; padding: 10px 14px; background: #070a13; border: 1px solid #1e293b; border-radius: 12px; color: #fff; font-size: 13px; outline: none; }
            .search-input:focus { border-color: #00f0ff; }
            .search-btn { padding: 10px 18px; background: #ef4444; color: #fff; border: none; border-radius: 12px; font-weight: 600; font-size: 13px; cursor: pointer; transition: 0.2s; }
            .search-btn:hover { background: #dc2626; }
            .btn-group { display: flex; flex-direction: column; gap: 10px; }
            .btn-ext { display: block; padding: 12px 20px; background: #00f0ff; color: #020612; text-decoration: none; border-radius: 12px; font-weight: 700; font-size: 13px; transition: 0.2s; }
            .btn-ext:hover { background: #38bdf8; }
            .hints { margin-top: 18px; font-size: 11px; color: #64748b; }
          </style>
        </head>
        <body>
          <div class="hub-card">
            <div class="badge">YouTube Companion</div>
            <h2>YouTube on MYRAA</h2>
            <p>YouTube's full desktop web app restricts third-party iframe hydration. Search for any video below to watch it directly in MYRAA's player, or open YouTube externally.</p>
            <form class="search-box" onsubmit="handleSearch(event)">
              <input type="text" id="ytQuery" class="search-input" placeholder="Search YouTube (e.g. lofi hip hop, tutorials)..." required />
              <button type="submit" class="search-btn">Search</button>
            </form>
            <div class="btn-group">
              <a href="https://www.youtube.com" target="_blank" rel="noopener noreferrer" class="btn-ext">Open Full YouTube in Chrome / Browser</a>
            </div>
            <div class="hints">Tip: You can also paste any youtube.com/watch link directly into MYRAA's address bar.</div>
          </div>
          <script>
            function handleSearch(e) {
              e.preventDefault();
              var q = document.getElementById('ytQuery').value.trim();
              if (q) {
                window.parent.postMessage({ type: 'MYRAA_YOUTUBE_SEARCH', query: q }, '*');
              }
            }
          </script>
        </body>
        </html>
      `;
      res.setHeader('Content-Type', 'text/html; charset=utf-8');
      return res.send(ytHubHtml);
    }

    try {
      const response = await fetch(targetUrl, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
          'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
          'Accept-Language': 'en-US,en;q=0.9,hi;q=0.8',
        },
        redirect: 'follow',
        signal: AbortSignal.timeout(9000),
      });

      const finalUrl = response.url || targetUrl;
      const contentType = response.headers.get('content-type') || 'text/html';

      // If it's an image, pass it directly
      if (contentType.startsWith('image/')) {
        const buffer = await response.arrayBuffer();
        res.setHeader('Content-Type', contentType);
        return res.send(Buffer.from(buffer));
      }

      if (!response.ok && response.status >= 400) {
        throw new Error(`Website returned HTTP status ${response.status} (${response.statusText})`);
      }

      const html = await response.text();

      // Ensure frame-blocking headers are removed
      res.removeHeader('X-Frame-Options');
      res.removeHeader('Content-Security-Policy');
      res.setHeader('Content-Type', 'text/html; charset=utf-8');

      // Base tag ensures all relative assets resolve properly to website origin
      const baseTag = `<base href="${finalUrl}">`;
      const injectionScript = `
        <script>
          (function() {
            // MYRAA Inbuilt Browser Link, Form & Navigation Bridge
            var CURRENT_PAGE_URL = "${finalUrl}";

            // 1. Intercept link clicks
            document.addEventListener('click', function(e) {
              var anchor = e.target.closest('a');
              if (anchor && anchor.href && !anchor.href.startsWith('javascript:')) {
                if (anchor.target === '_blank') {
                  anchor.target = '_self';
                }
                e.preventDefault();
                window.parent.postMessage({ type: 'MYRAA_BROWSER_NAVIGATE', url: anchor.href }, '*');
              }
            }, true);

            // 2. Intercept search forms (Google, Wikipedia, GitHub, etc.)
            document.addEventListener('submit', function(e) {
              var form = e.target;
              if (form && form.action) {
                var method = (form.method || 'GET').toUpperCase();
                if (method === 'GET') {
                  e.preventDefault();
                  var actionUrl = new URL(form.action, document.baseURI).href;
                  var formData = new FormData(form);
                  var params = new URLSearchParams(formData).toString();
                  var finalNavUrl = actionUrl + (actionUrl.includes('?') ? '&' : '?') + params;
                  window.parent.postMessage({ type: 'MYRAA_BROWSER_NAVIGATE', url: finalNavUrl }, '*');
                }
              }
            }, true);

            // 3. SPA & Hash Navigation interception
            window.addEventListener('popstate', function() {
              window.parent.postMessage({ type: 'MYRAA_BROWSER_POPSTATE', url: window.location.href }, '*');
            });

            window.addEventListener('hashchange', function() {
              window.parent.postMessage({ type: 'MYRAA_BROWSER_NAVIGATE', url: window.location.href }, '*');
            });

            // 4. Report actual page title & URL to MYRAA browser tabs
            window.addEventListener('DOMContentLoaded', function() {
              window.parent.postMessage({
                type: 'MYRAA_BROWSER_PAGE_INFO',
                url: CURRENT_PAGE_URL,
                title: document.title || CURRENT_PAGE_URL
              }, '*');
            });
          })();
        </script>
      `;

      let modifiedHtml = html;
      if (/<head[^>]*>/i.test(modifiedHtml)) {
        modifiedHtml = modifiedHtml.replace(/<head[^>]*>/i, `$&${baseTag}${injectionScript}`);
      } else {
        modifiedHtml = `${baseTag}${injectionScript}${modifiedHtml}`;
      }

      res.send(modifiedHtml);
    } catch (err: any) {
      console.warn(`[Browser Proxy Error for ${targetUrl}]:`, err.message);
      // Clean diagnostic fallback page with retry and external launch option (never leaves page blank)
      const errorHtml = `
        <!DOCTYPE html>
        <html>
        <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1">
          <title>${targetUrl} - MYRAA Browser</title>
          <style>
            body { background: #0b0f19; color: #e2e8f0; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; display: flex; align-items: center; justify-content: center; min-height: 100vh; margin: 0; padding: 20px; box-sizing: border-box; }
            .card { background: #121826; border: 1px solid rgba(0, 240, 255, 0.25); border-radius: 20px; padding: 32px 24px; max-width: 500px; text-align: center; box-shadow: 0 20px 40px rgba(0,0,0,0.6); }
            h2 { color: #ffffff; margin-top: 0; font-size: 19px; }
            p { color: #94a3b8; font-size: 13px; line-height: 1.6; margin-bottom: 20px; }
            .url-box { background: #070a13; border: 1px solid #1e293b; padding: 8px 12px; border-radius: 10px; font-family: monospace; font-size: 11px; color: #38bdf8; word-break: break-all; margin-bottom: 20px; }
            .actions { display: flex; gap: 12px; justify-content: center; flex-wrap: wrap; }
            .btn { padding: 10px 20px; border-radius: 12px; font-weight: 600; font-size: 13px; cursor: pointer; text-decoration: none; border: none; transition: all 0.2s; }
            .btn-primary { background: #00f0ff; color: #020612; }
            .btn-primary:hover { background: #38bdf8; }
            .btn-secondary { background: #1e293b; color: #fff; border: 1px solid #334155; }
            .btn-secondary:hover { background: #334155; }
          </style>
        </head>
        <body>
          <div class="card">
            <h2>Website Notice</h2>
            <div class="url-box">${targetUrl}</div>
            <p>This website (${targetUrl}) restricts embedded frame rendering, requires direct authentication, or experienced a connection timeout (${err.message}). You can open it in your external browser or retry.</p>
            <div class="actions">
              <a href="${targetUrl}" target="_blank" rel="noopener noreferrer" class="btn btn-primary">Open in Chrome / Browser</a>
              <button onclick="window.location.reload()" class="btn btn-secondary">Retry</button>
            </div>
          </div>
        </body>
        </html>
      `;
      res.setHeader('Content-Type', 'text/html; charset=utf-8');
      res.send(errorHtml);
    }
  });

  // REAL WEBPAGE CONTENT EXTRACTION & AI SUMMARIZATION ENDPOINT
  app.post('/api/web/summarize', async (req, res) => {
    try {
      const { url } = req.body;
      if (!url) {
        return res.status(400).json({ error: 'URL is required to summarize.' });
      }

      const { title, content, url: targetUrl } = await fetchAndExtractPageText(url);
      if (!content) {
        return res.status(400).json({ error: 'Could not extract readable text from webpage.' });
      }

      if (!apiKey) {
        return res.json({
          title,
          url: targetUrl,
          summary: `Webpage "${title}" retrieved successfully. (${content.split(' ').length} words).`,
          keyPoints: ['Content loaded from live URL.'],
        });
      }

      const prompt = `You are MYRAA. Read and summarize this actual webpage content clearly in 2 concise spoken sentences followed by 3 brief key points. Do not invent information not in the text.\n\nTitle: ${title}\nURL: ${targetUrl}\n\nWebpage Text:\n${content.substring(0, 4000)}`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: prompt,
      });

      const summaryText = response.text || `Summary for ${title}`;
      res.json({
        success: true,
        title,
        url: targetUrl,
        summary: summaryText,
        wordCount: content.split(' ').length,
      });
    } catch (err: any) {
      console.error('[Web Summarize Error]', err);
      res.status(500).json({ error: err.message || 'Error extracting or summarizing webpage.' });
    }
  });

  const PRIMARY_LIVE_MODEL = 'gemini-3.8-live';
  const FALLBACK_LIVE_MODEL = 'gemini-3.1-flash-live-preview';

  // WebSocket Live API bridge
  wss.on('connection', (clientWs: WebSocket) => {
    console.log('[Live] Client connected to MYRAA /live');

    let geminiSession: any = null;
    let isConnected = false;
    let pendingAudioQueue: string[] = [];
    let selectedVoice = 'Aoede';
    let activeModelName = PRIMARY_LIVE_MODEL;

    const setupCallbacks = (modelInUse: string, isFallback: boolean, fallbackNotice?: string) => ({
      onopen: () => {
        console.log(`[Live] Gemini socket opened for MYRAA (${modelInUse})`);
      },
      onmessage: (message: any) => {
        if (message.setupComplete) {
          console.log(`[Live] Setup complete received from Gemini (${modelInUse})`);
          isConnected = true;
          if (clientWs.readyState === WebSocket.OPEN) {
            clientWs.send(
              JSON.stringify({
                type: 'ready',
                model: modelInUse,
                isFallback,
                fallbackNotice,
              })
            );
          }

          while (pendingAudioQueue.length > 0) {
            const chunk = pendingAudioQueue.shift();
            if (chunk && geminiSession) {
              geminiSession.sendRealtimeInput({
                audio: { data: chunk, mimeType: 'audio/pcm;rate=16000' },
              });
            }
          }
        }

        // Handle model audio output
        const serverContent = message.serverContent;
        if (serverContent) {
          // 1. Process and deliver audio chunks first so no spoken words are lost
          const parts = serverContent.modelTurn?.parts || [];
          for (const part of parts) {
            if (part.inlineData?.data) {
              if (clientWs.readyState === WebSocket.OPEN) {
                clientWs.send(
                  JSON.stringify({
                    type: 'audio',
                    audio: part.inlineData.data,
                  })
                );
              }
            }
          }

          // 2. Deliver turn_complete signal
          if (serverContent.turnComplete) {
            if (clientWs.readyState === WebSocket.OPEN) {
              clientWs.send(JSON.stringify({ type: 'turn_complete' }));
            }
          }

          // 3. Deliver interrupted signal
          if (serverContent.interrupted) {
            console.log('[Live] Gemini serverContent.interrupted received from API');
            if (clientWs.readyState === WebSocket.OPEN) {
              clientWs.send(JSON.stringify({ type: 'interrupted' }));
            }
          }
        }

        // Handle function / tool calling
        const toolCall = message.toolCall;
        if (toolCall?.functionCalls && toolCall.functionCalls.length > 0) {
          for (const fc of toolCall.functionCalls) {
            console.log(`[Live] MYRAA Tool Call: ${fc.name} (id: ${fc.id})`);
            if (clientWs.readyState === WebSocket.OPEN) {
              clientWs.send(
                JSON.stringify({
                  type: 'tool_call',
                  callId: fc.id,
                  name: fc.name,
                  args: fc.args || {},
                })
              );
            }
          }
        }
      },
      onerror: (err: any) => {
        console.error('[Live] Gemini session error:', err?.message || err);
        if (clientWs.readyState === WebSocket.OPEN) {
          clientWs.send(
            JSON.stringify({
              type: 'error',
              message: err?.message || 'Error occurred during voice session.',
            })
          );
        }
      },
      onclose: (e: any) => {
        console.log('[Live] Gemini session closed:', e?.code, e?.reason);
        isConnected = false;
        if (clientWs.readyState === WebSocket.OPEN) {
          clientWs.send(
            JSON.stringify({
              type: 'session_closed',
              code: e?.code,
              reason: e?.reason || 'Live session completed',
            })
          );
        }
      },
    });

    const connectToGemini = async (voice: string = 'Aoede', memoryContext: string = '') => {
      // Close any previous session cleanly
      if (geminiSession) {
        try {
          if (geminiSession.conn && typeof geminiSession.conn.close === 'function') {
            geminiSession.conn.close();
          }
        } catch {}
        geminiSession = null;
      }
      isConnected = false;

      const fullSystemInstruction = `${BASE_MYRAA_PROMPT}\n${memoryContext}`;

      try {
        console.log(`[Live] Attempting primary Gemini Live connection with ${PRIMARY_LIVE_MODEL}...`);
        activeModelName = PRIMARY_LIVE_MODEL;

        geminiSession = await ai.live.connect({
          model: PRIMARY_LIVE_MODEL,
          config: {
            responseModalities: [Modality.AUDIO],
            speechConfig: {
              voiceConfig: {
                prebuiltVoiceConfig: { voiceName: voice || 'Aoede' },
              },
            },
            systemInstruction: fullSystemInstruction,
            tools: myraaTools,
          },
          callbacks: setupCallbacks(PRIMARY_LIVE_MODEL, false),
        });
      } catch (err: any) {
        const errorMsg = err?.message || String(err);
        console.warn(`[Live] Primary model ${PRIMARY_LIVE_MODEL} connection failed:`, errorMsg);
        console.log(`[Live] Connecting to verified alternative model: ${FALLBACK_LIVE_MODEL}`);

        activeModelName = FALLBACK_LIVE_MODEL;
        const notice = `Primary model '${PRIMARY_LIVE_MODEL}' unavailable (${errorMsg}). Connecting with supported live alternative '${FALLBACK_LIVE_MODEL}'.`;

        if (clientWs.readyState === WebSocket.OPEN) {
          clientWs.send(
            JSON.stringify({
              type: 'model_fallback_notice',
              requestedModel: PRIMARY_LIVE_MODEL,
              activeModel: FALLBACK_LIVE_MODEL,
              error: errorMsg,
              message: notice,
            })
          );
        }

        try {
          geminiSession = await ai.live.connect({
            model: FALLBACK_LIVE_MODEL,
            config: {
              responseModalities: [Modality.AUDIO],
              speechConfig: {
                voiceConfig: {
                  prebuiltVoiceConfig: { voiceName: voice || 'Aoede' },
                },
              },
              systemInstruction: fullSystemInstruction,
              tools: myraaTools,
            },
            callbacks: setupCallbacks(FALLBACK_LIVE_MODEL, true, notice),
          });
        } catch (fallbackErr: any) {
          console.error('[Live] Fallback to Gemini Live also failed:', fallbackErr);
          if (clientWs.readyState === WebSocket.OPEN) {
            clientWs.send(
              JSON.stringify({
                type: 'error',
                message: `Failed to connect to Live API (${PRIMARY_LIVE_MODEL}: ${errorMsg}; ${FALLBACK_LIVE_MODEL}: ${fallbackErr?.message || fallbackErr}).`,
              })
            );
          }
        }
      }
    };

    clientWs.on('message', async (raw) => {
      try {
        const data = JSON.parse(raw.toString());

        switch (data.type) {
          case 'init':
          case 'reconnect':
            selectedVoice = data.config?.voice || 'Aoede';
            const memoryContext = data.config?.memoryContext || '';
            await connectToGemini(selectedVoice, memoryContext);
            break;

          case 'text_input':
            if (geminiSession && isConnected && data.text) {
              console.log(`[Live] Forwarding text input to Gemini: ${data.text}`);
              geminiSession.sendClientContent({
                turns: [
                  {
                    role: 'user',
                    parts: [{ text: data.text }],
                  },
                ],
                turnComplete: true,
              });
            }
            break;

          case 'audio':
            if (data.audio) {
              if (geminiSession && isConnected) {
                geminiSession.sendRealtimeInput({
                  audio: { data: data.audio, mimeType: 'audio/pcm;rate=16000' },
                });
              } else {
                if (pendingAudioQueue.length < 20) {
                  pendingAudioQueue.push(data.audio);
                }
              }
            }
            break;

          case 'interrupt':
            console.log('[Live] User interrupted current turn; discarding queued audio.');
            pendingAudioQueue = [];
            break;

          case 'tool_response':
            if (geminiSession && data.callId) {
              console.log(`[Live] Sending tool response back for: ${data.name || data.callId}`);
              geminiSession.sendToolResponse({
                functionResponses: [
                  {
                    id: data.callId,
                    name: data.name,
                    response: data.response || { output: { success: true } },
                  },
                ],
              });
            }
            break;

          case 'ping':
            if (clientWs.readyState === WebSocket.OPEN) {
              clientWs.send(JSON.stringify({ type: 'pong', timestamp: data.timestamp }));
            }
            break;

          default:
            break;
        }
      } catch (err) {
        console.error('[Live] Client message handling error:', err);
      }
    });

    clientWs.on('close', () => {
      console.log('[Live] Client disconnected from /live');
      if (geminiSession) {
        try {
          if (geminiSession.conn && typeof geminiSession.conn.close === 'function') {
            geminiSession.conn.close();
          }
        } catch {
          // Ignore close errors
        }
        geminiSession = null;
      }
    });
  });

  // Serve public directory and assets directly (for video and audio files)
  app.use(express.static(path.resolve(__dirname, 'public')));
  app.use('/assets', express.static(path.resolve(__dirname, 'src/assets')));

  // Mount Vite middleware in dev, or serve built assets in prod
  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  server.listen(PORT, HOST, () => {
    console.log(`[Server] MYRAA Hindi AI Voice Assistant listening on http://${HOST}:${PORT}`);
  });
}

createServer().catch((err) => {
  console.error('[Server] Fatal startup error:', err);
  process.exit(1);
});
